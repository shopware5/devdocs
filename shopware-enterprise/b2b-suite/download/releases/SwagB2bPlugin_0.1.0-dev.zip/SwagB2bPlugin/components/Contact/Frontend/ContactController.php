<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Frontend;

use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Validator\ValidationException;
use Shopware\B2B\Contact\Framework\ContactCrudService;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Contact\Framework\ContactSearchStruct;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

class ContactController
{
    /**
     * @var ContactRepository
     */
    private $contactRepository;

    /**
     * @var GridHelper
     */
    private $contactGridHelper;

    /**
     * @var ContactCrudService
     */
    private $contactCrudService;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @param AuthenticationService $authenticationService
     * @param ContactRepository $contactRepository
     * @param ContactCrudService $contactCrudService
     * @param GridHelper $contactGridHelper
     */
    public function __construct(
        AuthenticationService $authenticationService,
        ContactRepository $contactRepository,
        ContactCrudService $contactCrudService,
        GridHelper $contactGridHelper
    ) {
        $this->authenticationService = $authenticationService;
        $this->contactRepository = $contactRepository;
        $this->contactCrudService = $contactCrudService;
        $this->contactGridHelper = $contactGridHelper;
    }

    public function indexAction()
    {
        //nth
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $ownershipContextContext = $this->authenticationService
            ->getIdentity()
            ->getOwnershipContext();

        $searchStruct = new ContactSearchStruct();

        $this->contactGridHelper
            ->extractSearchDataInStoreFront($request, $searchStruct);

        $contacts = $this->contactRepository
            ->fetchList($ownershipContextContext, $searchStruct);

        $totalCount = $this->contactRepository
            ->fetchTotalCount($ownershipContextContext, $searchStruct);

        $maxPage = $this->contactGridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $request->getParam('page', 1);

        $contactGridState = $this->contactGridHelper
            ->getGridState($request, $searchStruct, $contacts, $maxPage, $currentPage);

        return [
            'contactGrid' => $contactGridState,
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function detailAction(Request $request): array
    {
        $email = $request->requireParam('email');

        return ['contact' => $this->contactRepository->fetchOneByEmail($email)];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function editAction(Request $request): array
    {
        $email = $request->requireParam('email');

        $validationResponse = $this->contactGridHelper->getValidationResponse('contact');

        return array_merge([
            'contact' => $this->contactRepository->fetchOneByEmail($email),
        ], $validationResponse);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function updateAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();
        $contact = $this->contactRepository->fetchOneById((int) $post['id']);

        $post['encoder'] = $contact->encoder;
        $post['debtorEmail'] = $contact->debtorEmail;
        $post['password'] = $contact->password;

        $serviceRequest = $this->contactCrudService
            ->createExistingRecordRequest($post);

        try {
            $contact = $this->contactCrudService->update($serviceRequest);
        } catch (ValidationException $e) {
            $this->contactGridHelper->pushValidationException($e);
        }

        throw new B2bControllerForwardException('edit', null, null, ['email' => $contact->email]);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function removeAction(Request $request)
    {
        $request->checkPost();

        $serviceRequest = $this->contactCrudService
            ->createExistingRecordRequest($request->getPost());

        try {
            $this->contactCrudService->remove($serviceRequest);
        } catch (CanNotRemoveExistingRecordException $e) {
            // nth
        }

        throw new B2bControllerForwardException('grid');
    }

    /**
     * @return array
     */
    public function newAction(): array
    {
        $validationResponse = $this->contactGridHelper->getValidationResponse('contact');

        return array_merge([
            'isNew' => true,
        ], $validationResponse);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function createAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();

        $identity = $this->authenticationService->getIdentity();
        $post = $this->extendRequestDataFromIdentity($post, $identity);

        $serviceRequest = $this->contactCrudService->createNewRecordRequest($post);

        try {
            $this->contactCrudService->create($serviceRequest, $identity);
        } catch (ValidationException $e) {
            $this->contactGridHelper->pushValidationException($e);
            throw new B2bControllerForwardException('new');
        }

        throw new B2bControllerForwardException('detail', null, null, ['email' => $serviceRequest->requireParam('email')]);
    }

    /**
     * @param $post
     * @param Identity $identity
     * @return array $post
     */
    private function extendRequestDataFromIdentity($post, Identity $identity): array
    {
        $post['debtorEmail'] = $identity->getOwnershipContext()->shopOwnerEmail;
        $post['language'] = $identity->getPostalSettings()->language;

        return $post;
    }
}
