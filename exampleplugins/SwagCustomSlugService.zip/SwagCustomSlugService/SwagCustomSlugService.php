<?php

namespace SwagCustomSlugService;

use Shopware\Components\Plugin;

class SwagCustomSlugService extends Plugin
{
}