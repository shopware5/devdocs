<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Framework;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\Debtor\Framework\DebtorRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationRepositoryInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class ContactRepository implements AuthenticationRepositoryInterface, GridRepository
{
    const TABLE_NAME = 'b2b_debtor_contact';
    const TABLE_ALIAS = 'contact';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DebtorRepository
     */
    private $debtorRepository;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param DebtorRepository $debtorRepository
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        DebtorRepository $debtorRepository
    ) {
        $this->connection = $connection;
        $this->debtorRepository = $debtorRepository;
        $this->dbalHelper = $dbalHelper;
    }

    /**
     * @param string $email
     * @return ContactEntity
     */
    public function fetchOneByEmail(string $email): ContactEntity
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.email = :email')
            ->setParameter('email', $email)
            ->execute();

        $contactData = $statement->fetch(\PDO::FETCH_ASSOC);

        return $this->createContactByContactData($contactData, $email);
    }

    /**
     * @param int $id
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return ContactEntity
     */
    public function fetchOneById(int $id): ContactEntity
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->setParameter('id', $id)
            ->execute();

        $contactData = $statement->fetch(\PDO::FETCH_ASSOC);

        return $this->createContactByContactData($contactData, $id);
    }

    /**
     * @param $contactData
     * @param $identifier
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return ContactEntity
     */
    private function createContactByContactData($contactData, $identifier): ContactEntity
    {
        if (!$contactData) {
            throw new NotFoundException(sprintf('Contact not found for %s', $identifier));
        }

        $contact = new ContactEntity();
        $contact->fromDatabaseArray($contactData);
        $contact->debtor = $this->debtorRepository->fetchOneByEmail($contact->debtorEmail);

        return $contact;
    }

    /**
     * @param string $email
     * @return int
     */
    public function hasByEmail(string $email): int
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.email = :email')
            ->setParameter('email', $email)
            ->execute();

        return (int) $statement->fetch(\PDO::FETCH_COLUMN);
    }

    /**
     * @param ContactEntity $contact
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @return ContactEntity
     */
    public function addContact(ContactEntity $contact): ContactEntity
    {
        if (!$contact->isNew()) {
            throw new CanNotInsertExistingRecordException('The contact provided already exists');
        }

        $this->connection->insert(
            self::TABLE_NAME,
            $contact->toDatabaseArray()
        );

        $contact->id = (int) $this->connection->lastInsertId();

        return $contact;
    }

    /**
     * @param ContactEntity $contact
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return ContactEntity
     */
    public function updateContact(ContactEntity $contact): ContactEntity
    {
        if ($contact->isNew()) {
            throw new CanNotUpdateExistingRecordException('The contact provided does not exist');
        }

        $this->connection->update(
            self::TABLE_NAME,
            $contact->toDatabaseArray(),
            ['id' => $contact->id]
        );

        return $contact;
    }

    /**
     * @param ContactEntity $contact
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return ContactEntity
     */
    public function removeContact(ContactEntity $contact): ContactEntity
    {
        if ($contact->isNew()) {
            throw new CanNotRemoveExistingRecordException('The contact provided does not exist');
        }

        $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $contact->id]
        );

        $contact->id = null;

        return $contact;
    }

    /**
     * @param string $email
     * @param LoginContextService $contextService
     * @return Identity
     */
    public function fetchIdentityByEmail(string $email, LoginContextService $contextService): Identity
    {
        $entity = $this->fetchOneByEmail($email);

        $debtorIdentity = $this
            ->debtorRepository
            ->fetchIdentityById($entity->debtor->id, $contextService);

        $authId = $contextService->getAuthId(__CLASS__, $email, $debtorIdentity->getAuthId());

        return new ContactIdentity($authId, (int) $entity->id, self::TABLE_NAME, $entity, $debtorIdentity);
    }

    /**
     * @param OwnershipContext $context
     * @param ContactSearchStruct $searchStruct
     * @return array
     */
    public function fetchList(OwnershipContext $context, ContactSearchStruct $searchStruct): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS);

        $this->filterByDebtor($context, $query);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper->applySearchStruct($searchStruct, $query);

        $statement = $query->execute();
        $contactsData = $statement->fetchAll(\PDO::FETCH_ASSOC);

        $contacts = [];
        foreach ($contactsData as $contactData) {
            $contacts[] = (new ContactEntity())->fromDatabaseArray($contactData);
        }

        return $contacts;
    }

    /**
     * @param OwnershipContext $context
     * @param ContactSearchStruct $contactSearchStruct
     * @return int
     */
    public function fetchTotalCount(OwnershipContext $context, ContactSearchStruct $contactSearchStruct): int
    {
        $query = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS);

        $this->filterByDebtor($context, $query);
        $this->dbalHelper->applyFilters($contactSearchStruct, $query);

        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * @param OwnershipContext $context
     * @param QueryBuilder $query
     */
    private function filterByDebtor(OwnershipContext $context, QueryBuilder $query)
    {
        $query->andWhere(self::TABLE_ALIAS . '.s_user_debtor_email = :debtorEmail')
            ->setParameter('debtorEmail', $context->shopOwnerEmail);
    }

    /**
     * @return string query alias for filter construction
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'email',
            'title',
            'salutation',
            'firstname',
            'lastname',
        ];
    }
}
