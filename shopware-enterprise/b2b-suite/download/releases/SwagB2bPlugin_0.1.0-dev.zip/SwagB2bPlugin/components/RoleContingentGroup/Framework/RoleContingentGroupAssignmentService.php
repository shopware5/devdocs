<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContingentGroup\Framework;

/**
 * Assigns roles to contingent groups M:N
 */
class RoleContingentGroupAssignmentService
{
    /**
     * @var RoleContingentGroupRepository
     */
    private $roleContingentGroupRepository;

    /**
     * @param RoleContingentGroupRepository $roleContingentGroupRepository
     */
    public function __construct(
        RoleContingentGroupRepository $roleContingentGroupRepository
    ) {
        $this->roleContingentGroupRepository = $roleContingentGroupRepository;
    }

    /**
     * @param int $roleId
     * @param int $contingentGroupId
     */
    public function assign(int $roleId, int $contingentGroupId)
    {
        $this->roleContingentGroupRepository
            ->assignRoleContingentGroup($roleId, $contingentGroupId);
    }

    /**
     * @param int $roleId
     * @param int $contingentGroupId
     */
    public function removeAssignment(int $roleId, int $contingentGroupId)
    {
        $this->roleContingentGroupRepository
            ->removeRoleContingentGroupAssignment($roleId, $contingentGroupId);
    }
}
