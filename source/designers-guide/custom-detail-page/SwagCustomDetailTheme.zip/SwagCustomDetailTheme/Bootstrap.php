<?php
class Shopware_Plugins_Frontend_SwagCustomDetailTheme_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{
    /**
     * Returns a marketing friendly name of the plugin.
     */
    public function getLabel()
    {
        return 'Responsive theme with custom detail page';
    }

    /**
     * Returns the version of the plugin
     */
    public function getVersion()
    {
        return '1.0.0';
    }
}
