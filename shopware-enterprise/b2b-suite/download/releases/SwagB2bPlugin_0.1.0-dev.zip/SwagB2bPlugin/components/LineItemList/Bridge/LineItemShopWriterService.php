<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Bridge;

use Shopware\B2B\Address\Framework\AddressEntity;
use Shopware\B2B\Address\Framework\AddressRepository;
use Shopware\B2B\LineItemList\Framework\LineItemList;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContext;
use Shopware\B2B\LineItemList\Framework\LineItemShopWriterServiceInterface;

class LineItemShopWriterService implements LineItemShopWriterServiceInterface
{
    /**
     * @var AddressRepository
     */
    private $addressRepository;
    /**
     * @var LineItemBridgeRepository
     */
    private $repository;

    /**
     * @param AddressRepository $addressRepository
     * @param LineItemBridgeRepository $repository
     */
    public function __construct(
        AddressRepository $addressRepository,
        LineItemBridgeRepository $repository
    ) {
        $this->addressRepository = $addressRepository;
        $this->repository = $repository;
    }

    /**
     * @param LineItemList $list
     * @param LineItemListOrderContext $context
     * @return array raw basket array
     */
    public function triggerCart(LineItemList $list, LineItemListOrderContext $context): array
    {
        return $this->asUser($context->shopUserId, function () use ($list) {
            Shopware()->Modules()->Basket()->clearBasket();

            foreach ($list->references as $product) {
                @Shopware()->Modules()->Basket()->sAddArticle($product->referenceNumber);
            }

            return @Shopware()->Modules()->Basket()->sGetBasket();
        });
    }

    /**
     * @param LineItemList $list
     * @param LineItemListOrderContext $context
     * @param array $cartArray
     * @return string ordernumber
     */
    public function triggerOrder(LineItemList $list, LineItemListOrderContext $context, array $cartArray): string
    {
        return $this->asUser($context->shopUserId, function () use ($list, $context, $cartArray) {
            $this->registerShop();

            foreach ($cartArray['content'] as &$item) {
                if (!isset($item['itemUnit'])) {
                    $item['itemUnit'] = null;
                }
            }
            unset($item);

            $billingAddress = $this->addressRepository->fetchOneById($context->billingAddressId, 'billing');
            $shippingAddress = $this->addressRepository->fetchOneById($context->shippingAddressId, 'shipping');

            $userData = $this->getUserData($context->paymentId, $billingAddress, $shippingAddress);

            $order = Shopware()->Modules()->Order();
            $order->sUserData = $userData;
            $order->sComment = $context->comment;
            $order->sBasketData = $cartArray;
            $order->sAmount = $cartArray['Amount'];
            $order->sAmountWithTax = !empty($cartArray['AmountWithTaxNumeric']) ? $cartArray['AmountWithTaxNumeric'] : $cartArray['AmountNumeric'];
            $order->sAmountNet = $cartArray['AmountNetNumeric'];
            $order->sShippingcosts = (double) 0;
            $order->sShippingcostsNumeric = (double) 0;
            $order->sShippingcostsNumericNet = (double) 0;
            $order->dispatchId = $context->shippingId;
            $order->sNet = !$userData['additional']['charge_vat'];
            $order->deviceType = $context->deviceType;

            return (string) @$order->sSaveOrder();
        });
    }

    /**
     * Get complete user-data as an array to use in view
     *
     * @param int $paymentId
     * @param AddressEntity $billingAddress
     * @param AddressEntity $shippingAddress
     * @return array
     */
    private function getUserData(int $paymentId, AddressEntity $billingAddress, AddressEntity $shippingAddress): array
    {
        $system = Shopware()->System();
        $userData = @Shopware()->Modules()->Admin()->sGetUserData();

        $userData['billingaddress'] = $billingAddress->toDatabaseArray();
        $userData['billingaddress']['userID'] = $userData['billingaddress']['user_id'];
        $userData['billingaddress']['countryID'] = $userData['billingaddress']['country_id'];
        $userData['billingaddress']['stateID'] = $userData['billingaddress']['state_id'];

        $userData['shippingaddress'] = $shippingAddress->toDatabaseArray();
        $userData['shippingaddress']['userID'] = $userData['shippingaddress']['user_id'];
        $userData['shippingaddress']['countryID'] = $userData['shippingaddress']['country_id'];
        $userData['shippingaddress']['stateID'] = $userData['shippingaddress']['state_id'];

        if (!empty($userData['additional']['countryShipping'])) {
            $system->sUSERGROUPDATA = $this->repository
                ->fetchOneUserGroupByKey($system->sUSERGROUP);

            if ($this->isTaxFreeDelivery($userData)) {
                $system->sUSERGROUPDATA['tax'] = 0;
                $system->sCONFIG['sARTICLESOUTPUTNETTO'] = 1;
                Shopware()->Session()->sUserGroupData = $system->sUSERGROUPDATA;
                $userData['additional']['charge_vat'] = false;
                $userData['additional']['show_net'] = false;
                Shopware()->Session()->sOutputNet = true;
            } else {
                $userData['additional']['charge_vat'] = true;
                $userData['additional']['show_net'] = !empty($system->sUSERGROUPDATA['tax']);
                Shopware()->Session()->sOutputNet = empty($system->sUSERGROUPDATA['tax']);
            }
        }

        $userData['additional']['payment']['id'] = $paymentId;

        return $userData;
    }

    /**
     * Validates if the provided customer should get a tax free delivery
     * @param array $userData
     * @return bool
     */
    private function isTaxFreeDelivery($userData): bool
    {
        if (!empty($userData['additional']['countryShipping']['taxfree'])) {
            return true;
        }

        if (empty($userData['additional']['countryShipping']['taxfree_ustid'])) {
            return false;
        }

        return !empty($userData['shippingaddress']['ustid']);
    }

    private function registerShop()
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
        $shop = $repository->getActiveDefault();
        $shop->registerResources();
    }

    /**
     * @param int $userId
     * @param callable $executeAs
     * @return mixed
     */
    private function asUser(int $userId, callable $executeAs)
    {
        $originalUserId = Shopware()->Session()->offsetGet('sUserId');
        Shopware()->Session()->offsetSet('sUserId', $userId);

        $result = $executeAs();

        Shopware()->Session()->offsetSet('sUserId', $originalUserId);

        return $result;
    }
}
