<?php declare(strict_types=1);

namespace B2bAjaxPanel;

use Shopware\Components\Plugin;

class B2bAjaxPanel extends Plugin
{
}
