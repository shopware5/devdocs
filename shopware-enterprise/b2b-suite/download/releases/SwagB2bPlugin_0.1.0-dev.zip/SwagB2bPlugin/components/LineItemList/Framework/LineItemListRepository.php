<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class LineItemListRepository implements GridRepository
{
    const TABLE_NAME = 'b2b_line_item_list';

    const TABLE_ALIAS = 'lineItemList';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @var LineItemReferenceRepository
     */
    private $referenceRepository;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param LineItemReferenceRepository $referenceRepository
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        LineItemReferenceRepository $referenceRepository
    ) {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
        $this->referenceRepository = $referenceRepository;
    }

    /**
     * @param LineItemListSearchStruct $searchStruct
     * @param OwnershipContext $ownershipContext
     * @return array
     */
    public function fetchLists(OwnershipContext $ownershipContext, LineItemListSearchStruct $searchStruct): array
    {
        $queryBuilder = $this->connection->createQueryBuilder()
            ->select('*')
            ->addSelect(self::TABLE_ALIAS . '.id as id')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS);
        
        $this->extendListSelectQuery($queryBuilder, $ownershipContext);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper
            ->applySearchStruct($searchStruct, $queryBuilder);

        $this->applyDebtorFilter($ownershipContext, $queryBuilder);

        $rawListData = $queryBuilder
            ->execute()
            ->fetchAll();

        $lists = [];
        foreach ($rawListData as $rawList) {
            $list = $this->createListEntity($rawList);
            $list->references = $this->referenceRepository->fetchAllForList($list->id);

            $lists[] = $list;
        }

        return $lists;
    }

    /**
     * @param OwnershipContext $ownershipContext
     * @param LineItemListSearchStruct $searchStruct
     * @return int
     */
    public function fetchTotalCount(OwnershipContext $ownershipContext, LineItemListSearchStruct $searchStruct): int
    {
        $queryBuilder = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS);

        $this->extendListSelectQuery($queryBuilder, $ownershipContext);

        $this->dbalHelper
            ->applyFilters($searchStruct, $queryBuilder);
        $this->applyDebtorFilter($ownershipContext, $queryBuilder);

        $statement = $queryBuilder->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * @param $listId
     * @return LineItemList
     */
    public function fetchOneListById(int $listId): LineItemList
    {
        $listData = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->setParameter('id', $listId)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        if (!$listData) {
            throw new NotFoundException('Unable to find list by id "' . $listId . '"');
        }

        $list = new LineItemList();
        $list->fromDatabaseArray($listData);
        $list->references = $this->referenceRepository->fetchAllForList($listId);

        return $list;
    }

    /**
     * @param LineItemList $list
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @return LineItemList
     */
    public function addList(LineItemList $list): LineItemList
    {
        if (!$list->isNew()) {
            throw new CanNotInsertExistingRecordException('The list provided already exists');
        }

        $this->connection->insert(
            self::TABLE_NAME,
            $list->toDatabaseArray()
        );

        $list->id = (int) $this->connection->lastInsertId();

        return $list;
    }

    /**
     * @param int $id
     * @param float $amountNet
     * @param float $amount
     */
    public function updateList(int $id, float $amountNet, float $amount)
    {
        $this->connection->update(
            self::TABLE_NAME,
            [
                'amount_net' => $amountNet,
                'amount' => $amount,
            ],
            ['id' => $id]
        );
    }

    /**
     * @return string query alias for filter construction
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'amount',
            'amount_net',
        ];
    }

    /**
     * @param OwnershipContext $ownershipContext
     * @param QueryBuilder $queryBuilder
     */
    private function applyDebtorFilter(OwnershipContext $ownershipContext, QueryBuilder $queryBuilder)
    {
        // @todo was andWhere before, check this @teiling
        $queryBuilder->orWhere(self::TABLE_ALIAS . '.s_user_debtor_id = :debtorId')
            ->setParameter('debtorId', $ownershipContext->shopOwnerUserId);
    }

    /**
     * @param $rawList
     * @return LineItemList
     */
    protected function createListEntity(array $rawList): LineItemList
    {
        $list = new LineItemList();
        $list->fromDatabaseArray($rawList);

        return $list;
    }

    /**
     * @param QueryBuilder $queryBuilder
     * @param OwnershipContext $context
     */
    protected function extendListSelectQuery(QueryBuilder $queryBuilder, OwnershipContext $context)
    {
        //nth
    }
}
