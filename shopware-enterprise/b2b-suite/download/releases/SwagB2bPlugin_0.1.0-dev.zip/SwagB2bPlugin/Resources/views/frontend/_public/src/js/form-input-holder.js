/**
 * Sync input field with another field which will be addressed by element class
 *
 * USAGE:
 *
 * <input type="text" name="original" data-b2b-form-input-holder="true" data-targetElement="targetClass">
 *
 * <input type="hidden" name="target" class="targetClass">
 *
 */
$.plugin('b2bFormInputHolder', {
    defaults: {
        /**
         * @type {String}
         */
        targetElement: '',
    },

    init: function() {
        this.applyDataAttributes();
        this.registerGlobalListeners();
    },

    registerGlobalListeners: function() {
        var me = this;

        me._on(me.$el, 'change', $.proxy(me.onChange, me));
    },

    onChange: function() {
        var me = this,
            sourceValue = me.$el.val(),
            $targetElement = $('.' + me.opts.targetElement);

        if(!$targetElement.length) {
            return;
        }

        $targetElement.val(sourceValue);
    },

    destroy: function() {
        var me = this;
        me._destroy();
    }
});

$('*[data-b2b-form-input-holder="true"]').b2bFormInputHolder();
