<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Bridge;

use Shopware\B2B\LineItemList\Framework\LineItemListSource;

class LineItemCheckoutSource implements LineItemListSource
{
    /**
     * @var array
     */
    public $basketData;

    /**
     * @var string
     */
    public $orderNumber;

    /**
     * @var int
     */
    public $billingAddressId;

    /**
     * @var int
     */
    public $shippingAddressId;

    /**
     * @param array $basketData
     * @param string $orderNumber
     * @param int $billingAddressId
     * @param int $shippingAddressId
     */
    public function __construct(array $basketData, string $orderNumber, int $billingAddressId, int $shippingAddressId)
    {
        $this->basketData = $basketData;
        $this->orderNumber = $orderNumber;
        $this->billingAddressId = $billingAddressId;
        $this->shippingAddressId = $shippingAddressId;
    }
}
