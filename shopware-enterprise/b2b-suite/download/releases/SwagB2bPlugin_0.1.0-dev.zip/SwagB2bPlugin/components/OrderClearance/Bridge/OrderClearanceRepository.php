<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Bridge;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceEntity;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceRepositoryInterface;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceSearchStruct;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

class OrderClearanceRepository implements OrderClearanceRepositoryInterface
{
    const TABLE_NAME = 's_order';

    const TABLE_ALIAS = 'o';

    const TABLE_ATTRIBUTES_NAME = 's_order_attributes';

    const TABLE_ATTRIBUTES_ALIAS = 'so';

    const STATUS_ORDER_CLEARANCE = -2;

    const STATUS_ORDER_OPEN = 0;

    const STATUS_ORDER_DENIED = -3;

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @var ContactRepository
     */
    private $contactRepository;

    /**
     * @var OrderClearanceEntityFactory
     */
    private $entityFactory;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param OrderClearanceEntityFactory $entityFactory
     * @param ContactRepository $contactRepository
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        OrderClearanceEntityFactory $entityFactory,
        ContactRepository $contactRepository
    ) {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
        $this->contactRepository = $contactRepository;
        $this->entityFactory = $entityFactory;
    }

    /**
     * {@inheritdoc}
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     */
    public function fetchOneByOrderContextId(int $orderContextId): OrderClearanceEntity
    {
        $order = $this->createBaseQueryBuilder()
            ->select(
                'list.*',
                'b2bOrder.*',
                'b2bOrder.id as order_context_id',
                'o.*',
                'oa.b2b_contact_id as contact_id',
                'list.id as id'
            )
            ->addSelect('(SELECT COUNT(*) FROM s_order_details WHERE orderID = o.id AND modus = 0) AS quantity')
            ->leftJoin('o', 's_order_attributes', 'oa', 'o.id = oa.orderID')
            ->where('b2bOrder.id = :orderContextId')
            ->andWhere('o.status = :status')
            ->setParameter(':orderContextId', $orderContextId)
            ->setParameter(':status', self::STATUS_ORDER_CLEARANCE)
            ->execute()
            ->fetch();

        if (!$order) {
            throw new NotFoundException(
                'Could not find an order with context id "' . $orderContextId . '" 
                 and status "' . self::STATUS_ORDER_CLEARANCE . '"'
            );
        }

        return $this->createOrder($order, (int) $order['contact_id']);
    }

    /**
     * @param int $listId
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return OrderClearanceEntity
     */
    public function fetchOneByListId(int $listId): OrderClearanceEntity
    {
        $order = $this->createBaseQueryBuilder()
            ->select(
                'list.*',
                'b2bOrder.*',
                'list.id as order_context_id',
                'o.*',
                'oa.b2b_contact_id as contact_id',
                'list.id as id'
            )
            ->addSelect('(SELECT COUNT(*) FROM s_order_details WHERE orderID = o.id AND modus = 0) AS quantity')
            ->leftJoin('o', 's_order_attributes', 'oa', 'o.id = oa.orderID')
            ->where('list.id = :listId')
            ->andWhere('o.status = :status')
            ->setParameter(':listId', $listId)
            ->setParameter(':status', self::STATUS_ORDER_CLEARANCE)
            ->execute()
            ->fetch();

        if (!$order) {
            throw new NotFoundException(
                'Could not find an order with number "' . $listId . '" and status "' . self::STATUS_ORDER_CLEARANCE . '"'
            );
        }

        return $this->createOrder($order, (int) $order['contact_id']);
    }

    /**
     * {@inheritdoc}
     */
    public function fetchAllOrderClearances(Identity $identity): array
    {
        $debtorEmail = $identity->getOwnershipContext()->shopOwnerEmail;
        $contacts = $this->getAllContactIds($debtorEmail);

        $orderClearanceData = $this
            ->createBaseQueryBuilder()
            ->select(
                'list.*',
                'b2bOrder.*',
                'b2bOrder.id as order_context_id',
                'o.*',
                'oa.b2b_contact_id as contact_id',
                'cs.name as status',
                'list.id as id'
            )
            ->leftJoin('o', 's_order_attributes', 'oa', 'o.id = oa.orderID')
            ->innerJoin(
                self::TABLE_ALIAS,
                's_core_states',
                'cs',
                self::TABLE_ALIAS . '.status = cs.id'
            )
            ->where('o.status = :status')
            ->andWhere('(b2bOrder.contact_id IN (:contacts) AND list.s_user_debtor_id = :debtorId)')
            ->setParameter(':status', self::STATUS_ORDER_CLEARANCE)
            ->setParameter(':debtorId', $identity->getOwnershipContext()->shopOwnerUserId)
            ->setParameter(':contacts', $contacts, Connection::PARAM_STR_ARRAY)
            ->execute()
            ->fetchAll();

        $orders = [];
        foreach ($orderClearanceData as $data) {
            $data['quantity'] = $this->connection
                ->fetchColumn(
                    'SELECT COUNT(*)
                     FROM s_order_details
                     WHERE orderID = :id AND modus = 0',
                    [':id' => $data['id']]
                );

            $orders[] = $this->createOrder($data, (int) $data['contact_id']);
        }

        return $orders;
    }

    /**
     * @param Identity $identity
     * @param OrderClearanceSearchStruct $searchStruct
     * @return int
     */
    public function fetchTotalCount(Identity $identity, OrderClearanceSearchStruct $searchStruct): int
    {
        $debtorEmail = $identity->getOwnershipContext()->shopOwnerEmail;
        $contacts = $this->getAllContactIds($debtorEmail);

        $query = $this
            ->createBaseQueryBuilder()
            ->select('COUNT(*)')
            ->where('o.status = :status')
            ->andWhere('(b2bOrder.contact_id IN (:contacts) AND list.s_user_debtor_id = :debtorId)')
            ->setParameter(':status', self::STATUS_ORDER_CLEARANCE)
            ->setParameter(':debtorId', $identity->getOwnershipContext()->shopOwnerUserId)
            ->setParameter(':contacts', $contacts, Connection::PARAM_STR_ARRAY);

        $this->dbalHelper->applyFilters($searchStruct, $query);
        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * {@inheritdoc}
     */
    public function belongsOrderContextIdToDebtor(Identity $identity, int $orderContextId): bool
    {
        $debtorEmail = $identity->getOwnershipContext()->shopOwnerEmail;
        $contacts = $this->getAllContactIds($debtorEmail);

        return (bool) $this->createBaseQueryBuilder()
            ->select('COUNT(*)')
            ->where('b2bOrder.contact_id IN (:contacts) ')
            ->andWhere('b2bOrder.id = :orderContextId')
            ->setParameter(':orderContextId', $orderContextId)
            ->setParameter('contacts', $contacts, Connection::PARAM_INT_ARRAY)
            ->execute()
            ->fetchColumn();
    }

    /**
     * {@inheritdoc}
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     */
    public function acceptOrder(int $orderContextId, string $comment)
    {
        $this->setOrderStatusId($orderContextId, self::STATUS_ORDER_OPEN, $comment);
    }

    /**
     * {@inheritdoc}
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     */
    public function declineOrder(int $orderContextId, string $comment)
    {
        $this->setOrderStatusId($orderContextId, self::STATUS_ORDER_DENIED, $comment);
    }

    /**
     * {@inheritdoc}
     */
    public function sendToOrderClearance(int $orderContextId)
    {
        $this->setOrderStatusId($orderContextId, self::STATUS_ORDER_CLEARANCE);
    }

    /**
     * @param int $orderContextId
     * @param int $statusId
     * @param string $comment
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     */
    private function setOrderStatusId(int $orderContextId, int $statusId, string $comment = '')
    {
        $success = (bool) $this->connection->update(
            'b2b_order_context',
            [
                'status_id' => $statusId,
                'comment' => $comment,
            ],
            ['id' => $orderContextId]
        );

        if (!$success) {
            throw new CanNotUpdateExistingRecordException(
                "Could not update b2b order context status with context id with number {$orderContextId}"
            );
        }

        $statement = $this->connection->prepare('
            UPDATE s_order as o
            INNER JOIN b2b_order_context b2bOrder ON b2bOrder.s_order_id = o.id
            SET o.status = :status
            WHERE b2bOrder.id = :id;
        ');

        $statement->execute([
            'status' => $statusId,
            'id' => $orderContextId,
        ]);
    }

    /**
     * @param int $orderContextId
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     */
    public function deleteOrder(int $orderContextId)
    {
        $orderContext = $this->connection->fetchAssoc(
            'SELECT s_order_id, list_id FROM b2b_order_context WHERE id = :id',
            [':id' => $orderContextId]
        );
        
        $successOrder = (bool) $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $orderContext['s_order_id']]
        );

        $successLineItem = (bool) $this->connection->delete(
            'b2b_line_item_list',
            ['id' => $orderContext['list_id']]
        );

        if (!$successOrder || !$successLineItem) {
            throw new CanNotRemoveExistingRecordException("Could not delete order with id {$orderContextId}");
        }
    }

    /**
     * @return string query alias for filter construction
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'ordernumber',
            'orderamount',
            'ordertime',
        ];
    }

    /**
     * @param string $debtorEmail
     * @return array
     */
    private function getAllContactIds(string $debtorEmail): array
    {
        $contacts = [];
        $contactIds = $this->connection->createQueryBuilder()
            ->select('dc.id')
            ->from('b2b_debtor_contact', 'dc')
            ->where('dc.s_user_debtor_email = :debtorEmail')
            ->setParameter(':debtorEmail', $debtorEmail)
            ->execute()
            ->fetchAll();

        foreach ($contactIds as $id) {
            $contacts[] = $id['id'];
        }

        return $contacts;
    }

    /**
     * @return \Doctrine\DBAL\Query\QueryBuilder
     */
    private function createBaseQueryBuilder()
    {
        return $this->connection->createQueryBuilder()
            ->select('o.*')
            ->from('b2b_line_item_list', 'list')
            ->innerJoin('list', 'b2b_order_context', 'b2bOrder', 'list.id = b2bOrder.list_id')
            ->innerJoin('b2bOrder', 's_order', 'o', 'b2bOrder.s_order_id = o.id');
    }

    /**
     * @param array $data
     * @param int $contactId
     * @return OrderClearanceEntity
     */
    private function createOrder(array $data, int $contactId): OrderClearanceEntity
    {
        $order = $this->entityFactory
            ->createOrderEntityFromDatabase($data);

        $order->contact = $this->contactRepository
            ->fetchOneById($contactId);

        return $order;
    }
}
