<?php

namespace SwagExtendCustomProducts\Components;

use Doctrine\DBAL\Connection;

class Verifier
{
    /** @var Connection */
    private $connection;

    /**
     * Verifier constructor.
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @return bool
     */
    public function isDependingPluginInstalled()
    {
        $queryBuilder = $this->connection->createQueryBuilder();

        return (bool)$queryBuilder->select('id')
            ->from('s_core_plugins')
            ->where('name LIKE "SwagCustomProducts"')
            ->andWhere('active = 1')
            ->execute()
            ->fetchColumn();
    }
}