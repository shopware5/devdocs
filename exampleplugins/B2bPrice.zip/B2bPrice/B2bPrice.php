<?php declare(strict_types=1);

namespace B2bPrice;

use Shopware\Components\Plugin;

class B2bPrice extends Plugin
{
}
