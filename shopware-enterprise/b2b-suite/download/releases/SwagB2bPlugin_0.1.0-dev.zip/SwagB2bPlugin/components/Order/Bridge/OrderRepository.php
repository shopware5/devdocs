<?php declare(strict_types=1);

namespace Shopware\B2B\Order\Bridge;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\LineItemList\Framework\LineItemList;
use Shopware\B2B\LineItemList\Framework\LineItemListRepository;
use Shopware\B2B\LineItemList\Framework\LineItemReferenceRepository;
use Shopware\B2B\Order\Framework\OrderEntity;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class OrderRepository extends LineItemListRepository
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param LineItemReferenceRepository $referenceRepository
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        LineItemReferenceRepository $referenceRepository
    ) {
        parent::__construct($connection, $dbalHelper, $referenceRepository);
        $this->connection = $connection;
    }

    /**
     * {@inheritdoc}
     */
    protected function extendListSelectQuery(QueryBuilder $queryBuilder, OwnershipContext $context)
    {
        $queryBuilder->innerJoin(self::TABLE_ALIAS, 'b2b_order_context', 'orderContext', self::TABLE_ALIAS . '.id = orderContext.list_id');
        $queryBuilder->innerJoin('orderContext', 's_core_states', 'shopOrderStates', 'orderContext.status_id = shopOrderStates.id');
        $queryBuilder->addSelect('shopOrderStates.name as status');
        $queryBuilder->addSelect('orderContext.id as order_context_id');

        $queryBuilder->andWhere('orderContext.contact_id = :contactId');
        $queryBuilder->setParameter('contactId', $context->identityId);
    }

    /**
     * @param array $data
     * @return LineItemList
     */
    protected function createListEntity(array $data): LineItemList
    {
        $entity = new OrderEntity();
        $entity->fromDatabaseArray($data);

        return $entity;
    }

    /**
     * @param string $orderNumber
     * @return array
     */
    public function fetchAllContainedProducts(string $orderNumber): array
    {
        $rawArticleIds = (array) $this->connection->createQueryBuilder()
            ->select('orderItem.articleID as articleId')
            ->addSelect('price as articlePrice')
            ->addSelect('articleordernumber as articleOrderNumber')
            ->from('s_order_details', 'orderItem', 'orderItem.articleID = article.id')
            ->innerJoin('orderItem', 's_order', '`order`', '`order`.ordernumber = orderItem.ordernumber')
            ->where('`order`.ordernumber = :ordernumber AND `orderItem`.articleID > 0')
            ->setParameter('ordernumber', $orderNumber)
            ->execute()
            ->fetchAll();

        return array_map(function (array $article) {
            return [
                'productId' => (int) $article['articleId'],
                'productPrice' => (float) $article['articlePrice'],
                'productOrderNumber' => (string) $article['articleOrderNumber'],
            ];
        }, $rawArticleIds);
    }

    /**
     * @param string $orderNumber
     * @param int $debtorId
     */
    public function setOrderToDebtor(string $orderNumber, int $debtorId)
    {
        $orderId = $this->getOrderIdByOrderNumber($orderNumber);

        $this->connection->update(
            's_order',
            ['userID' => $debtorId],
            ['ordernumber ' => $orderNumber]
        );

        $this->connection->update(
            's_order_esd',
            ['userID' => $debtorId],
            ['orderID ' => $orderId]
        );
    }

    /**
     * @param string $orderNumber
     * @param string $orderReference
     */
    public function setOrderReferenceNumber(string $orderNumber, string $orderReference)
    {
        $orderId = $this->getOrderIdByOrderNumber($orderNumber);

        $this->connection->update(
            's_order_attributes',
            ['b2b_order_reference ' => $orderReference],
            ['orderID' => $orderId]
        );

        $this->connection->update(
            'b2b_order_context',
            ['order_reference ' => $orderReference],
            ['s_order_id' => $orderId]
        );
    }

    /**
     * @param string $orderNumber
     * @param string $requestedDeliveryDate
     */
    public function setRequestedDeliveryDate(string $orderNumber, string $requestedDeliveryDate)
    {
        $orderId = $this->getOrderIdByOrderNumber($orderNumber);

        $this->connection->update(
            's_order_attributes',
            ['b2b_requested_delivery_date ' => $requestedDeliveryDate],
            ['orderID' => $orderId]
        );

        $this->connection->update(
            'b2b_order_context',
            ['requested_delivery_date ' => $requestedDeliveryDate],
            ['s_order_id' => $orderId]
        );
    }

    /**
     * @param string $orderNumber
     * @param int $contactId
     * @param string $email
     */
    public function setOrderIdentity(string $orderNumber, int $contactId, string $email)
    {
        $orderId = $this->getOrderIdByOrderNumber($orderNumber);

        $this->connection->update(
            's_order_attributes',
            ['b2b_contact_id ' => $contactId, 'b2b_email' => $email],
            ['orderID' => $orderId]
        );
    }

    /**
     * @param string $orderNumber
     * @return int
     */
    private function getOrderIdByOrderNumber(string $orderNumber)
    {
        $orderId = $this->connection->createQueryBuilder()
            ->select('id')
            ->from('s_order')
            ->where('ordernumber = :ordernumber')
            ->setParameter('ordernumber', $orderNumber)
            ->execute()
            ->fetchColumn();

        return (int) $orderId;
    }
}
