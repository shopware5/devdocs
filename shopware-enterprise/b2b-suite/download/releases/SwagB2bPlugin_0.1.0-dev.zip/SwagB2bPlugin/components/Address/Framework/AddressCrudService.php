<?php declare(strict_types=1);

namespace Shopware\B2B\Address\Framework;

use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Acl\Framework\AclUnsupportedContextException;
use Shopware\B2B\Common\Service\AbstractCrudService;
use Shopware\B2B\Common\Service\CrudServiceRequest;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class AddressCrudService extends AbstractCrudService
{
    /**
     * @var AddressRepository
     */
    private $addressRepository;

    /**
     * @var AddressValidationService
     */
    private $validationService;

    /**
     * @var AclRepository
     */
    private $aclRepository;

    /**
     * @param AddressRepository $addressRepository
     * @param AddressValidationService $validationService
     * @param AclRepository $aclRepository
     */
    public function __construct(
        AddressRepository $addressRepository,
        AddressValidationService $validationService,
        AclRepository $aclRepository
    ) {
        $this->addressRepository = $addressRepository;
        $this->validationService = $validationService;
        $this->aclRepository = $aclRepository;
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createNewRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'company',
                'department',
                'salutation',
                'ustid',
                'firstname',
                'lastname',
                'street',
                'additional_address_line1',
                'additional_address_line2',
                'zipcode',
                'city',
                'country_id',
                'phone',
            ]
        );
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createExistingRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'id',
                'company',
                'department',
                'salutation',
                'ustid',
                'firstname',
                'lastname',
                'street',
                'additional_address_line1',
                'additional_address_line2',
                'zipcode',
                'city',
                'country_id',
                'phone',
            ]
        );
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @param string $type
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @return AddressEntity
     */
    public function create(CrudServiceRequest $request, OwnershipContext $ownershipContext, string $type): AddressEntity
    {
        $data = $request->getFilteredData();
        $data['user_id'] = $ownershipContext->shopOwnerUserId;

        $address = new AddressEntity();
        
        $address->setData($data);
        
        $validation = $this->validationService
            ->createInsertValidation($address);

        $this->testValidation($address, $validation);

        $address = $this->addressRepository
            ->addAddress($address, $type);

        try {
            $this->aclRepository->allow(
                $ownershipContext,
                (int) $address->id
            );
        } catch (AclUnsupportedContextException $e) {
            return $address;
        }

        return $address;
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @param string $type
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return AddressEntity
     */
    public function update(CrudServiceRequest $request, OwnershipContext $ownershipContext, string $type): AddressEntity
    {
        $data = $request->getFilteredData();
        $address = new AddressEntity();
        $address->setData($data);
        $address->id = (int) $address->id;
        $address->user_id = $ownershipContext->shopOwnerUserId;

        $validation = $this->validationService
            ->createUpdateValidation($address);

        $this->testValidation($address, $validation);

        $this->addressRepository
            ->updateAddress($address, $type);

        return $address;
    }

    /**
     * @param CrudServiceRequest $request
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveUsedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return AddressEntity
     */
    public function remove(CrudServiceRequest $request): AddressEntity
    {
        $data = $request->getFilteredData();
        $address = new AddressEntity();
        $address->setData($data);

        $this->addressRepository
            ->removeAddress($address);

        return $address;
    }
}
