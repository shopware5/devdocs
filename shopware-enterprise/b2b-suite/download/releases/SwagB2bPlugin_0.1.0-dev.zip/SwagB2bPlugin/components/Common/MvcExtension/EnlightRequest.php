<?php declare(strict_types=1);

namespace Shopware\B2B\Common\MvcExtension;

use Shopware\B2B\Common\Controller\B2bControllerRedirectException;

class EnlightRequest implements Request
{
    /**
     * @var \Enlight_Controller_Request_Request
     */
    private $request;

    /**
     * @param \Enlight_Controller_Request_Request $request
     */
    public function __construct(\Enlight_Controller_Request_Request $request)
    {
        $this->request = $request;
    }

    /**
     * @param $key
     * @param mixed|null $default
     * @return mixed
     */
    public function getParam($key, $default = null)
    {
        return $this->request->getParam($key, $default);
    }

    /**
     * @param $key
     * @return string
     */
    public function requireParam($key): string
    {
        $value = $this->getParam($key);

        if (!$value) {
            throw new \InvalidArgumentException('Missing required parameter "' . $key . '"');
        }

        return (string) $value;
    }

    /**
     * @return bool
     */
    public function isPost(): bool
    {
        return $this->request->isPost();
    }

    /**
     * @return array
     */
    public function getPost(): array
    {
        return $this->request->getPost();
    }

    /**
     * @param string $action
     * @param array $params
     * @throws B2bControllerRedirectException
     */
    public function checkPost(string $action = 'index', array $params = [])
    {
        if ($this->isPost()) {
            return;
        }

        throw new B2bControllerRedirectException($action, null, null, $params);
    }
}
