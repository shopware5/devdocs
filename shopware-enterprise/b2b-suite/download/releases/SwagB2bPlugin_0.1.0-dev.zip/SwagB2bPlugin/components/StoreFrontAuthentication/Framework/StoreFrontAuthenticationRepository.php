<?php declare(strict_types = 1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

use Doctrine\DBAL\Connection;

class StoreFrontAuthenticationRepository
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    public function fetchIdByProviderData(string $providerKey, string $email): int
    {
        return (int) $this->connection
            ->fetchColumn('SELECT id FROM b2b_store_front_auth WHERE provider_key = :providerKey AND provider_context = :providerContext', [
                'providerKey' => $providerKey,
                'providerContext' => $email,
        ]);
    }

    public function createAuthContextEntry(int $contextOwnerId = null, string $providerKey, string $email)
    {
        $insertData = [
            'provider_key' => $providerKey,
            'provider_context' => $email,
        ];

        if ($contextOwnerId) {
            $insertData['context_owner_id'] = $contextOwnerId;
        }

        $this->connection->insert(
            'b2b_store_front_auth',
            $insertData
        );

        $authId =  (int) $this->connection->lastInsertId();

        if (!$contextOwnerId) {
            $this->connection->update(
                'b2b_store_front_auth',
                ['context_owner_id' => $authId],
                ['id' => $authId]
            );
        }

        return $authId;
    }
}
