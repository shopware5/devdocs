<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Framework;

use Shopware\B2B\Common\Repository\SearchStruct;

class ContactSearchStruct extends SearchStruct
{
}
