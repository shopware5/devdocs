<?php declare(strict_types=1);

namespace Shopware\B2B\Common\MvcExtension;

use Shopware\B2B\Common\Controller\B2bControllerRedirectException;

interface Request
{
    /**
     * @param $key
     * @param null $default
     * @return mixed
     */
    public function getParam($key, $default = null);

    /**
     * @param $key
     * @return mixed
     */
    public function requireParam($key);

    /**
     * @return bool
     */
    public function isPost(): bool;

    /**
     * @return array
     */
    public function getPost(): array;

    /**
     * @param string $action
     * @param array $params
     * @throws B2bControllerRedirectException
     */
    public function checkPost(string $action = 'index', array $params = []);
}
