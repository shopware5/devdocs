<?php declare(strict_types=1);

namespace SwagB2bPlugin\Subscriber;

use Enlight\Event\SubscriberInterface;

class ControllerResolver implements SubscriberInterface
{
    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2BAcl' => 'getAclControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bAddress' => 'getAddressControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bAddressSelect' => 'getAddressSelectControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContact' => 'getContactControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentGroup' => 'getContingentGroupControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRestriction' => 'getContingentRestrictionControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRule' => 'getContingentRuleControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRuleOrderItemQuantity' => 'getContingentRuleOrderItemQuantityControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRuleOrderQuantity' => 'getContingentRuleOrderQuantityControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRuleOrderAmount' => 'getContingentRuleOrderAmountControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRuleCategory' => 'getContingentRuleCategoryControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRuleProductPrice' => 'getContingentRuleProductPriceControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContingentRuleProductOrderNumber' => 'getContingentRuleProductOrderNumberControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bContactAddress' => 'getContactAddressControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2BContactContingent' => 'getContactContingentControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2BContactRole' => 'getContactRoleControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2BContactRoute' => 'getContactRouteControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bCategorySelect' => 'getCategorySelectControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bOrderClearance' => 'getOrderClearancePath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bRole' => 'getRoleControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bRoleAddress' => 'getRoleAddressControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bRoleContingentGroup' => 'getRoleContingentGroupControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bRoleRoute' => 'getRoleRouteControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bOrder' => 'getOrderControllerPath',
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_B2bLineItem' => 'getLineItemController',
        ];
    }

    /**
     * @return string
     */
    public function getOrderClearancePath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bOrderClearance.php';
    }

    /**
     * @return string
     */
    public function getContactControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContact.php';
    }

    /**
     * @return string
     */
    public function getContactAddressControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContactAddress.php';
    }

    /**
     * @return string
     */
    public function getRoleAddressControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bRoleAddress.php';
    }

    /**
     * @return string
     */
    public function getContactRoleControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContactRole.php';
    }

    /**
     * @return string
     */
    public function getContactRouteControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContactRoute.php';
    }

    /**
     * @return string
     */
    public function getContactContingentControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContactContingent.php';
    }

    /**
     * @return string
     */
    public function getAddressControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bAddress.php';
    }

    /**
     * @return string
     */
    public function getAddressSelectControllerPath()
    {
        return __DIR__ . '/../Controllers/ExtendedFrontend/B2bAddressSelect.php';
    }

    /**
     * @return string
     */
    public function getCategorySelectControllerPath()
    {
        return __DIR__ . '/../Controllers/ExtendedFrontend/B2bCategorySelect.php';
    }

    /**
     * @return string
     */
    public function getRoleControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bRole.php';
    }

    /**
     * @return string
     */
    public function getRoleRouteControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bRoleRoute.php';
    }

    /**
     * @return string
     */
    public function getAclControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bAcl.php';
    }

    /**
     * @return string
     */
    public function getContingentGroupControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentGroup.php';
    }

    /**
     * @return string
     */
    public function getContingentRestrictionControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRestriction.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRule.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleOrderItemQuantityControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRuleOrderItemQuantity.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleOrderQuantityControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRuleOrderQuantity.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleOrderAmountControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRuleOrderAmount.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleCategoryControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRuleCategory.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleProductPriceControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRuleProductPrice.php';
    }

    /**
     * @return string
     */
    public function getContingentRuleProductOrderNumberControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bContingentRuleProductOrderNumber.php';
    }

    /**
     * @return string
     */
    public function getRoleContingentGroupControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bRoleContingentGroup.php';
    }

    /**
     * @return string
     */
    public function getOrderControllerPath()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bOrder.php';
    }

    /**
     * @return string
     */
    public function getLineItemController()
    {
        return __DIR__ . '/../Controllers/Frontend/B2bLineItem.php';
    }
}
