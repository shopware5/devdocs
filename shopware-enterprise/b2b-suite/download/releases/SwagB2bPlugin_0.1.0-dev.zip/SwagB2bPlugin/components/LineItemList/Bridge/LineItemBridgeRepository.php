<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Bridge;

use Doctrine\DBAL\Connection;

class LineItemBridgeRepository
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param $orderNumber
     * @return array
     */
    public function fetchOrderDetailsByOrderNumber(string $orderNumber): array
    {
        return (array) $this->connection->createQueryBuilder()
            ->select('*')
            ->from('s_order_details', 'orderDetails')
            ->where('orderDetails.ordernumber = :orderNumber')
            ->orderBy('id')
            ->setParameter('orderNumber', $orderNumber)
            ->execute()
            ->fetchAll();
    }

    /**
     * @param string $orderNumber
     * @return array
     */
    public function fetchOrderByOrderNumber(string $orderNumber): array
    {
        return (array) $this->connection->createQueryBuilder()
            ->select('*')
            ->from('s_order', '`order`')
            ->where('`order`.ordernumber = :orderNumber')
            ->setParameter('orderNumber', $orderNumber)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);
    }

    /**
     * @param string $groupKey
     * @return array
     */
    public function fetchOneUserGroupByKey(string $groupKey): array
    {
        return (array) $this->connection
            ->fetchAssoc(
                'SELECT * FROM s_core_customergroups WHERE groupkey = :groupKey',
                ['groupKey' => $groupKey]
            );
    }
}
