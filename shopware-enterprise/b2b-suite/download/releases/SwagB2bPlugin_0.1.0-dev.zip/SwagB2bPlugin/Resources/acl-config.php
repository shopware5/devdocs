<?php declare (strict_types = 1); return array (
  'acl' => 
  array (
    'B2bAcl' => 
    array (
      'error' => 'free',
    ),
  ),
  'address' => 
  array (
    'B2bAddress' => 
    array (
      'index' => 'list',
      'remove' => 'delete',
      'billingGrid' => 'list',
      'shippingGrid' => 'list',
      'new' => 'create',
      'create' => 'create',
      'detail' => 'detail',
      'update' => 'update',
    ),
    'B2bContactAddress' => 
    array (
      'grid' => 'list',
      'assign' => 'assign',
      'billing' => 'list',
      'shipping' => 'list',
    ),
    'B2bRoleAddress' => 
    array (
      'grid' => 'detail',
      'assign' => 'assign',
      'billing' => 'detail',
      'shipping' => 'detail',
    ),
  ),
  'contact' => 
  array (
    'B2bContact' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'detail' => 'detail',
      'update' => 'update',
      'remove' => 'delete',
      'new' => 'create',
      'create' => 'create',
      'edit' => 'detail',
    ),
  ),
  'role' => 
  array (
    'B2bRole' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'remove' => 'delete',
      'create' => 'create',
      'update' => 'update',
      'new' => 'create',
      'detail' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContactRole' => 
    array (
      'index' => 'detail',
      'grid' => 'detail',
      'assign' => 'assign',
    ),
  ),
  'route' => 
  array (
    'B2bRoleRoute' => 
    array (
      'index' => 'detail',
      'grid' => 'detail',
      'assign' => 'assign',
    ),
    'B2bContactRoute' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'assign' => 'assign',
    ),
  ),
  'contingent' => 
  array (
    'B2bContingentGroup' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'create' => 'create',
      'update' => 'update',
      'remove' => 'delete',
      'new' => 'create',
      'detail' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContactContingent' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'assign' => 'assign',
    ),
    'B2bRoleContingentGroup' => 
    array (
      'index' => 'detail',
      'grid' => 'detail',
      'assign' => 'assign',
    ),
  ),
  'contingentrule' => 
  array (
    'B2bContingentRule' => 
    array (
      'grid' => 'list',
      'detail' => 'detail',
      'update' => 'update',
      'remove' => 'delete',
      'new' => 'create',
      'create' => 'create',
      'tr' => 'detail',
    ),
    'B2bContingentRestriction' => 
    array (
      'grid' => 'list',
      'detail' => 'detail',
      'update' => 'update',
      'remove' => 'delete',
      'new' => 'create',
      'create' => 'create',
    ),
    'B2bContingentRuleOrderItemQuantity' => 
    array (
      'new' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContingentRuleOrderAmount' => 
    array (
      'new' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContingentRuleOrderQuantity' => 
    array (
      'new' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContingentRuleCategory' => 
    array (
      'new' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContingentRuleProductPrice' => 
    array (
      'new' => 'detail',
      'edit' => 'detail',
    ),
    'B2bContingentRuleProductOrderNumber' => 
    array (
      'new' => 'detail',
      'edit' => 'detail',
    ),
  ),
  'order' => 
  array (
    'B2bOrder' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'detail' => 'detail',
      'overview' => 'detail',
      'log' => 'detail',
    ),
    'B2bOrderClearance' => 
    array (
      'index' => 'list',
      'grid' => 'list',
      'accept' => 'create',
      'decline' => 'update',
      'delete' => 'delete',
      'acceptOrder' => 'create',
      'declineOrder' => 'update',
      'detail' => 'detail',
    ),
    'B2bLineItem' => 
    array (
      'masterdata' => 'detail',
      'list' => 'detail',
      'saveComment' => 'update',
    ),
  ),
);