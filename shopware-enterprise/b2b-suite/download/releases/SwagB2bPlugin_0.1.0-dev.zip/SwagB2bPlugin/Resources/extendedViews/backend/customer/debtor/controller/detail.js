//{block name="backend/customer/controller/detail"}
//{$smarty.block.parent}
/** global: Ext */
Ext.define('Shopware.apps.Customer.debtor.controller.Detail', {
    override: 'Shopware.apps.Customer.controller.Detail',

    onSaveCustomer: function (btn) {
        var me = this;
        var id = btn.up('window').down('form').getRecord().get('id');

        /** global: Ext */
        Ext.Ajax.request({
            method: 'POST',
            url: '{url controller=AttributeData action=saveData}',
            params: {
                _foreignKey: id,
                _table: 's_user_attributes',
                __attribute_b2b_is_debtor: ~~me.getDetailWindow().baseFieldSet.checkbox.getValue()
            }
        });

        me.callParent(arguments);
    }
});
//{/block}
