<?php

namespace SwagBannerApi\Components\Api\Resource;

use Shopware\Components\Api\Resource\Resource;

class Example extends Resource
{
    // implement stuff here
}
