<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

class LineItemListOrderContext
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var int
     */
    public $listId;

    /**
     * @var int
     */
    public $shopUserId;

    /**
     * @var int
     */
    public $orderNumber;

    /**
     * @var int
     */
    public $shippingAddressId;

    /**
     * @var int
     */
    public $billingAddressId;

    /**
     * @var int
     */
    public $paymentId;

    /**
     * shopware alias: dispatchID
     *
     * @var int
     */
    public $shippingId;

    /**
     * @var string
     */
    public $comment = '';

    /**
     * @var string
     */
    public $deviceType = '';

    /**
     * @var int
     */
    public $statusId;

    /**
     * @var int
     */
    public $contactId;

    /**
     * @var string
     */
    public $createdAt;

    /**
     * @var string
     */
    public $requestedDeliveryDate;

    /**
     * @var string
     */
    public $orderReference;

    /**
     * @return array
     */
    public function toDatabaseArray(): array
    {
        return [
            'id' => $this->id,
            'list_id' => $this->listId,

            'ordernumber' => $this->orderNumber,

            'user_id' => $this->shopUserId,
            'shipping_address_id' => $this->shippingAddressId,
            'billing_address_id' => $this->billingAddressId,

            'payment_id' => $this->paymentId,
            'shipping_id' => $this->shippingId,

            'comment' => $this->comment,
            'device_type' => $this->deviceType,
            'status_id' => $this->statusId,

            'contact_id' => $this->contactId,

            's_order_id' => $this->orderId,
        ];
    }

    /**
     * @param array $data
     * @return array
     */
    public function fromDatabaseArray(array $data)
    {
        $this->id = (int) $data['id'];

        $this->listId = (int) $data['list_id'];

        $this->orderNumber = $data['ordernumber'];

        $this->shopUserId = (int) $data['user_id'];
        $this->contactId = (int) $data['contact_id'];

        $this->createdAt = $data['created_at'];

        $this->shippingAddressId = (int) $data['shipping_address_id'];
        $this->billingAddressId = (int) $data['billing_address_id'];

        $this->paymentId = (int) $data['payment_id'];
        $this->shippingId = (int) $data['shipping_id'];

        $this->comment = $data['comment'];
        $this->deviceType = $data['device_type'];
        $this->statusId = (int) $data['status_id'];

        $this->orderId = (int) $data['s_order_id'];

        $this->orderReference = (string) $data['order_reference'];
        $this->requestedDeliveryDate = (string) $data['requested_delivery_date'];
    }
}
