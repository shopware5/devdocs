<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

interface LineItemShopWriterServiceInterface
{
    /**
     * @param LineItemList $list
     * @param LineItemListOrderContext $context
     * @return array raw basket array
     */
    public function triggerCart(LineItemList $list, LineItemListOrderContext $context): array;

    /**
     * @param LineItemList $list
     * @param LineItemListOrderContext $context
     * @param array $cartArray
     * @return string ordernumber
     */
    public function triggerOrder(LineItemList $list, LineItemListOrderContext $context, array $cartArray): string;
}
