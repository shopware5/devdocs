<?php declare(strict_types=1);

namespace Shopware\B2B\Common\Controller;

use Shopware\B2B\Common\B2BException;

interface B2bControllerRoutingException extends B2BException
{
    /**
     * @param string $action
     * @param string|null $controller
     * @param string|null $module
     * @param array $params
     * @param int $code
     * @param \Exception|null $previous
     */
    public function __construct(string $action, string $controller = null, string $module = null, array $params = [], $code = 0, \Exception $previous = null);

    /**
     * @return string
     */
    public function getAction(): string;

    /**
     * @return string
     */
    public function getController();

    /**
     * @return string
     */
    public function getModule();

    /**
     * @return array
     */
    public function getParams(): array;
}
