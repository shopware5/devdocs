<?php declare(strict_types=1);

namespace Shopware\B2B\AclRoute\Framework;

use Shopware\B2B\Common\Repository\SearchStruct;

/**
 * AclRoute search in controllers through repositories.
 */
class AclRouteSearchStruct extends SearchStruct
{
}
