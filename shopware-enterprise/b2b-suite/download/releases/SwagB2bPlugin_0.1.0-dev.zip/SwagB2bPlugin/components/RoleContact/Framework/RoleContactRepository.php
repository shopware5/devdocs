<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContact\Framework;

use Doctrine\DBAL\Connection;

/**
 * DB-Representation of role:contact assignment
 */
class RoleContactRepository
{
    const TABLE_NAME = 'b2b_role_contact';
    const TABLE_ALIAS = 'role_contact';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param int $roleId
     * @param int $contactId
     */
    public function removeRoleContactAssignment(int $roleId, int $contactId)
    {
        $this->connection->delete(
            self::TABLE_NAME,
            [
                'role_id' => $roleId,
                'debtor_contact_id' => $contactId,
            ]
        );
    }

    /**
     * @param int $roleId
     * @param int $contactId
     */
    public function assignRoleContact(int $roleId, int $contactId)
    {
        $data = [
            'role_id' => $roleId,
            'debtor_contact_id' => $contactId,
        ];

        $this->connection->insert(
            self::TABLE_NAME,
            $data
        );
    }

    /**
     * @param int $contactId
     * @return array
     */
    public function getActiveRolesByContactId(int $contactId): array
    {
        $contingentGroups = $this->connection->fetchAll(
            'SELECT role_id FROM ' . self::TABLE_NAME . '
             WHERE debtor_contact_id = :contactId
            ',
            [
                ':contactId' => $contactId,
            ]
        );

        return (array) $contingentGroups;
    }

    /**
     * @param int $roleId
     * @param int $contactId
     * @return bool
     */
    public function isRoleDebtorContactDebtor(int $roleId, int $contactId): bool
    {
        $query = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->leftJoin(
                self::TABLE_ALIAS,
                'b2b_role',
                'role',
                'role.id = :roleId'
            )
            ->leftJoin(
                self::TABLE_ALIAS,
                'b2b_debtor_contact',
                'dc',
                'dc.id = :contactId'
            )
            ->where('role.s_user_debtor_email = dc.s_user_debtor_email')
            ->setParameter('contactId', $contactId)
            ->setParameter('roleId', $roleId)
            ->execute();

        return (bool) $query->fetch(\PDO::FETCH_COLUMN);
    }
}
