<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Repository\NotFoundException;

class LineItemListOrderContextRepository
{
    const TABLE_NAME = 'b2b_order_context';

    const TABLE_ALIAS = 'orderContext';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param int $id
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return LineItemListOrderContext
     */
    public function fetchOneOrderContextById(int $id): LineItemListOrderContext
    {
        $rawOrderContextData = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->setParameter('id', $id)
            ->setMaxResults(1)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        return $this->createOrderContextEntity($id, $rawOrderContextData);
    }

    /**
     * @param string $orderNumber
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return LineItemListOrderContext
     */
    public function fetchOneOrderContextByOrderNumber(string $orderNumber): LineItemListOrderContext
    {
        $rawOrderContextData = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.ordernumber = :orderNumber')
            ->setParameter('orderNumber', $orderNumber)
            ->setMaxResults(1)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        return $this->createOrderContextEntity((int) $rawOrderContextData['id'], $rawOrderContextData);
    }

    /**
     * @param int $listId
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return LineItemListOrderContext
     */
    public function fetchOneOrderContextByListId(int $listId): LineItemListOrderContext
    {
        $rawOrderContextData = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.list_id = :listId')
            ->setParameter('listId', $listId)
            ->setMaxResults(1)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        return $this->createOrderContextEntity($listId, $rawOrderContextData);
    }

    /**
     * @param LineItemListOrderContext $orderContext
     */
    public function addOrderContext(LineItemListOrderContext $orderContext)
    {
        $orderContextData = $orderContext->toDatabaseArray();

        if (!$orderContext->contactId) {
            unset($orderContextData['contact_id']);
        }

        $this->connection
            ->insert('b2b_order_context', $orderContext->toDatabaseArray());

        $orderContext->id = $this->connection->lastInsertId();
    }

    /**
     * @param int $listId
     * @param string $comment
     */
    public function setOrderContextComment(int $listId, string $comment)
    {
        $this->connection->update(
            self::TABLE_NAME,
            ['comment' => $comment],
            ['list_id' => $listId]
        );
    }

    /**
     * @param int $id
     * @param array|false $rawOrderContextData
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return LineItemListOrderContext
     */
    private function createOrderContextEntity(int $id, $rawOrderContextData): LineItemListOrderContext
    {
        if (!$rawOrderContextData) {
            throw new NotFoundException('No context found with id "' . $id . '"');
        }


        $orderContext = new LineItemListOrderContext();
        $orderContext->fromDatabaseArray($rawOrderContextData);

        return $orderContext;
    }
}
