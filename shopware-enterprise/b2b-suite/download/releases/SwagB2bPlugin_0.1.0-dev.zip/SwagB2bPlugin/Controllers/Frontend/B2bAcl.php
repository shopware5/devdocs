<?php declare(strict_types=1);

class Shopware_Controllers_Frontend_B2bAcl extends Enlight_Controller_Action
{
    public function errorAction()
    {
    }
}
