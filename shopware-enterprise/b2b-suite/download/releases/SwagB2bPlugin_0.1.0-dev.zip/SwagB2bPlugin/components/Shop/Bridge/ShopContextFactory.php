<?php declare(strict_types=1);

namespace Shopware\B2B\Shop\Bridge;

use Shopware\Bundle\StoreFrontBundle\Gateway\CountryGatewayInterface;
use Shopware\Bundle\StoreFrontBundle\Gateway\CurrencyGatewayInterface;
use Shopware\Bundle\StoreFrontBundle\Gateway\CustomerGroupGatewayInterface;
use Shopware\Bundle\StoreFrontBundle\Gateway\PriceGroupDiscountGatewayInterface;
use Shopware\Bundle\StoreFrontBundle\Gateway\ShopGatewayInterface;
use Shopware\Bundle\StoreFrontBundle\Gateway\TaxGatewayInterface;
use Shopware\Bundle\StoreFrontBundle\Service\Core\ContextService;
use Shopware\Bundle\StoreFrontBundle\Struct\ShopContext;
use Shopware\Components\DependencyInjection\Container;

class ShopContextFactory
{
    /**
     * @var Container
     */
    private $container;

    /**
     * @var CustomerGroupGatewayInterface
     */
    private $customerGroupGateway;

    /**
     * @var TaxGatewayInterface
     */
    private $taxGateway;

    /**
     * @var PriceGroupDiscountGatewayInterface
     */
    private $priceGroupDiscountGateway;

    /**
     * @var ShopGatewayInterface
     */
    private $shopGateway;

    /**
     * @var CurrencyGatewayInterface
     */
    private $currencyGateway;

    /**
     * @var CountryGatewayInterface
     */
    private $countryGateway;

    /**
     * @param Container $container
     * @param CustomerGroupGatewayInterface $customerGroupGateway
     * @param TaxGatewayInterface $taxGateway
     * @param CountryGatewayInterface $countryGateway
     * @param PriceGroupDiscountGatewayInterface $priceGroupDiscountGateway
     * @param ShopGatewayInterface $shopGateway
     * @param CurrencyGatewayInterface $currencyGateway
     */
    public function __construct(
        Container $container,
        CustomerGroupGatewayInterface $customerGroupGateway,
        TaxGatewayInterface $taxGateway,
        CountryGatewayInterface $countryGateway,
        PriceGroupDiscountGatewayInterface $priceGroupDiscountGateway,
        ShopGatewayInterface $shopGateway,
        CurrencyGatewayInterface $currencyGateway
    ) {
        $this->container = $container;
        $this->taxGateway = $taxGateway;
        $this->countryGateway = $countryGateway;
        $this->customerGroupGateway = $customerGroupGateway;
        $this->priceGroupDiscountGateway = $priceGroupDiscountGateway;
        $this->shopGateway = $shopGateway;
        $this->currencyGateway = $currencyGateway;
    }

    /**
     * @param int $shopId
     * @param null|int $currencyId
     * @param null|string $currentCustomerGroupKey
     * @param null|int $areaId
     * @param null|int $countryId
     * @param null|int $stateId
     * @return ShopContext
     */
    public function create(
        $shopId,
        $currencyId = null,
        $currentCustomerGroupKey = null,
        $areaId = null,
        $countryId = null,
        $stateId = null
    ): ShopContext {
        $baseUrl = $this->getStoreFrontBaseUrl();

        $shop = $this->shopGateway->get($shopId);
        $fallbackCustomerGroupKey = ContextService::FALLBACK_CUSTOMER_GROUP;

        if ($currentCustomerGroupKey === null) {
            $currentCustomerGroupKey = $fallbackCustomerGroupKey;
        }

        $groups = $this->customerGroupGateway->getList([$currentCustomerGroupKey, $fallbackCustomerGroupKey]);

        $currentCustomerGroup = $groups[$currentCustomerGroupKey];
        $fallbackCustomerGroup = $groups[$fallbackCustomerGroupKey];

        $currency = null;
        if ($currencyId !== null) {
            $currency = $this->currencyGateway->getList([$currencyId]);
            $currency = array_shift($currency);
        }
        if (!$currency) {
            $currency = $shop->getCurrency();
        }

        $context = new ShopContext($baseUrl, $shop, $currency, $currentCustomerGroup, $fallbackCustomerGroup, [], []);

        $area = null;
        if ($areaId !== null) {
            $area = $this->countryGateway->getArea($areaId, $context);
        }

        $country = null;
        if ($countryId !== null) {
            $country = $this->countryGateway->getCountry($countryId, $context);
        }

        $state = null;
        if ($stateId !== null) {
            $state = $this->countryGateway->getState($stateId, $context);
        }

        $taxRules = $this->taxGateway->getRules($currentCustomerGroup, $area, $country, $state);
        $priceGroups = $this->priceGroupDiscountGateway->getPriceGroups($currentCustomerGroup, $context);

        return new ShopContext(
            $baseUrl,
            $shop,
            $currency,
            $currentCustomerGroup,
            $fallbackCustomerGroup,
            $taxRules,
            $priceGroups,
            $area,
            $country,
            $state
        );
    }

    /**
     * @return string
     */
    private function getStoreFrontBaseUrl(): string
    {
        /** @var $config \Shopware_Components_Config */
        $config = $this->container->get('config');

        $request = null;
        if ($this->container->initialized('front')) {
            /** @var $front \Enlight_Controller_Front */
            $front = $this->container->get('front');
            $request = $front->Request();
        }

        if ($request !== null) {
            return $request->getScheme() . '://' . $request->getHttpHost() . $request->getBasePath();
        }

        return 'http://' . $config->get('basePath');
    }
}
