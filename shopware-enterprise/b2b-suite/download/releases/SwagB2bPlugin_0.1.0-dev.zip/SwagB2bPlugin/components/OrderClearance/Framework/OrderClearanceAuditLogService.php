<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Framework;

use Shopware\B2B\AuditLog\Framework\AuditLogEntity;
use Shopware\B2B\AuditLog\Framework\AuditLogIndexEntity;
use Shopware\B2B\AuditLog\Framework\AuditLogSearchStruct;
use Shopware\B2B\AuditLog\Framework\AuditLogService;
use Shopware\B2B\AuditLog\Framework\AuditLogValueEntity;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContextRepository;
use Shopware\B2B\LineItemList\Framework\LineItemReferenceRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

class OrderClearanceAuditLogService
{
    const TYPE_STATUS_CHANGE = 'OrderClearanceStatusChange';

    const TYPE_LINE_ITEM_COMMENT = 'OrderClearanceLineItemComment';

    const TYPE_COMMENT = 'OrderClearanceComment';

    /**
     * @var AuditLogService
     */
    private $auditLogService;

    /**
     * @param AuditLogService $auditLogService
     */
    public function __construct(AuditLogService $auditLogService)
    {
        $this->auditLogService = $auditLogService;
    }

    /**
     * @param int $referenceId
     * @param AuditLogValueEntity $auditLogValue
     * @param Identity $identity
     * @return AuditLogEntity
     */
    public function createStatusChangeAuditLog(int $referenceId, AuditLogValueEntity $auditLogValue, Identity $identity): AuditLogEntity
    {
        $auditLog = new AuditLogEntity();
        $auditLog->logValue = $auditLogValue->toDatabaseString();
        $auditLog->logType = self::TYPE_STATUS_CHANGE;

        $auditLogIndex = new AuditLogIndexEntity();
        $auditLogIndex->referenceId = $referenceId;
        $auditLogIndex->referenceTable = LineItemListOrderContextRepository::TABLE_NAME;

        return $this->auditLogService->createAuditLog($auditLog, $identity, [$auditLogIndex]);
    }

    /**
     * @param int $referenceId
     * @param AuditLogValueEntity $auditLogValue
     * @param Identity $identity
     * @return AuditLogEntity
     */
    public function createOrderClearanceLineItemComment(int $referenceId, AuditLogValueEntity $auditLogValue, Identity $identity): AuditLogEntity
    {
        $auditLog = new AuditLogEntity();
        $auditLog->logValue = $auditLogValue->toDatabaseString();
        $auditLog->logType = self::TYPE_LINE_ITEM_COMMENT;

        $lineItemReferenceIndex = new AuditLogIndexEntity();
        $lineItemReferenceIndex->referenceId = $referenceId;
        $lineItemReferenceIndex->referenceTable = LineItemReferenceRepository::TABLE_NAME;

        $lineItemOrderIndex = new AuditLogIndexEntity();
        $lineItemOrderIndex->referenceId = $referenceId;
        $lineItemOrderIndex->referenceTable = LineItemListOrderContextRepository::TABLE_NAME;

        $indexGroup = [
            $lineItemReferenceIndex,
            $lineItemOrderIndex,
        ];

        return $this->auditLogService
            ->createAuditLog($auditLog, $identity, $indexGroup);
    }

    /**
     * @param int $referenceId
     * @param AuditLogValueEntity $auditLogValue
     * @param Identity $identity
     * @return AuditLogEntity
     */
    public function createOrderClearanceComment(int $referenceId, AuditLogValueEntity $auditLogValue, Identity $identity): AuditLogEntity
    {
        $auditLog = new AuditLogEntity();
        $auditLog->logValue = $auditLogValue->toDatabaseString();
        $auditLog->logType = self::TYPE_COMMENT;

        $auditLogIndex = new AuditLogIndexEntity();
        $auditLogIndex->referenceId = $referenceId;
        $auditLogIndex->referenceTable = LineItemListOrderContextRepository::TABLE_NAME;

        return $this->auditLogService
            ->createAuditLog($auditLog, $identity, [$auditLogIndex]);
    }

    /**
     * @param int $referenceId
     * @param AuditLogSearchStruct $searchStruct
     * @return AuditLogEntity[]
     */
    public function getOrderClearanceAuditLog(int $referenceId, AuditLogSearchStruct $searchStruct): array
    {
        return $this->auditLogService
            ->fetchList(LineItemListOrderContextRepository::TABLE_NAME, $referenceId, $searchStruct);
    }
}
