<?php declare(strict_types=1);

namespace Shopware\B2B\AclRoute\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\Common\Repository\SearchStruct;

class AclRouteRepository
{
    const TABLE_NAME = 'b2b_acl_route';
    const PRIVILEGE_TABLE_NAME = 'b2b_acl_route_privilege';
    const PRIVILEGE_TABLE_ALIAS = 'privilege';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     */
    public function __construct(Connection $connection, DbalHelper $dbalHelper)
    {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
    }

    /**
     * @param string $controllerName
     * @param string $actionName
     * @throws NotFoundException
     * @return int
     */
    public function fetchPrivilegeIdByControllerAndActionName(string $controllerName, string $actionName): int
    {
        $id = (int) $this->connection->fetchColumn(
            'SELECT privilege_id FROM ' . self::TABLE_NAME . ' WHERE controller = :controllerName AND action = :actionName',
            [
                'controllerName' => $controllerName,
                'actionName' =>$actionName,
            ]
        );

        if (!$id) {
            throw new NotFoundException(sprintf('No record found for %s::%s', $controllerName, $actionName));
        }

        return $id;
    }

    /**
     * @return array
     */
    public function fetchControllerList(): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::PRIVILEGE_TABLE_NAME, self::PRIVILEGE_TABLE_ALIAS)
            ->where(self::PRIVILEGE_TABLE_ALIAS . '.privilege_type NOT LIKE \'free\'')
            ->orderBy(self::PRIVILEGE_TABLE_ALIAS . '.resource_name');

        $statement = $query->execute();
        $aclData = $statement->fetchAll(\PDO::FETCH_ASSOC);

        $aclRoutes = [];
        foreach ($aclData as $aclEntry) {
            $aclRoutes[] = (new AclRouteEntity())->fromDatabaseArray($aclEntry);
        }

        return $aclRoutes;
    }

    /**
     * @param SearchStruct $contactSearchStruct
     * @return int
     */
    public function fetchTotalCount(SearchStruct $contactSearchStruct): int
    {
        $query = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::PRIVILEGE_TABLE_NAME, self::PRIVILEGE_TABLE_ALIAS);

        $this->dbalHelper->applyFilters($contactSearchStruct, $query);

        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }
}
