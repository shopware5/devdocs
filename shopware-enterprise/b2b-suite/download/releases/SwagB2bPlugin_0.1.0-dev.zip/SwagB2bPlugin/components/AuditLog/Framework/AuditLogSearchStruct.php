<?php declare(strict_types=1);

namespace Shopware\B2B\AuditLog\Framework;

use Shopware\B2B\Common\Repository\SearchStruct;

class AuditLogSearchStruct extends SearchStruct
{
}
