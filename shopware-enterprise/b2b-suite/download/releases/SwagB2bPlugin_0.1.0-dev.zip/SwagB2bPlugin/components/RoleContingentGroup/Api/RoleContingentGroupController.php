<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContingentGroup\Api;

use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\RoleContingentGroup\Framework\RoleContingentGroupAssignmentService;

class RoleContingentGroupController
{
    /**
     * @var RoleContingentGroupAssignmentService
     */
    private $roleContingentGroupAssignmentService;
    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @param RoleRepository $roleRepository
     * @param RoleContingentGroupAssignmentService $roleContingentGroupAssignmentService
     */
    public function __construct(
        RoleRepository $roleRepository,
        RoleContingentGroupAssignmentService $roleContingentGroupAssignmentService
    ) {
        $this->roleContingentGroupAssignmentService = $roleContingentGroupAssignmentService;
        $this->roleRepository = $roleRepository;
    }

    /**
     * @param string $debtorEmail
     * @param string $roleId
     * @return array
     */
    public function getListAction(string $debtorEmail, string $roleId): array
    {
        $roles = $this->roleRepository
            ->fetchAllRolesAndCheckForContingentGroupAssignment((int) $roleId, $debtorEmail);

        $totalCount = count($roles);

        return ['success' => true, 'roles' => $roles, 'totalCount' => $totalCount];
    }

    /**
     * @param string $debtorEmail
     * @param string $roleId
     * @param Request $request
     * @return array
     */
    public function createAction(string $debtorEmail, string $roleId, Request $request): array
    {
        $this->roleContingentGroupAssignmentService
            ->assign((int) $roleId, (int) $request->getParam('contingentGroupId'));

        return ['success' => true];
    }

    /**
     * @param string $debtorEmail
     * @param string $roleId
     * @param Request $request
     * @return array
     */
    public function removeAction(string $debtorEmail, string $roleId, Request $request): array
    {
        $this->roleContingentGroupAssignmentService
            ->removeAssignment((int) $roleId, (int) $request->getParam('contingentGroupId'));

        return ['success' => true];
    }
}
