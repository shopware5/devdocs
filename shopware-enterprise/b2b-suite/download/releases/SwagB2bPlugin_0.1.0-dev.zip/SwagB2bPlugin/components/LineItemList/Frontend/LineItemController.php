<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Frontend;

use Shopware\B2B\Address\Framework\AddressRepository;
use Shopware\B2B\AuditLog\Framework\AuditLogAuthorService;
use Shopware\B2B\AuditLog\Framework\AuditLogValueEntity;
use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\LineItemList\Bridge\ProductProvider;
use Shopware\B2B\LineItemList\Framework\LineItemList;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContext;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContextRepository;
use Shopware\B2B\LineItemList\Framework\LineItemListRepository;
use Shopware\B2B\LineItemList\Framework\LineItemReferenceRepository;
use Shopware\B2B\LineItemList\Framework\LineItemReferenceSearchStruct;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceAuditLogService;
use Shopware\B2B\Shop\Framework\OrderRelationServiceInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class LineItemController
{
    /**
     * @var LineItemReferenceRepository
     */
    private $repository;

    /**
     * @var GridHelper
     */
    private $grid;

    /**
     * @var LineItemListOrderContextRepository
     */
    private $orderContextRepository;

    /**
     * @var AddressRepository
     */
    private $addressRepository;

    /**
     * @var LineItemListRepository
     */
    private $listRepository;

    /**
     * @var OrderRelationServiceInterface
     */
    private $orderRelationService;

    /**
     * @var ProductProvider
     */
    private $productProvider;

    /**
     * @var AuditLogAuthorService
     */
    private $auditLogService;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @param LineItemReferenceRepository $repository
     * @param GridHelper $grid
     * @param LineItemListOrderContextRepository $orderContextRepository
     * @param AddressRepository $addressRepository
     * @param LineItemListRepository $listRepository
     * @param OrderRelationServiceInterface $orderRelationService
     * @param ProductProvider $productProvider
     * @param OrderClearanceAuditLogService $auditLogService
     * @param AuthenticationService $authenticationService
     */
    public function __construct(
        LineItemReferenceRepository $repository,
        GridHelper $grid,
        LineItemListOrderContextRepository $orderContextRepository,
        AddressRepository $addressRepository,
        LineItemListRepository $listRepository,
        OrderRelationServiceInterface $orderRelationService,
        ProductProvider $productProvider,
        OrderClearanceAuditLogService $auditLogService,
        AuthenticationService $authenticationService
    ) {
        $this->repository = $repository;
        $this->grid = $grid;
        $this->orderContextRepository = $orderContextRepository;
        $this->addressRepository = $addressRepository;
        $this->listRepository = $listRepository;
        $this->orderRelationService = $orderRelationService;
        $this->productProvider = $productProvider;
        $this->auditLogService = $auditLogService;
        $this->authenticationService = $authenticationService;
    }

    /**
     * @param Request $request
     * @return array
     */
    public function masterdataAction(Request $request): array
    {
        $listId = (int) $request->requireParam('listId');

        $list = $this->listRepository
            ->fetchOneListById($listId);

        $orderContext = $this->orderContextRepository
            ->fetchOneOrderContextByListId($listId);

        $billingAddress = $this->addressRepository
            ->fetchOneById($orderContext->billingAddressId, 'billing');

        $shippingAddress = $this->addressRepository
            ->fetchOneById($orderContext->shippingAddressId, 'shipping');

        return array_merge(
            $this->getHeaderData($list, $orderContext), [
                'orderContext' => $orderContext,
                'comment' => $orderContext->comment,
                'billingAddress' => $billingAddress,
                'shippingAddress' => $shippingAddress,
                'paymentName' => $this->orderRelationService->getPaymentNameForId($orderContext->paymentId),
                'shippingName' => $this->orderRelationService->getShippingNameForId($orderContext->shippingId),
                'listId' => $listId,
        ]);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function listAction(Request $request): array
    {
        $listId = (int) $request->requireParam('listId');

        $list = $this->listRepository
            ->fetchOneListById($listId);

        $orderContext = $this->orderContextRepository
            ->fetchOneOrderContextByListId($listId);

        $searchStruct = new LineItemReferenceSearchStruct();

        $this->grid
            ->extractSearchDataInStoreFront($request, $searchStruct);

        $searchStruct->offset = 0;
        $searchStruct->limit = PHP_INT_MAX;

        $items = $this->repository
            ->fetchList($listId, $searchStruct);

        $totalCount = $this->repository
            ->fetchTotalCount($listId, $searchStruct);

        $currentPage = $this->grid
            ->getCurrentPage($request);

        $maxPage = $this->grid
            ->getMaxPage($totalCount);

        $gridState = $this->grid
            ->getGridState($request, $searchStruct, $items, $currentPage, $maxPage);

        return array_merge(
            $this->getHeaderData($list, $orderContext), [
                'itemGrid' => $gridState,
                'listId' => $listId,
        ]);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function saveCommentAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();

        $listId = (int) $post['listId'];
        $comment = (string) $post['comment'];

        $this->orderContextRepository->setOrderContextComment($listId, $comment);

        $orderContext = $this->orderContextRepository->fetchOneOrderContextByListId($listId);
        $identity = $this->authenticationService->getIdentity();

        $auditLogValue = new AuditLogValueEntity();
        $auditLogValue->oldValue = $orderContext->comment;
        $auditLogValue->newValue = $comment;

        $this->auditLogService->createOrderClearanceComment(
            $orderContext->id,
            $auditLogValue,
            $identity
        );

        throw new B2bControllerForwardException('masterdata', null, null, ['listId' => $listId]);
    }

    /**
     * @param Request $request
     */
    public function updateLineItemAction(Request $request)
    {
        $request->checkPost();
        
        $listId = (int) $request->getParam('listId');
        $lineItemId = (int) $request->getParam('id');
        $newQuantity = (int) $request->getParam('quantity');
        $comment = (string) $request->getParam('comment');

        $item = $this->repository->fetchReferenceById($lineItemId);

        $this->repository->updateReference($lineItemId, $newQuantity, $comment);

        $lineItemList = $this->listRepository->fetchOneListById($listId);
        $this->productProvider->updateList($lineItemList);
        $this->listRepository->updateList($listId, (float) $lineItemList->amountNet, (float) $lineItemList->amount);

        $orderContext = $this->orderContextRepository->fetchOneOrderContextByListId($listId);
        $identity = $this->authenticationService->getIdentity();

        $auditLogValue = new AuditLogValueEntity();
        $auditLogValue->oldValue = $item['comment'];
        $auditLogValue->newValue = $comment;
        $auditLogValue->comment = $item['reference_number'];

        if ($auditLogValue->newValue !== $auditLogValue->oldValue) {
            $this->auditLogService->createOrderClearanceLineItemComment(
                $orderContext->id,
                $auditLogValue,
                $identity
            );
        }

        // audit log quantity change
        $auditLogValue = new AuditLogValueEntity();
        $auditLogValue->oldValue = $item['quantity'];
        $auditLogValue->newValue = $newQuantity;
        $auditLogValue->comment = $item['reference_number'];

        if ($auditLogValue->newValue !== $auditLogValue->oldValue) {
            $this->auditLogService->createStatusChangeAuditLog(
                $orderContext->id,
                $auditLogValue,
                $identity
            );
        }

        throw new B2bControllerForwardException('list', null, null, ['id' => $listId]);
    }

    /**
     * @param Request $request
     */
    public function deleteLineItemAction(Request $request)
    {
        $listId = (int) $request->getParam('listId');
        $lineItemId = (int) $request->getParam('lineItemId');

        $this->repository->removeReference($lineItemId);

        $lineItemList = $this->listRepository->fetchOneListById($listId);
        $this->productProvider->updateList($lineItemList);
        $this->listRepository->updateList($listId, (float) $lineItemList->amountNet, (float) $lineItemList->amount);

        throw new B2bControllerForwardException('list', null, null, ['id' => $listId]);
    }

    /**
     * @param LineItemList $list
     * @param LineItemListOrderContext $orderContext
     * @return array
     */
    private function getHeaderData(LineItemList $list, LineItemListOrderContext $orderContext): array
    {
        return [
            'itemCount' => count($list->references),
            'value' => $list->amount,
            'createdAt' => $orderContext->createdAt,
            'orderNumber' => $orderContext->orderNumber,
        ];
    }
}
