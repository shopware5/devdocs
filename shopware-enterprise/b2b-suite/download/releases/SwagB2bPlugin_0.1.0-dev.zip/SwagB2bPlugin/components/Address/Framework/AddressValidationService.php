<?php declare(strict_types=1);

namespace Shopware\B2B\Address\Framework;

use Shopware\B2B\Common\Validator\ValidationBuilder;
use Shopware\B2B\Common\Validator\Validator;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class AddressValidationService
{
    /**
     * @var ValidationBuilder
     */
    private $validationBuilder;

    /**
     * @var ValidatorInterface
     */
    private $validator;

    /**
     * @param ValidationBuilder $validationBuilder
     * @param ValidatorInterface $validator
     */
    public function __construct(
        ValidationBuilder $validationBuilder,
        ValidatorInterface $validator
    ) {
        $this->validationBuilder = $validationBuilder;
        $this->validator = $validator;
    }

    /**
     * @param AddressEntity $address
     * @return Validator
     */
    public function createInsertValidation(AddressEntity $address): Validator
    {
        return $this->createCrudValidation($address)
            ->validateThat('id', $address->id)
            ->isBlank()

            ->getValidator($this->validator);
    }

    /**
     * @param AddressEntity $address
     * @return Validator
     */
    public function createUpdateValidation(AddressEntity $address): Validator
    {
        return $this->createCrudValidation($address)
            ->validateThat('id', $address->id)
            ->isInt()

            ->getValidator($this->validator);
    }

    /**
     * @param AddressEntity $address
     * @return ValidationBuilder
     */
    private function createCrudValidation(AddressEntity $address): ValidationBuilder
    {
        return $this->validationBuilder
            
            ->validateThat('salutation', $address->salutation)
            ->isNotBlank()

            ->validateThat('firstname', $address->firstname)
            ->isNotBlank()

            ->validateThat('lastname', $address->lastname)
            ->isNotBlank()

            ->validateThat('company', $address->company)
            ->isNotBlank()

            ->validateThat('country_id', $address->country_id)
            ->isNotBlank()

            ->validateThat('street', $address->street)
            ->isNotBlank()

            ->validateThat('zipcode', $address->zipcode)
            ->isNotBlank()
            
            ->validateThat('city', $address->city)
            ->isNotBlank();
    }
}
