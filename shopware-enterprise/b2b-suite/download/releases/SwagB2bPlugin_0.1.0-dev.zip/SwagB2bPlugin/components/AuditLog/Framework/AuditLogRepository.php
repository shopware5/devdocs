<?php declare(strict_types=1);

namespace Shopware\B2B\AuditLog\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;

class AuditLogRepository implements GridRepository
{
    const TABLE_NAME = 'b2b_audit_log';

    const TABLE_ALIAS = 'auditLog';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @var AuditLogAuthorService
     */
    private $auditLogAuthorService;

    /**
     * @var AuditLogIndexRepository
     */
    private $auditLogIndexRepository;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param AuditLogAuthorService $auditLogAuthorService
     * @param AuditLogIndexRepository $auditLogIndexRepository
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        AuditLogAuthorService $auditLogAuthorService,
        AuditLogIndexRepository $auditLogIndexRepository

    ) {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
        $this->auditLogAuthorService = $auditLogAuthorService;
        $this->auditLogIndexRepository = $auditLogIndexRepository;
    }

    /**
     * @param string $referenceTable
     * @param int $referenceId
     * @param AuditLogSearchStruct $searchStruct
     * @return AuditLogEntity[]
     */
    public function fetchList(string $referenceTable, int $referenceId, AuditLogSearchStruct $searchStruct): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->addSelect(AuditLogIndexRepository::TABLE_ALIAS . '.*')
            ->addSelect(AuditLogAuthorRepository::TABLE_ALIAS . '.*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->innerJoin(
                self::TABLE_ALIAS,
                AuditLogAuthorRepository::TABLE_NAME,
                AuditLogAuthorRepository::TABLE_ALIAS,
                self::TABLE_ALIAS . '.author_hash = ' . AuditLogAuthorRepository::TABLE_ALIAS . '.hash'
            )
            ->innerJoin(
                self::TABLE_ALIAS,
                AuditLogIndexRepository::TABLE_NAME,
                AuditLogIndexRepository::TABLE_ALIAS,
                self::TABLE_ALIAS . '.id = ' . AuditLogIndexRepository::TABLE_ALIAS . '.audit_log_id'
            )
            ->where(AuditLogIndexRepository::TABLE_ALIAS . '.reference_table = :referenceTable')
            ->andWhere(AuditLogIndexRepository::TABLE_ALIAS . '.reference_id = :referenceId')
            ->setParameter(':referenceTable', $referenceTable)
            ->setParameter(':referenceId', $referenceId);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper->applySearchStruct($searchStruct, $query);

        $auditLogs = $query->execute()->fetchAll();

        return array_map(
            function (array $log) {
                $entity = new AuditLogEntity();
                $entity->fromDatabaseArray($log);
                $entity->logValue = (new AuditLogValueEntity())->fromDatabaseString((string) $entity->logValue);
                $entity->eventDate = new \DateTime($entity->eventDate);
                $entity->authorIdentity = (new AuditLogAuthorEntity())->fromDatabaseArray($log);

                return $entity;
            },
            $auditLogs
        );
    }

    /**
     * @param string $referenceTable
     * @param int $referenceId
     * @param AuditLogSearchStruct $searchStruct
     * @return int
     */
    public function fetchTotalCount(string $referenceTable, int $referenceId, AuditLogSearchStruct $searchStruct): int
    {
        $query = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->innerJoin(
                self::TABLE_ALIAS,
                AuditLogIndexRepository::TABLE_NAME,
                AuditLogIndexRepository::TABLE_ALIAS,
                self::TABLE_ALIAS . '.id = ' . AuditLogIndexRepository::TABLE_ALIAS . '.audit_log_id'
            )
            ->where(AuditLogIndexRepository::TABLE_ALIAS . '.reference_table = :referenceTable')
            ->andWhere(AuditLogIndexRepository::TABLE_ALIAS . '.reference_id = :referenceId')
            ->setParameter(':referenceTable', $referenceTable)
            ->setParameter(':referenceId', $referenceId);

        $this->dbalHelper->applyFilters($searchStruct, $query);

        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * @param AuditLogEntity $auditLogEntity
     * @param AuditLogIndexEntity[] $auditLogIndex
     * @return AuditLogEntity
     */
    public function createAuditLog(
        AuditLogEntity $auditLogEntity,
        array $auditLogIndex
    ): AuditLogEntity {
        if (!$auditLogEntity->isNew()) {
            throw new CanNotInsertExistingRecordException('The Audit Log provided already exists');
        }

        $entityData = $auditLogEntity->toDatabaseArray();

        $this->connection->insert(
            self::TABLE_NAME,
            $entityData
        );

        $auditLogEntity->id = (int) $this->connection->lastInsertId();

        $this->createAuditLogIndex($auditLogEntity->id, $auditLogIndex);

        $auditLogEntity->logValue = (new AuditLogValueEntity())->fromDatabaseString((string) $auditLogEntity->logValue);

        return $auditLogEntity;
    }

    /**
     * @param int $auditLogId
     * @param AuditLogIndexEntity[] $auditLogIndexes
     * @throws \Exception
     * @return bool
     */
    private function createAuditLogIndex(int $auditLogId, array $auditLogIndexes)
    {
        foreach ($auditLogIndexes as $index) {
            if (!($index instanceof AuditLogIndexEntity)) {
                throw new \Exception('Provided Entity is not instance of AuditLogIndexEntity');
            }

            $index->auditLogId = $auditLogId;
            $this->auditLogIndexRepository->createAuditLogIndex($index);
        }

        return true;
    }

    /**
     * @return string query alias for filter construction
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'log_type',
        ];
    }
}
