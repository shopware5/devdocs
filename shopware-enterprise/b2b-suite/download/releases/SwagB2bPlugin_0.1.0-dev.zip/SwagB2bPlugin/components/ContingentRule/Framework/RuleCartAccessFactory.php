<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework;

use Shopware\B2B\Cart\Framework\BlackListCartAccess;
use Shopware\B2B\Cart\Framework\CartAccessFactoryInterface;
use Shopware\B2B\Cart\Framework\CartAccessStrategyInterface;
use Shopware\B2B\Cart\Framework\WhiteListCartAccess;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

class RuleCartAccessFactory implements CartAccessFactoryInterface
{
    /**
     * @var array
     */
    private $allowedTypes;

    /**
     * @var ContingentGroupRepository
     */
    private $contingentGroupRepository;

    /**
     * @var ContingentRuleRepository
     */
    private $contingentRuleRepository;

    /**
     * @var ContingentRuleTypeFactory
     */
    private $typeFactory;

    /**
     * @param ContingentGroupRepository $contingentGroupRepository
     * @param ContingentRuleService $contingentRuleService
     * @param ContingentRuleRepository $contingentRuleRepository
     * @param ContingentRuleTypeFactory $typeFactory
     * @param array $allowedTypes
     */
    public function __construct(
        ContingentGroupRepository $contingentGroupRepository,
        ContingentRuleService $contingentRuleService,
        ContingentRuleRepository $contingentRuleRepository,
        ContingentRuleTypeFactory $typeFactory,
        array $allowedTypes
    ) {
        $this->contingentGroupRepository = $contingentGroupRepository;
        $this->contingentRuleRepository = $contingentRuleRepository;
        $this->typeFactory = $typeFactory;
        $this->allowedTypes = $allowedTypes;
    }

    /**
     * @param Identity $identity
     * @return CartAccessStrategyInterface
     */
    public function createCartAccessForIdentity(Identity $identity): CartAccessStrategyInterface
    {
        $context = $identity->getOwnershipContext();

        $contingentGroupIds = $this->contingentGroupRepository
            ->fetchContingentGroupIdsForContact($context->identityId);

        $groupStrategies = [];
        foreach ($contingentGroupIds as $contingentGroupId) {
            $types = $this->contingentGroupRepository
                ->fetchRuleTypesFromContingentGroup($contingentGroupId);

            $types = array_filter($types, function (string $typeName) {
                return in_array($typeName, $this->allowedTypes, true);
            });

            $typeStrategies = [];
            foreach ($types as $type) {
                $ruleData = $this->contingentRuleRepository
                    ->fetchActiveRuleItemsForRuleType($type, $contingentGroupId);

                $ruleStrategies = [];
                foreach ($ruleData as $rule) {
                    $ruleStrategies[] = $this->typeFactory
                        ->createCartAccessStrategy($type, $context, $rule);
                }

                $typeStrategies[] = new BlackListCartAccess(... $ruleStrategies);
            }

            $groupStrategies[] = new BlackListCartAccess(... $typeStrategies);
        }

        return new WhiteListCartAccess(... $groupStrategies);
    }
}
