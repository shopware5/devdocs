<?php declare(strict_types=1);

namespace Shopware\B2B\Shop\Framework;

interface CategoryRepositoryInterface
{
    /**
     * @param int $parentId
     * @return CategoryNode[]
     */
    public function fetchChildren(int $parentId): array;

    /**
     * @param int $categoryId
     * @param int $productId
     * @return bool
     */
    public function hasProduct(int $categoryId, int $productId): bool;

    /**
     * @param int $categoryId
     * @return CategoryNode
     */
    public function fetchNodeById(int $categoryId): CategoryNode;
}
