<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Frontend;

use Shopware\B2B\Acl\Framework\AclAccessExtensionService;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Address\Framework\AddressRepository;
use Shopware\B2B\Address\Framework\AddressSearchStruct;
use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class RoleAddressController
{
    /**
     * @var AddressRepository
     */
    private $addressRepository;

    /**
     * @var AclRepository
     */
    private $addressAclRepository;

    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @var AclAccessExtensionService
     */
    private $aclAccessExtensionService;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @param AuthenticationService $authenticationService
     * @param AddressRepository $addressRepository
     * @param AclRepository $addressAclRepository
     * @param RoleRepository $roleRepository
     * @param GridHelper $gridHelper
     * @param AclAccessExtensionService $aclAccessExtensionService
     */
    public function __construct(
        AuthenticationService $authenticationService,
        AddressRepository $addressRepository,
        AclRepository $addressAclRepository,
        RoleRepository $roleRepository,
        GridHelper $gridHelper,
        AclAccessExtensionService $aclAccessExtensionService
    ) {
        $this->authenticationService = $authenticationService;
        $this->addressRepository = $addressRepository;
        $this->addressAclRepository = $addressAclRepository;
        $this->roleRepository = $roleRepository;
        $this->gridHelper = $gridHelper;
        $this->aclAccessExtensionService = $aclAccessExtensionService;
    }

    /**
     * @param  Request $request
     * @return array
     */
    public function billingAction(Request $request): array
    {
        return ['roleId' => $request->requireParam('roleId')];
    }

    /**
     * @param  Request $request
     * @return array
     */
    public function shippingAction(Request $request): array
    {
        return ['roleId' => $request->requireParam('roleId')];
    }

    /**
     * @param  Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $addressType = $request->requireParam('type');
        $roleId = (int) $request->requireParam('roleId');

        $searchStruct = new AddressSearchStruct();

        $this->gridHelper->extractSearchDataInStoreFront($request, $searchStruct);

        $entity = $this->authenticationService->getIdentity()->getOwnershipContext();

        $role = $this->roleRepository->fetchOneById($roleId);

        $addresses = $this->addressRepository
            ->fetchList($addressType, $entity, $searchStruct);

        $this->aclAccessExtensionService
            ->extendEntitiesWithAssignment($this->addressAclRepository, $role, $addresses);

        $this->aclAccessExtensionService
            ->extendEntitiesWithIdentityOwnership($this->addressAclRepository, $entity, $addresses);

        $count = $this->addressRepository
            ->fetchTotalCount($addressType, $entity, $searchStruct);

        $maxPage = $this->gridHelper->getMaxPage($count);
        $currentPage = $this->gridHelper->getCurrentPage($request);

        $gridState = $this->gridHelper
            ->getGridState($request, $searchStruct, $addresses, $maxPage, $currentPage);

        return [
            'gridState' => $gridState,
            'type' => $addressType,
            'addresses' => $addresses,
            'roleId' => (int) $request->requireParam('roleId'),
        ];
    }

    /**
     * @param  Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function assignAction(Request $request)
    {
        $request->checkPost('grid', [
            'type' => $request->requireParam('type'),
            'roleId' => $request->requireParam('roleId'),
        ]);

        $post = $request->getPost();

        $role = $this->roleRepository->fetchOneById((int) $post['roleId']);

        if ($request->getParam('allow')) {
            $this->addressAclRepository->allow($role, (int) $post['addressId'], (bool) $request->getParam('grantable'));
        } else {
            $this->addressAclRepository->deny($role, (int) $post['addressId']);
        }

        throw new B2bControllerForwardException('grid', null, null, ['roleId' => $post['roleId'], 'type' => $post['type']]);
    }
}
