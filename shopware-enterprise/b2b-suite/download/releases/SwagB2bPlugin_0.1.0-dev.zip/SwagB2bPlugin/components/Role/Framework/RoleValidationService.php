<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Framework;

use Shopware\B2B\Common\Validator\ValidationBuilder;
use Shopware\B2B\Common\Validator\Validator;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class RoleValidationService
{
    /**
     * @var ValidationBuilder
     */
    private $validationBuilder;

    /**
     * @var ValidatorInterface
     */
    private $validator;

    /**.
     * @param ValidationBuilder $validationBuilder
     * @param ValidatorInterface $validator
     */
    public function __construct(
        ValidationBuilder $validationBuilder,
        ValidatorInterface $validator
    ) {
        $this->validationBuilder = $validationBuilder;
        $this->validator = $validator;
    }

    /**
     * @param RoleEntity $role
     * @return Validator
     */
    public function createInsertValidation(RoleEntity $role): Validator
    {
        return $this->createCrudValidation($role)
            ->validateThat('id', $role->id)
            ->isBlank()

            ->getValidator($this->validator);
    }

    /**
     * @param RoleEntity $role
     * @return Validator
     */
    public function createUpdateValidation(RoleEntity $role): Validator
    {
        return $this->createCrudValidation($role)
            ->validateThat('id', $role->id)
            ->isNotBlank()

            ->getValidator($this->validator);
    }

    /**
     * @param RoleEntity $role
     * @return ValidationBuilder
     */
    private function createCrudValidation(RoleEntity $role): ValidationBuilder
    {
        return $this->validationBuilder
            ->validateThat('name', $role->name)
            ->isNotBlank()
            ->isString()

            ->validateThat('debtorEmail', $role->debtorEmail)
            ->isNotBlank()
            ->isEmail();
    }
}
