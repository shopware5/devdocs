<?php declare(strict_types=1);

namespace SwagB2bPlugin;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Acl\Framework\AclDdlService;
use Shopware\B2B\AclRoute\Framework\AclRoutingUpdateService;
use Shopware\B2B\Contact\Framework\DependencyInjection\ContactFrameworkConfiguration;
use Shopware\B2B\Role\Framework\DependencyInjection\RoleFrameworkConfiguration;

class Installer
{
    /**
     * {@inheritdoc}
     */
    public function install()
    {
        $this->createAttributes();
        $this->createDatabase();
    }

    private function createAttributes()
    {
        $attributeService = Shopware()->Container()->get('shopware_attribute.crud_service');
        $attributeService->update('s_user_attributes', 'b2b_is_debtor', 'boolean');
        $attributeService->update('s_order_attributes', 'b2b_email', 'string');
        $attributeService->update('s_order_attributes', 'b2b_contact_id', 'integer');
        $attributeService->update('s_order_attributes', 'b2b_order_reference', 'string');
        $attributeService->update('s_order_attributes', 'b2b_requested_delivery_date', 'string');
        $attributeService->update('s_order_attributes', 'b2b_clearance_comment', 'string');
        $attributeService->update('s_user_addresses_attributes', 'b2b_type', 'string');
    }

    private function createDatabase()
    {
        $connection = Shopware()->Container()->get('dbal_connection');

        $this->createStoreFrontAuthTables($connection);
        $this->createAclRouteTables($connection);
        $this->createAuditLogTable($connection);
        $this->createContingentGroupTables($connection);
        $this->createContingentRuleTables($connection);
        $this->createContactTables($connection);
        $this->createRoleTables($connection);
        $this->createRoleContactTables($connection);
        $this->createRoleContingentGroupTables($connection);
        $this->createContactContingentGroupTables($connection);
        $this->createLineItemList($connection);
        $this->createOrderStatus($connection);
        $this->createPriceTable($connection);

        AclRoutingUpdateService::create()->addConfig(require __DIR__ . '/Resources/acl-config.php');
    }

    /**
     * @param Connection $connection
     */
    private function createStoreFrontAuthTables(Connection $connection)
    {
        $connection->exec('
            CREATE TABLE  IF NOT EXISTS `b2b_store_front_auth` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `context_owner_id` INT(11) NULL DEFAULT NULL,
                `provider_key` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                `provider_context` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                
                PRIMARY KEY (`id`),
                UNIQUE INDEX `b2b_store_front_auth_provider_key_provider_value_idx` (`provider_key`, `provider_context`)
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;
        ');
    }

    /**
     * @param Connection $connection
     */
    private function createAclRouteTables(Connection $connection)
    {
        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_acl_route_privilege` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `resource_name` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                `privilege_type` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',

                PRIMARY KEY (`id`),
                UNIQUE INDEX `b2b_acl_route_privilege_resource_privilege_idx` (`resource_name`, `privilege_type`)
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;
        ');

        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_acl_route` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `privilege_id` INT(11) NOT NULL,
                `controller` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                `action` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                
                PRIMARY KEY (`id`),
                UNIQUE INDEX `b2b_acl_route_controller_action_idx` (`controller`, `action`),
                INDEX `FK_b2b_acl_route_privilege_b2b_acl_route` (`privilege_id`),
                
                CONSTRAINT `FK_b2b_acl_route_privilege_b2b_acl_route` FOREIGN KEY (`privilege_id`) 
                    REFERENCES `b2b_acl_route_privilege` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;
        ');
    }

    /**
     * @param Connection $connection
     */
    private function createAuditLogTable(Connection $connection)
    {
        $connection->exec(
            '
            CREATE TABLE IF NOT EXISTS `b2b_audit_log_author` (
                `hash` VARCHAR(32) NOT NULL COLLATE \'utf8_unicode_ci\',
                `salutation` VARCHAR(30) COLLATE \'utf8_unicode_ci\', 
                `title` VARCHAR(100) COLLATE \'utf8_unicode_ci\', 
                `firstname` VARCHAR(100) COLLATE \'utf8_unicode_ci\', 
                `lastname` VARCHAR(100) COLLATE \'utf8_unicode_ci\',
                `email` VARCHAR(70) NOT NULL COLLATE \'utf8_unicode_ci\',
                
                PRIMARY KEY (`hash`)
            )
        '
        );

        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_audit_log` (
              `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT ,
              `log_value` TEXT COLLATE \'utf8_unicode_ci\',
              `log_type` VARCHAR(40) NOT NULL COLLATE \'utf8_unicode_ci\',
              `event_date` DATETIME DEFAULT CURRENT_TIMESTAMP,
              `author_hash` VARCHAR(32) NOT NULL COLLATE \'utf8_unicode_ci\',
                          
              PRIMARY KEY (`id`),              
              
              CONSTRAINT `FK_b2b_audit_log_author_hash` FOREIGN KEY (`author_hash`)
              REFERENCES `b2b_audit_log_author` (`hash`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB;
        '
        );

        $connection->exec(
            '
            CREATE TABLE IF NOT EXISTS `b2b_audit_log_index` (              
              `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT ,
              `audit_log_id` INT(11) UNSIGNED NOT NULL,
              `reference_table` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
              `reference_id` INT(11) NOT NULL,
                          
              PRIMARY KEY (`id`),
              INDEX `I_b2b_audit_log_table_id` (`reference_table`, `reference_id`),
              
              CONSTRAINT `FK_b2b_audit_log_id` FOREIGN KEY (`audit_log_id`)
              REFERENCES `b2b_audit_log` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB;
        ');
    }

    /**
     * @param Connection $connection
     */
    private function createContingentGroupTables(Connection $connection)
    {
        $connection->exec(
            'CREATE TABLE IF NOT EXISTS `b2b_contingent_group` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `s_user_id` INT(11) NOT NULL,
              `name` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
              `description` TEXT NULL COLLATE \'utf8_unicode_ci\',
              
              PRIMARY KEY (`id`),
              
              CONSTRAINT b2b_contingent_group_s_user_id_FK FOREIGN KEY (`s_user_id`) 
                REFERENCES `s_user` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
              COLLATE = utf8_unicode_ci;'
        );
    }

    /**
     * @param Connection $connection
     */
    private function createContingentRuleTables(Connection $connection)
    {
        $connection->exec(
            'CREATE TABLE IF NOT EXISTS b2b_contingent_group_rule (
              id INT(11) NOT NULL AUTO_INCREMENT,
              contingent_group_id INT(11) NOT NULL,
              type VARCHAR(255) NULL COLLATE \'utf8_unicode_ci\',
              
              PRIMARY KEY (id),
              
              CONSTRAINT b2b_contingent_group_rule_contingent_group_id_FK FOREIGN KEY (`contingent_group_id`) 
                REFERENCES `b2b_contingent_group` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE              
            )
              COLLATE=\'utf8_unicode_ci\''
        );

        $connection->exec(
            'CREATE TABLE IF NOT EXISTS b2b_contingent_group_rule_time_restriction (
              contingent_rule_id INT(11) NOT NULL,
              time_restriction VARCHAR(25) NULL COLLATE \'utf8_unicode_ci\',
              value DECIMAL(11,2),
              
              PRIMARY KEY (`contingent_rule_id`),
              
              CONSTRAINT b2b_contingent_group_rule_contingent_rule_id_FK FOREIGN KEY (`contingent_rule_id`) 
                REFERENCES `b2b_contingent_group_rule` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE              
            )
              COLLATE=\'utf8_unicode_ci\''
        );

        $connection->exec(
            'CREATE TABLE IF NOT EXISTS b2b_contingent_group_rule_category (
              contingent_rule_id INT(11) NOT NULL,
              category_id INT(11) UNSIGNED NOT NULL,
              
              PRIMARY KEY (`contingent_rule_id`),
            
              CONSTRAINT b2b_contingent_group_rule_category_contingent_rule_id_FK FOREIGN KEY (`contingent_rule_id`) 
                REFERENCES `b2b_contingent_group_rule` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE,              
              CONSTRAINT b2b_contingent_group_rule_category_category_id_FK FOREIGN KEY (`category_id`) 
                REFERENCES `s_categories` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE              
            )
              COLLATE=\'utf8_unicode_ci\''
        );

        $connection->exec(
            'CREATE TABLE IF NOT EXISTS b2b_contingent_group_rule_product_price (
              contingent_rule_id INT(11) NOT NULL,
              product_price INT(11) NOT NULL,
            
              PRIMARY KEY (`contingent_rule_id`),
            
              CONSTRAINT b2b_contingent_group_rule_product_price_contingent_rule_id_FK FOREIGN KEY (`contingent_rule_id`)
              REFERENCES `b2b_contingent_group_rule` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
              COLLATE=\'utf8_unicode_ci\''
        );

        $connection->exec(
            'CREATE TABLE IF NOT EXISTS b2b_contingent_group_rule_product_order_number (
              contingent_rule_id INT(11) NOT NULL,
              product_order_number VARCHAR(255) NOT NULL,
            
              PRIMARY KEY (`contingent_rule_id`),
            
              CONSTRAINT b2b_contingent_group_rule_product_order_number_rule_id_FK FOREIGN KEY (`contingent_rule_id`)
              REFERENCES `b2b_contingent_group_rule` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
              COLLATE=\'utf8_unicode_ci\''
        );
    }

    /**
     * @param Connection $connection
     */
    private function createContactTables(Connection $connection)
    {
        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_debtor_contact` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `password` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                `encoder` VARCHAR(255) NOT NULL DEFAULT \'md5\' COLLATE \'utf8_unicode_ci\',
                `email` VARCHAR(70) NOT NULL COLLATE \'utf8_unicode_ci\',
                `active` INT(1) NOT NULL DEFAULT \'0\',
                `language` VARCHAR(10) NOT NULL COLLATE \'utf8_unicode_ci\',
                `title` VARCHAR(100) NULL DEFAULT NULL COLLATE \'utf8_unicode_ci\',
                `salutation` VARCHAR(30) NULL DEFAULT NULL COLLATE \'utf8_unicode_ci\',
                `firstname` VARCHAR(255) NULL DEFAULT NULL COLLATE \'utf8_unicode_ci\',
                `lastname` VARCHAR(255) NULL DEFAULT NULL COLLATE \'utf8_unicode_ci\',
                `department` VARCHAR(255) NULL DEFAULT NULL COLLATE \'utf8_unicode_ci\',
                `s_user_debtor_email` VARCHAR(70) NOT NULL COLLATE \'utf8_unicode_ci\',
                
                PRIMARY KEY (`id`),                
                UNIQUE INDEX `email` (`email`),
                INDEX `FK_b2b_user_s_user_debtor` (`s_user_debtor_email`),
                
                CONSTRAINT `FK_b2b_user_s_user_debtor` FOREIGN KEY (`s_user_debtor_email`)
                    REFERENCES `s_user` (`email`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;
        ');

        foreach (ContactFrameworkConfiguration::createAclTables() as $table) {
            AclDdlService::create()->createTable($table);
        }
    }

    /**
     * @param Connection $connection
     */
    private function createRoleTables(Connection $connection)
    {
        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_role` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(70) NOT NULL COLLATE \'utf8_unicode_ci\',
                `s_user_debtor_email` VARCHAR(70) NOT NULL COLLATE \'utf8_unicode_ci\',
                
                PRIMARY KEY (`id`),
                INDEX `FK_b2b_role_s_user` (`s_user_debtor_email`),
                
                CONSTRAINT `FK_b2b_role_s_user` FOREIGN KEY (`s_user_debtor_email`) 
                    REFERENCES `s_user` (`email`) ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;
        ');

        foreach (RoleFrameworkConfiguration::createAclTables() as $table) {
            AclDdlService::create()->createTable($table);
        }
    }

    /**
     * @param Connection $connection
     */
    private function createRoleContactTables(Connection $connection)
    {
        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_role_contact` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `role_id` INT(11) NOT NULL,
                `debtor_contact_id` INT(11) NOT NULL ,
                
                PRIMARY KEY (`id`),
                UNIQUE INDEX `b2b_role_id_b2b_debtor_contact_id_idx` (`role_id`, `debtor_contact_id`),
                INDEX `FK_b2b_debtor_contact_id` (`debtor_contact_id`),
                INDEX `FK_b2b_role_id` (`role_id`),
                
                CONSTRAINT `FK_b2b_debtor_contact_id` FOREIGN KEY (`debtor_contact_id`) 
                    REFERENCES `b2b_debtor_contact` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE,
                CONSTRAINT `FK_b2b_role_id` FOREIGN KEY (`role_id`) 
                    REFERENCES `b2b_role` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;      
        ');
    }

    /**
     * @param Connection $connection
     */
    private function createRoleContingentGroupTables(Connection $connection)
    {
        $connection->exec(
            'CREATE TABLE IF NOT EXISTS `b2b_role_contingent_group` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `role_id` INT(11) NOT NULL,
              `contingent_group_id` INT(11) NOT NULL,
              
              PRIMARY KEY (`id`),
              UNIQUE INDEX `b2b_role_id_b2b_contingent_group_id_idx` (`role_id`, `contingent_group_id`),
              INDEX `FK_rcg_b2b_contingent_group_id` (`contingent_group_id`),
              INDEX `FK_rcg_b2b_role_id` (`role_id`),
              
              CONSTRAINT `FK_rcg_b2b_contingent_group_id` FOREIGN KEY (`contingent_group_id`)
                REFERENCES `b2b_contingent_group` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE,
              CONSTRAINT `FK_rcg_b2b_role_contingent_group_id` FOREIGN KEY (`role_id`)
                REFERENCES `b2b_role` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
              COLLATE=\'utf8_unicode_ci\'
              ENGINE=InnoDB;'
        );
    }

    /**
     * @param Connection $connection
     */
    private function createContactContingentGroupTables(Connection $connection)
    {
        $connection->exec('
            CREATE TABLE IF NOT EXISTS `b2b_contact_contingent_group` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `contact_id` INT(11) NOT NULL,
                `contingent_group_id` INT(11) NOT NULL ,
                
                PRIMARY KEY (`id`),
                UNIQUE INDEX `b2b_contingent_id_b2b_contact_id_idx` (`contact_id`, `contingent_group_id`),
                
                CONSTRAINT `FK_b2b_contact_id` FOREIGN KEY (`contact_id`) 
                  REFERENCES `b2b_debtor_contact` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE,
                CONSTRAINT `FK_b2b_contingent_group_id` FOREIGN KEY (`contingent_group_id`) 
                  REFERENCES `b2b_contingent_group` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            AUTO_INCREMENT=100;      
        ');
    }

    /**
     * @param Connection $connection
     */
    private function createOrderStatus(Connection $connection)
    {
        $connection->query('
            CREATE TABLE IF NOT EXISTS `b2b_order_context` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `list_id` INT(11) NOT NULL,

                `ordernumber` VARCHAR(255) NOT NULL,

                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                `user_id` INT(11) NOT NULL,
                `shipping_address_id` INT(11) NOT NULL,
                `billing_address_id` INT(11) NOT NULL,

                `payment_id` INT(11) NOT NULL,
                `shipping_id` INT(11) NOT NULL,

                `status_id` VARCHAR(255) NOT NULL DEFAULT \' \',

                `comment` TEXT NOT NULL,
                `device_type` VARCHAR(255) NOT NULL,

                `order_reference` VARCHAR(255) NULL DEFAULT NULL,
                `requested_delivery_date` VARCHAR(255) NULL DEFAULT NULL,
                `contact_id` INT(11) NULL DEFAULT NULL,

                `s_order_id` INT(11) NOT NULL,

                PRIMARY KEY (`id`),
                UNIQUE INDEX `b2b_line_item_list_s_order_s_order_id_list_id_idx` (`s_order_id`, `list_id`),
                INDEX `FK_b2b_line_item_list_s_order_b2b_line_item_list` (`list_id`),
                
                CONSTRAINT `FK_b2b_order_context_contact_id` FOREIGN KEY (`contact_id`) 
                    REFERENCES `b2b_debtor_contact` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE,
                CONSTRAINT `FK_b2b_order_s_order_b2b_line_item_list_id` FOREIGN KEY (`list_id`) 
                  REFERENCES `b2b_line_item_list` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE,
                CONSTRAINT `FK_b2b_order_s_order_id` FOREIGN KEY (`s_order_id`) 
                  REFERENCES `s_order` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            ;
        ');

        $connection->query('
            REPLACE INTO s_core_states (id, name, description, position, `group`, mail)
            VALUES (-3, \'orderclearance_denied\', \'Freigabe abgelehnt\', 100, \'state\', 0),
                   (-2, \'orderclearance_open\', \'Freigabe offen\', 99, \'state\', 0);
        ');
    }

    private function createLineItemList(Connection $connection)
    {
        $connection->query('
            CREATE TABLE IF NOT EXISTS `b2b_line_item_list` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `s_user_debtor_id` INT(11) NOT NULL,
                
                `amount_net`  VARCHAR(255) NULL,
                `amount`  VARCHAR(255) NULL,
                                
                PRIMARY KEY (`id`),
                INDEX `FK_b2b_line_item_list_s_user_debtor_id` (`s_user_debtor_id`),
                
                CONSTRAINT `FK_b2b_line_item_list_s_user` FOREIGN KEY (`s_user_debtor_id`) 
                  REFERENCES `s_user` (`id`) ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            ;
        ');

        $connection->query('
            CREATE TABLE IF NOT EXISTS `b2b_line_item_reference` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `reference_number` VARCHAR(255) NOT NULL COLLATE \'utf8_unicode_ci\',
                `quantity` INT(11) NOT NULL DEFAULT 1,
                `comment` LONGTEXT NOT NULL DEFAULT \'\' COLLATE \'utf8_unicode_ci\',
                `list_id` INT(11) NULL DEFAULT NULL,
                
                `amount_net`  VARCHAR(255) NULL,
                `amount`  VARCHAR(255) NULL,
                
                PRIMARY KEY (`id`),
                INDEX `b2b_line_item_reference_number_idx` (`reference_number`),
                INDEX `b2b_line_item_list_id_idx` (`list_id`),
                
                CONSTRAINT `FK__b2b_line_item_list` FOREIGN KEY (`list_id`) 
                  REFERENCES `b2b_line_item_list` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            ;
        ');
    }

    /**
     * @param Connection $connection
     */
    private function createPriceTable(Connection $connection)
    {
        $connection->query('
            CREATE TABLE `b2b_prices` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `debtor_id` int(11) NOT NULL,
              `price` double NOT NULL,
              `from` int(11) NOT NULL,
              `to` int(11) DEFAULT NULL,
              `articles_details_id` INT(11) unsigned NOT NULL,
            
              PRIMARY KEY (`id`),
            
              UNIQUE INDEX `b2b_debtor_from_to_article_idx` (`debtor_id`, `from`, `to`, `articles_details_id`),
              INDEX `b2b_prices_articles_details_idx` (`articles_details_id`),
              INDEX `b2b_prices_debtor_idx` (`debtor_id`),
            
              CONSTRAINT `FK_prices_debtor_id` FOREIGN KEY (`debtor_id`)
                REFERENCES `s_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
              CONSTRAINT `FK_prices_articles_details_id` FOREIGN KEY (`articles_details_id`)
                REFERENCES `s_articles_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
            )
            COLLATE=\'utf8_unicode_ci\'
            ENGINE=InnoDB
            ;
        ');
    }
}
