<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Framework;

use Shopware\B2B\Common\Repository\SearchStruct;

class OrderClearanceSearchStruct extends SearchStruct
{
}
