<?php

namespace SwagExtendCustomProducts\Subscriber;

use Doctrine\Common\Collections\ArrayCollection;
use Enlight\Event\SubscriberInterface;
use Enlight_Event_EventArgs;
use SwagExtendCustomProducts\Components\Types\CustomType;

class TypeFactory implements SubscriberInterface
{
    public static function getSubscribedEvents()
    {
        return [
            'SwagCustomProduct_Collect_Types' => 'onCollectTypes'
        ];
    }

    /**
     * Returns our new type(s) as ArrayCollection
     * @param Enlight_Event_EventArgs $arguments
     *
     * @return ArrayCollection
     */
    public function onCollectTypes(Enlight_Event_EventArgs $arguments)
    {
        return new ArrayCollection([
            CustomType::TYPE => new CustomType()
        ]);
    }
}