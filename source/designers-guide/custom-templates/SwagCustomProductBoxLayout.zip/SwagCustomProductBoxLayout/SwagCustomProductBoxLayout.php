<?php

namespace SwagCustomProductBoxLayout;

use Shopware\Components\Plugin;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Shopware-Plugin SwagCustomProductBoxLayout.
 */
class SwagCustomProductBoxLayout extends Plugin
{

    /**
    * @param ContainerBuilder $container
    */
    public function build(ContainerBuilder $container)
    {
        $container->setParameter('swag_custom_product_box_layout.plugin_dir', $this->getPath());
        parent::build($container);
    }

}
