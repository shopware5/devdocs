<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Frontend;

use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Validator\ValidationException;
use Shopware\B2B\Role\Framework\RoleCrudService;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\Role\Framework\RoleSearchStruct;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class RoleController
{
    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @var RoleCrudService
     */
    private $roleCrudService;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @param AuthenticationService $authenticationService
     * @param RoleRepository $roleRepository
     * @param GridHelper $gridHelper
     * @param RoleCrudService $roleCrudService
     */
    public function __construct(
        AuthenticationService $authenticationService,
        RoleRepository $roleRepository,
        GridHelper $gridHelper,
        RoleCrudService $roleCrudService
    ) {
        $this->authenticationService = $authenticationService;
        $this->roleRepository = $roleRepository;
        $this->gridHelper = $gridHelper;
        $this->roleCrudService = $roleCrudService;
    }

    public function indexAction()
    {
        //nth
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $debtorEmail = $this->authenticationService->getIdentity()->getOwnershipContext()->shopOwnerEmail;

        $searchStruct = new RoleSearchStruct();

        $this->gridHelper->extractSearchDataInStoreFront($request, $searchStruct);

        $roles = $this->roleRepository
            ->fetchList($searchStruct, $debtorEmail);

        $totalCount = $this->roleRepository
            ->fetchTotalCount($searchStruct, $debtorEmail);

        $maxPage = $this->gridHelper->getMaxPage($totalCount);

        $currentPage = (int) $this->gridHelper->getCurrentPage($request);

        $gridState = $this->gridHelper->getGridState($request, $searchStruct, $roles, $maxPage, $currentPage);

        return ['gridState' => $gridState];
    }

    /**
     * @param Request $request
     */
    public function removeAction(Request $request)
    {
        $request->checkPost();

        $serviceRequest = $this->roleCrudService
            ->createExistingRecordRequest($request->getPost());

        try {
            $this->roleCrudService->remove($serviceRequest);
        } catch (CanNotRemoveExistingRecordException $e) {
            // nth
        }

        throw new B2bControllerForwardException('grid');
    }

    public function newAction(): array
    {
        return $this->gridHelper->getValidationResponse('role');
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     * @return array
     */
    public function createAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();
        $post['debtorEmail'] = $this->authenticationService
            ->getIdentity()
            ->getOwnershipContext()
            ->shopOwnerEmail;

        $serviceRequest = $this->roleCrudService
            ->createNewRecordRequest($post);

        try {
            $role = $this->roleCrudService
                ->create($serviceRequest);
        } catch (ValidationException $e) {
            $this->gridHelper->pushValidationException($e);

            throw new B2bControllerForwardException('new');
        }

        throw new B2bControllerForwardException('detail', null, null, ['id' => $role->id]);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function detailAction(Request $request): array
    {
        $id = (int) $request->requireParam('id');

        return ['role' => $this->roleRepository->fetchOneById($id)];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function editAction(Request $request): array
    {
        $id = (int) $request->requireParam('id');

        $validationData = $this->gridHelper->getValidationResponse('role');

        return array_merge([
            'role' => $this->roleRepository->fetchOneById($id),
        ], $validationData);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function updateAction(Request $request)
    {
        $post = $request->getPost();

        $post['debtorEmail'] = $this->authenticationService->getIdentity()->getOwnershipContext()->shopOwnerEmail;
        $serviceRequest = $this->roleCrudService->createExistingRecordRequest($post);

        try {
            $this->roleCrudService->update($serviceRequest);
        } catch (ValidationException $e) {
            $this->gridHelper->pushValidationException($e);
        }

        throw new B2bControllerForwardException('edit', null, null, ['id' => $post['id']]);
    }
}
