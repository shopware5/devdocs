<?php declare(strict_types=1);

namespace SwagB2bPlugin\Resources\DependencyInjection;

use Shopware\B2B\Acl\Framework\DependencyInjection\AclFrameworkConfiguration;
use Shopware\B2B\AclRoute\Framework\DependencyInjection\AclRouteFrameworkConfiguration;
use Shopware\B2B\Address\Frontend\DependencyInjection\AddressFrontendConfiguration;
use Shopware\B2B\AuditLog\Framework\DependencyInjection\AuditLogFrameworkConfiguration;
use Shopware\B2B\Cart\Framework\DependencyInjection\CartFrameworkConfiguration;
use Shopware\B2B\Common\Controller\DependencyInjection\ControllerConfiguration;
use Shopware\B2B\Common\DependencyInjectionConfiguration;
use Shopware\B2B\Contact\Api\DependencyInjection\ContactApiConfiguration;
use Shopware\B2B\Contact\Frontend\DependencyInjection\ContactFrontendConfiguration;
use Shopware\B2B\ContingentGroup\Framework\DependencyInjection\ContingentGroupFrameworkConfiguration;
use Shopware\B2B\ContingentGroup\Frontend\DependencyInjection\ContingentGroupFrontendConfiguration;
use Shopware\B2B\ContingentGroupContact\Freontend\DependencyInjection\ContingentGroupContactFrontendConfiguration;
use Shopware\B2B\ContingentRule\Frontend\DependencyInjection\ContingentRuleFrontendConfiguration;
use Shopware\B2B\Debtor\Framework\DependencyInjection\DebtorFrameworkConfiguration;
use Shopware\B2B\LineItemList\Frontend\DependencyInjection\LineItemListFrontendConfiguration;
use Shopware\B2B\Order\Framework\DependencyInjection\OrderFrameworkConfiguration;
use Shopware\B2B\Order\Frontend\DependencyInjection\OrderFrontendConfiguration;
use Shopware\B2B\OrderClearance\Frontend\DependencyInjection\OrderClearanceFrontendConfiguration;
use Shopware\B2B\Price\Framework\DependencyInjection\PriceFrameworkConfiguration;
use Shopware\B2B\Role\Api\DependencyInjection\RoleApiConfiguration;
use Shopware\B2B\Role\Frontend\DependencyInjection\RoleFrontendConfiguration;
use Shopware\B2B\RoleContact\Frontend\DependencyInjection\RoleContactFrontendConfiguration;
use Shopware\B2B\RoleContingentGroup\Frontend\DependencyInjection\RoleContingentGroupFrontendConfiguration;
use Shopware\B2B\Shop\Frontend\DependencyInjection\ShopFrontendConfiguration;
use Shopware\B2B\StoreFrontAuthentication\Framework\DependencyInjection\StoreFrontAuthenticationFrameworkConfiguration;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;

class SwagB2bPluginConfiguration extends DependencyInjectionConfiguration
{
    /**
     * @return string[]
     */
    public function getServiceFiles(): array
    {
        return [
            __DIR__ . '/plugin-services.xml',
        ];
    }

    /**
     * @return CompilerPassInterface[]
     */
    public function getCompilerPasses(): array
    {
        return [];
    }

    /**
     * @return DependencyInjectionConfiguration[]
     */
    public function getDependingConfigurations(): array
    {
        return [
            new AclFrameworkConfiguration(),
            new AclRouteFrameworkConfiguration(),
            new AddressFrontendConfiguration(),
            new AuditLogFrameworkConfiguration(),
            new CartFrameworkConfiguration(),
            new ContactFrontendConfiguration(),
            new ContactApiConfiguration(),
            new ControllerConfiguration(),
            new ContingentGroupFrontendConfiguration(),
            new ContingentGroupContactFrontendConfiguration(),
            new ContingentRuleFrontendConfiguration(),
            new DebtorFrameworkConfiguration(),
            new OrderFrameworkConfiguration(),
            new OrderClearanceFrontendConfiguration(),
            new RoleFrontendConfiguration(),
            new RoleContactFrontendConfiguration(),
            new RoleApiConfiguration(),
            new ContingentGroupFrameworkConfiguration(),
            new RoleContingentGroupFrontendConfiguration(),
            new StoreFrontAuthenticationFrameworkConfiguration(),
            new CartFrameworkConfiguration(),
            new ShopFrontendConfiguration(),
            new OrderFrontendConfiguration(),
            new LineItemListFrontendConfiguration(),
            new PriceFrameworkConfiguration(),
        ];
    }
}
