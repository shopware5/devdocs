<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Framework;

use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Common\Service\AbstractCrudService;
use Shopware\B2B\Common\Service\CrudServiceRequest;
use Shopware\B2B\Common\Validator\ValidationException;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;
use Symfony\Component\Validator\ConstraintViolation;
use Symfony\Component\Validator\ConstraintViolationList;

class ContactCrudService extends AbstractCrudService
{
    /**
     * @var ContactRepository
     */
    private $contactRepository;

    /**
     * @var ContactValidationService
     */
    private $validationService;

    /**
     * @var AclRepository
     */
    private $aclRepository;

    /**
     * @var ContactPasswordProviderInterface
     */
    private $passwordProvider;

    /**
     * @param ContactRepository $contactRepository
     * @param ContactValidationService $validationService
     * @param AclRepository $aclRepository
     * @param ContactPasswordProviderInterface $passwordProvider
     */
    public function __construct(
        ContactRepository $contactRepository,
        ContactValidationService $validationService,
        AclRepository $aclRepository,
        ContactPasswordProviderInterface $passwordProvider
    ) {
        $this->contactRepository = $contactRepository;
        $this->validationService = $validationService;
        $this->aclRepository = $aclRepository;
        $this->passwordProvider = $passwordProvider;
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createNewRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'passwordNew',
                'passwordRepeat',
                'password',
                'encoder',
                'email',
                'active',
                'language',
                'title',
                'salutation',
                'firstName',
                'lastName',
                'debtorEmail',
                'department',
            ]
        );
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createExistingRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'id',
                'passwordNew',
                'passwordRepeat',
                'password',
                'encoder',
                'email',
                'active',
                'language',
                'title',
                'salutation',
                'firstName',
                'lastName',
                'debtorEmail',
                'department',
            ]
        );
    }

    /**
     * @param CrudServiceRequest $request
     * @param Identity $identity
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @return ContactEntity
     */
    public function create(CrudServiceRequest $request, Identity $identity): ContactEntity
    {
        $data = $request->getFilteredData();

        $contact = new ContactEntity();

        $contact->setData($data);

        $this->checkPassword($contact, $request, true);
        $this->passwordProvider->setPassword($contact, $request->requireParam('passwordNew'));

        $validation = $this->validationService
            ->createInsertValidation($contact);

        $this->testValidation($contact, $validation);

        $this->contactRepository
            ->addContact($contact);

        $contact = $this->contactRepository
            ->fetchOneByEmail($contact->email);

        $this->aclRepository
            ->allowAll(
                $contact,
                [
                    $identity->getMainShippingAddress()->id,
                    $identity->getMainBillingAddress()->id,
                ]
            );

        return $contact;
    }

    /**
     * @param CrudServiceRequest $request
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @return ContactEntity
     */
    public function update(CrudServiceRequest $request): ContactEntity
    {
        $data = $request->getFilteredData();
        $contact = new ContactEntity();
        $contact->setData($data);

        $this->checkPassword($contact, $request, false);

        if ($request->hasValueForParam('passwordNew')) {
            $this->passwordProvider->setPassword($contact, $request->requireParam('passwordNew'));
        }

        $validation = $this->validationService
            ->createUpdateValidation($contact);

        $this->testValidation($contact, $validation);

        $this->contactRepository
            ->updateContact($contact);

        return $contact;
    }

    /**
     * @param CrudServiceRequest $request
     * @return ContactEntity
     */
    public function remove(CrudServiceRequest $request): ContactEntity
    {
        $data = $request->getFilteredData();
        $contact = new ContactEntity();
        $contact->setData($data);

        $this->contactRepository
            ->removeContact($contact);

        return $contact;
    }

    /**
     * @param ContactEntity $contact
     * @param CrudServiceRequest $request
     * @param bool $required
     */
    private function checkPassword(ContactEntity $contact, CrudServiceRequest $request, bool $required)
    {
        if ($this->hasAnyPasswordSet($request)) {
            if ($required) {
                $this->throwPasswordRequiredException($contact);
            }

            return;
        }

        if ($this->hasMatchingPasswords($request)) {
            $this->throwPasswordNotMatchingException($contact);
        }
    }

    /**
     * @param ContactEntity $contact
     */
    private function throwPasswordNotMatchingException(ContactEntity $contact)
    {
        $violation = new ConstraintViolation(
            'The password is not equal to the repeated password.',
            '',
            [],
            '',
            '',
            '',
            null
        );

        $violationList = new ConstraintViolationList([$violation]);

        throw new ValidationException($contact, $violationList, 'Validation violations detected, can not proceed:', 400);
    }

    /**
     * @param ContactEntity $contact
     */
    private function throwPasswordRequiredException(ContactEntity $contact)
    {
        $violation = new ConstraintViolation(
            'A password is required.',
            '',
            [],
            '',
            '',
            '',
            null
        );

        $violationList = new ConstraintViolationList([$violation]);

        throw new ValidationException($contact, $violationList, 'Validation violations detected, can not proceed:', 400);
    }

    /**
     * @param CrudServiceRequest $request
     * @return bool
     */
    private function hasAnyPasswordSet(CrudServiceRequest $request): bool
    {
        return (!$request->hasValueForParam('passwordNew') && !$request->hasValueForParam('passwordRepeat'));
    }

    /**
     * @param CrudServiceRequest $request
     * @return bool
     */
    private function hasMatchingPasswords(CrudServiceRequest $request): bool
    {
        return !$request->hasValueForParam('passwordNew') ||
            !$request->hasValueForParam('passwordRepeat') ||
            $request->requireParam('passwordNew') !== $request->requireParam('passwordRepeat');
    }
}
