<?php declare(strict_types=1);

namespace Shopware\B2B\AclRoute\Frontend;

use Shopware\B2B\Acl\Framework\AclAccessExtensionService;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\AclRoute\Framework\AclRouteEntity;
use Shopware\B2B\AclRoute\Framework\AclRouteRepository;
use Shopware\B2B\AclRoute\Framework\AclRouteService;
use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Entity;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

/**
 * Base implementation of role assignment controller
 */
abstract class AssignmentController
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var AclRouteRepository
     */
    private $aclRouteRepository;

    /**
     * @var  AclRepository
     */
    private $aclRouteAclRepository;

    /**
     * @var AclAccessExtensionService
     */
    private $aclAccessExtensionService;

    /**
     * @var AclRouteService
     */
    private $aclRouteService;

    /**
     * @param AuthenticationService $authenticationService
     * @param AclRouteRepository $aclRouteRepository
     * @param AclRepository $aclRouteAclRepository
     * @param AclAccessExtensionService $aclAccessExtensionService
     * @param AclRouteService $aclRouteService
     */
    public function __construct(
        AuthenticationService $authenticationService,
        AclRouteRepository $aclRouteRepository,
        AclRepository $aclRouteAclRepository,
        AclAccessExtensionService $aclAccessExtensionService,
        AclRouteService $aclRouteService
    ) {
        $this->aclRouteRepository = $aclRouteRepository;
        $this->aclRouteAclRepository = $aclRouteAclRepository;
        $this->aclAccessExtensionService = $aclAccessExtensionService;
        $this->aclRouteService = $aclRouteService;
        $this->authenticationService = $authenticationService;
    }

    /**
     * @param int $id
     * @return Entity
     */
    abstract protected function getContextEntity(int $id): Entity;

    /**
     * @return string
     */
    abstract protected function getContextParameterName(): string;

    /**
     * @param Request $request
     * @return array
     */
    public function indexAction(Request $request): array
    {
        return [
            $this->getContextParameterName() => $request->requireParam($this->getContextParameterName()),
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $id = (int) $request->requireParam($this->getContextParameterName());

        $contextEntity = $this->getContextEntity($id);

        $ownership = $this->authenticationService->getIdentity()
            ->getOwnershipContext();

        $privilegeList = $this->aclRouteRepository
            ->fetchControllerList();

        $this->aclAccessExtensionService
            ->extendEntitiesWithAssignment($this->aclRouteAclRepository, $contextEntity, $privilegeList);

        $this->aclAccessExtensionService
            ->extendEntitiesWithIdentityOwnership($this->aclRouteAclRepository, $ownership, $privilegeList);

        $privilegeGrid = $this->transformPrivilegeListToGrid($privilegeList);

        return [
            'privilegeGrid' => $privilegeGrid,
            'actions' => $this->aclRouteService->getPrivilegeTypes(),
            $this->getContextParameterName() => $id,
        ];
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function assignAction(Request $request)
    {
        $request->checkPost('index', [$this->getContextParameterName() => $request->requireParam($this->getContextParameterName())]);

        $post = $request->getPost();

        $contextEntity = $this->getContextEntity((int) $post[$this->getContextParameterName()]);

        if ($request->getParam('allow', false)) {
            $this->aclRouteAclRepository->allow($contextEntity, (int) $post['routeId'], (bool) $request->getParam('grantable', false));
        } else {
            $this->aclRouteAclRepository->deny($contextEntity, (int) $post['routeId']);
        }

        throw new B2bControllerForwardException(
            'grid',
            null,
            null,
            [$this->getContextParameterName() => $post[$this->getContextParameterName()]]
        );
    }

    /**
     * @param AclRouteEntity[] $privilegeList
     * @return array
     */
    private function transformPrivilegeListToGrid(array $privilegeList): array
    {
        $grid = [];

        foreach ($privilegeList as $privilege) {
            if (!isset($grid[$privilege->resource_name])) {
                $grid[$privilege->resource_name] = [];
            }

            $grid[$privilege->resource_name][$privilege->privilege_type] = $privilege;
        }

        return $grid;
    }
}
