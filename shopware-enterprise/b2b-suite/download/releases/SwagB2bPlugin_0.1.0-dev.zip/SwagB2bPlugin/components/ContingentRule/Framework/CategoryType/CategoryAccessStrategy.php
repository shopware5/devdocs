<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\CategoryType;

use Shopware\B2B\Cart\Framework\CartAccessContext;
use Shopware\B2B\Cart\Framework\CartAccessStrategyInterface;
use Shopware\B2B\Cart\Framework\MessageCollection;
use Shopware\B2B\OrderClearance\Framework\OrderProductItem;
use Shopware\B2B\Shop\Framework\CategoryRepositoryInterface;

class CategoryAccessStrategy implements CartAccessStrategyInterface
{
    /**
     * @var int
     */
    private $categoryId;

    /**
     * @var CategoryRepositoryInterface
     */
    private $categoryRepository;

    /**
     * @param int $categoryId
     * @param CategoryRepositoryInterface $categoryRepository
     */
    public function __construct(int $categoryId, CategoryRepositoryInterface $categoryRepository)
    {
        $this->categoryId = $categoryId;
        $this->categoryRepository = $categoryRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function isAllowed(CartAccessContext $context, MessageCollection $messageCollection): bool
    {
        $products = $context->orderClearanceEntity
            ->getItemsOfType(OrderProductItem::class);

        $allowed = true;
        foreach ($products as $product) {
            if ($this->categoryRepository->hasProduct($this->categoryId, $product->identifier)) {
                $allowed = false;
            }
        }

        if ($allowed) {
            return true;
        }

        $category = $this->categoryRepository
            ->fetchNodeById($this->categoryId);

        $messageCollection->addError(
            __CLASS__,
            'CategoryError',
            [
                'allowedValue' => $category->name,
            ]
        );

        return false;
    }
}
