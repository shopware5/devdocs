<?php declare(strict_types=1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

class OwnershipContext
{
    /**
     * @var string
     */
    public $shopOwnerEmail;

    /**
     * @var int
     */
    public $shopOwnerUserId;

    /**
     * @var int
     */
    public $identityId;

    /**
     * @var string
     */
    public $identityClassName;

    /**
     * @param string $shopOwnerEmail
     * @param int $shopOwnerUserId
     * @param int $identityId
     * @param string $identityClassName
     */
    public function __construct(string $shopOwnerEmail, int $shopOwnerUserId, int $identityId, string $identityClassName)
    {
        $this->shopOwnerEmail = $shopOwnerEmail;
        $this->shopOwnerUserId = $shopOwnerUserId;
        $this->identityId = $identityId;
        $this->identityClassName = $identityClassName;
    }
}
