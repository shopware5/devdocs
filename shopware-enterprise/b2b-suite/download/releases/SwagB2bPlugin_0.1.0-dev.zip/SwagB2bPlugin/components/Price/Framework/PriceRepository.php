<?php declare(strict_types=1);

namespace Shopware\B2B\Price\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\CrudEntity;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException;
use Shopware\B2B\Common\Repository\NotFoundException;

class PriceRepository
{
    const TABLE_NAME = 'b2b_prices';
    const TABLE_ALIAS = 'price';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(
        Connection $connection
    ) {
        $this->connection = $connection;
    }

    /**
     * @param int $debtorId
     * @param string $orderNumber
     * @param int $quantity
     * @throws NotFoundException
     * @return CrudEntity
     */
    public function fetchPriceByDebtorIdAndOrderNumberAndQuantity(int $debtorId, string $orderNumber, int $quantity): CrudEntity
    {
        $priceData = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*, details.ordernumber')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.debtor_id = :id')
            ->innerJoin(self::TABLE_ALIAS, 's_articles_details', 'details', 'details.id = ' . self::TABLE_ALIAS . '.articles_details_id')
            ->where('details.ordernumber = :number')
            ->andWhere(self::TABLE_ALIAS . '.from <= :quantity')
            ->andWhere(self::TABLE_ALIAS . '.to >= :quantity or IFNULL(' . self::TABLE_ALIAS . '.to, 0) = 0')
            ->orderBy(self::TABLE_ALIAS . '.from', 'ASC')
            ->setMaxResults(1)
            ->setParameter('quantity', $quantity)
            ->setParameter('id', $debtorId)
            ->setParameter('number', $orderNumber)
            ->execute()->fetch(\PDO::FETCH_ASSOC);

        if (empty($priceData)) {
            throw new NotFoundException('Unable to locate price');
        }

        $price = new PriceEntity();

        return $price->fromDatabaseArray($priceData);
    }

    /**
     * @param int $debtorId
     * @param array $orderNumbers
     * @return PriceEntity[]
     */
    public function fetchPricesByDebtorIdAndOrdernumber(int $debtorId, array $orderNumbers): array
    {
        $pricesData = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*, details.ordernumber')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.debtor_id = :id')
            ->innerJoin(self::TABLE_ALIAS, 's_articles_details', 'details', 'details.id = ' . self::TABLE_ALIAS . '.articles_details_id')
            ->where('details.ordernumber IN (:orderNumbers)')
            ->setParameter('id', $debtorId)
            ->setParameter('orderNumbers', $orderNumbers, Connection::PARAM_STR_ARRAY)
            ->execute()->fetchAll();

        $prices = [];
        foreach ($pricesData as $price) {
            $prices[] = (new PriceEntity())->fromDatabaseArray($price);
        }

        return $prices;
    }

    /**
     * @param PriceEntity $priceEntity
     * @throws CanNotInsertExistingRecordException
     * @return PriceEntity
     */
    public function addPrice(PriceEntity $priceEntity): PriceEntity
    {
        if (!$priceEntity->isNew()) {
            throw new CanNotInsertExistingRecordException('The price provided already exists');
        }

        $this->connection->createQueryBuilder()
            ->insert(self::TABLE_NAME)
            ->setValue('debtor_id', $priceEntity->debtorId)
            ->setValue('`from`', $priceEntity->from)
            ->setValue('price', $priceEntity->price)
            ->setValue('`to`', $priceEntity->to)
            ->setValue('articles_details_id', $priceEntity->articleDetailId)
            ->execute();

        $priceEntity->id = (int) $this->connection->lastInsertId();

        return $priceEntity;
    }

    /**
     * @param PriceEntity $priceEntity
     * @throws CanNotRemoveExistingRecordException
     * @return PriceEntity
     */
    public function removePrice(PriceEntity $priceEntity): PriceEntity
    {
        if ($priceEntity->isNew()) {
            throw new CanNotRemoveExistingRecordException('The price provided does not exist');
        }

        $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $priceEntity->id]
        );

        $priceEntity->id = null;

        return $priceEntity;
    }

    /**
     * @param PriceEntity $priceEntity
     * @throws CanNotUpdateExistingRecordException
     * @return PriceEntity
     */
    public function updatePrice(PriceEntity $priceEntity): PriceEntity
    {
        if ($priceEntity->isNew()) {
            throw new CanNotUpdateExistingRecordException('The price provided does not exist');
        }

        $qb = $this->connection->createQueryBuilder();

        $qb->update(self::TABLE_NAME)
            ->set('debtor_id', $priceEntity->debtorId)
            ->set('`from`', $priceEntity->from)
            ->set('price', $priceEntity->price)
            ->set('`to`', $priceEntity->to)
            ->set('articles_details_id', $priceEntity->articleDetailId)
            ->where($qb->expr()->eq('id', ':id'))
            ->setParameter('id', $priceEntity->id)
            ->execute();

        return $priceEntity;
    }

    /**
     * @param PriceEntity $priceEntity
     * @return bool
     */
    public function checkForUniquePriceToRange(PriceEntity $priceEntity): bool
    {
        $isUnique = (bool) $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where('`from` >=' .  $priceEntity->to . ' AND ' . '`to` <=' .  $priceEntity->to)
            ->where('debtor_id =' . $priceEntity->debtorId)
            ->where('articles_details_id', $priceEntity->articleDetailId)
            ->execute();

        return $isUnique;
    }

    /**
     * @param PriceEntity $priceEntity
     * @return bool
     */
    public function checkForUniquePriceFromRange(PriceEntity $priceEntity): bool
    {
        $isUnique = (bool) $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where('`from` >=' .  $priceEntity->from . ' AND ' . '`to` <=' . $priceEntity->from)
            ->where('debtor_id =' . $priceEntity->debtorId)
            ->where('articles_details_id', $priceEntity->articleDetailId)
            ->execute();

        return $isUnique;
    }
}
