<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentGroup\Framework;

use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Acl\Framework\AclUnsupportedContextException;
use Shopware\B2B\Common\Service\AbstractCrudService;
use Shopware\B2B\Common\Service\CrudServiceRequest;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class ContingentGroupCrudService extends AbstractCrudService
{
    /**
     * @var ContingentGroupRepository
     */
    private $contingentGroupRepository;

    /**
     * @var ContingentGroupValidationService
     */
    private $groupValidationService;

    /**
     * @var AclRepository
     */
    private $aclRepository;

    /**
     * @param ContingentGroupRepository $contingentGroupRepository
     * @param ContingentGroupValidationService $groupValidationService
     * @param AclRepository $aclRepository
     */
    public function __construct(
        ContingentGroupRepository $contingentGroupRepository,
        ContingentGroupValidationService $groupValidationService,
        AclRepository $aclRepository
    ) {
        $this->contingentGroupRepository = $contingentGroupRepository;
        $this->groupValidationService = $groupValidationService;
        $this->aclRepository = $aclRepository;
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createNewRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'name',
                'description',
            ]
        );
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createExistingRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'id',
                'name',
                'description',
            ]
        );
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @return ContingentGroupEntity
     */
    public function create(CrudServiceRequest $request, OwnershipContext $ownershipContext): ContingentGroupEntity
    {
        $data = $request->getFilteredData();
        $data['sUserId'] = $ownershipContext->shopOwnerUserId;

        $contingent = new ContingentGroupEntity();

        $contingent->setData($data);

        $validation = $this->groupValidationService
            ->createInsertValidation($contingent);

        $this->testValidation($contingent, $validation);

        $contingentGroup = $this->contingentGroupRepository
            ->addContingentGroup($contingent);

        try {
            $this->aclRepository->allow(
                $ownershipContext,
                (int) $contingentGroup->id
            );
        } catch (AclUnsupportedContextException $e) {
            return $contingentGroup;
        }

        return $contingentGroup;
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return ContingentGroupEntity
     */
    public function update(CrudServiceRequest $request, OwnershipContext $ownershipContext): ContingentGroupEntity
    {
        $data = $request->getFilteredData();
        $contingentGroup = new ContingentGroupEntity();
        $contingentGroup->setData($data);
        $contingentGroup->id = (int) $contingentGroup->id;
        $contingentGroup->sUserId = $ownershipContext->shopOwnerUserId;

        $validation = $this->groupValidationService
            ->createUpdateValidation($contingentGroup);

        $this->testValidation($contingentGroup, $validation);

        $this->contingentGroupRepository
            ->updateContingentGroup($contingentGroup);

        return $contingentGroup;
    }

    /**
     * @param CrudServiceRequest $request
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveUsedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return ContingentGroupEntity
     */
    public function remove(CrudServiceRequest $request): ContingentGroupEntity
    {
        $data = $request->getFilteredData();
        $contingentGroup = new ContingentGroupEntity();
        $contingentGroup->setData($data);

        $this->contingentGroupRepository
            ->removeContingentGroup($contingentGroup);

        return $contingentGroup;
    }
}
