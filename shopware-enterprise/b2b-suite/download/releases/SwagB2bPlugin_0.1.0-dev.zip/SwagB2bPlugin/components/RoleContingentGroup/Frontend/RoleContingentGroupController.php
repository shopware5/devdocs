<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContingentGroup\Frontend;

use Shopware\B2B\Acl\Framework\AclAccessExtensionService;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupRepository;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupSearchStruct;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\RoleContingentGroup\Framework\RoleContingentGroupAssignmentService;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class RoleContingentGroupController
{
    /**
     * @var RoleContingentGroupAssignmentService
     */
    private $roleContingentGroupAssignmentService;

    /**
     * @var  AclRepository
     */
    private $roleContingentGroupAclRepository;

    /**
     * @var ContingentGroupRepository
     */
    private $contingentGroupRepository;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @var AclAccessExtensionService
     */
    private $aclAccessExtensionService;

    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @param RoleContingentGroupAssignmentService $roleContingentGroupAssignmentService
     * @param AclRepository $roleContingentGroupAclRepository
     * @param ContingentGroupRepository $contingentGroupRepository
     * @param GridHelper $gridHelper
     * @param AclAccessExtensionService $aclAccessExtensionService
     * @param RoleRepository $roleRepository
     * @param AuthenticationService $authenticationService
     */
    public function __construct(
        AuthenticationService $authenticationService,
        RoleContingentGroupAssignmentService $roleContingentGroupAssignmentService,
        AclRepository $roleContingentGroupAclRepository,
        ContingentGroupRepository $contingentGroupRepository,
        GridHelper $gridHelper,
        AclAccessExtensionService $aclAccessExtensionService,
        RoleRepository $roleRepository
    ) {
        $this->roleContingentGroupAssignmentService = $roleContingentGroupAssignmentService;
        $this->roleContingentGroupAclRepository = $roleContingentGroupAclRepository;
        $this->contingentGroupRepository = $contingentGroupRepository;
        $this->gridHelper = $gridHelper;
        $this->aclAccessExtensionService = $aclAccessExtensionService;
        $this->roleRepository = $roleRepository;
        $this->authenticationService = $authenticationService;
    }

    /**
     * @param Request $request
     * @return array
     */
    public function indexAction(Request $request): array
    {
        return ['roleId' => $request->requireParam('roleId')];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $roleId = (int) $request->requireParam('roleId');
        $role = $this->roleRepository->fetchOneById($roleId);

        $searchStruct = new ContingentGroupSearchStruct();

        $ownershipContext = $this->authenticationService->getIdentity()->getOwnershipContext();

        $this->gridHelper->extractSearchDataInStoreFront($request, $searchStruct);

        $contingentGroups = $this->contingentGroupRepository
            ->fetchAllContingentGroupsWithCheckForRoleAssignment($ownershipContext, $searchStruct, $roleId);

        $this->aclAccessExtensionService
            ->extendEntitiesWithAssignment($this->roleContingentGroupAclRepository, $role, $contingentGroups);

        $this->aclAccessExtensionService
            ->extendEntitiesWithIdentityOwnership(
                $this->roleContingentGroupAclRepository,
                $ownershipContext,
                $contingentGroups
            );

        $contingentGroupsCount = $this->contingentGroupRepository->fetchTotalCount($ownershipContext, $searchStruct);

        $maxPage = $this->gridHelper->getMaxPage($contingentGroupsCount);

        $currentPage = (int) $this->gridHelper->getCurrentPage($request);

        $gridState = $this->gridHelper
            ->getGridState($request, $searchStruct, $contingentGroups, $maxPage, $currentPage);

        return [
            'roleId' => $roleId,
            'gridState' => $gridState,
        ];
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function assignAction(Request $request)
    {
        $request->checkPost('index', ['roleId' => $request->requireParam('roleId')]);

        $contingentId = (int) $request->requireParam('contingentGroupId');
        $roleId = (int) $request->requireParam('roleId');
        $role = $this->roleRepository->fetchOneById($roleId);

        if (!$request->getParam('allow')) {
            $this->roleContingentGroupAssignmentService->removeAssignment($roleId, $contingentId);
            $this->roleContingentGroupAclRepository->deny($role, $contingentId);

            throw new B2bControllerForwardException('grid', null, null, ['roleId' => $roleId]);
        }

        $this->roleContingentGroupAclRepository->allow($role, $contingentId, (bool) $request->getParam('grantable'));

        if (!$request->getParam('assignmentId')) {
            $this->roleContingentGroupAssignmentService->assign($roleId, $contingentId);
        }

        throw new B2bControllerForwardException('grid', null, null, ['roleId' => $roleId]);
    }
}
