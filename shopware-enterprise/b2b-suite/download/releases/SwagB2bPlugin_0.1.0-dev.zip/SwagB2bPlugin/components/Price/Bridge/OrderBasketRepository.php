<?php declare(strict_types=1);

namespace Shopware\B2B\Price\Bridge;

use Doctrine\DBAL\Connection;

class OrderBasketRepository
{
    const TABLE_NAME = 's_order_basket';
    const TABLE_ALIAS = 'ob';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(
        Connection $connection
    ) {
        $this->connection = $connection;
    }

    /**
     * @param int $id
     * @return string
     */
    public function fetchOrderNumberById(int $id): string
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('ordernumber')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where('id = :id')
            ->setParameter('id', $id)
            ->execute();

        return $statement->fetchColumn();
    }
}
