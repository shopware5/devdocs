<?php declare(strict_types=1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

class AuthenticationService
{
    /**
     * @var AuthStorageAdapterInterface
     */
    private $authStorageAdapter;

    /**
     * @param AuthStorageAdapterInterface $authStorageAdapter
     */
    public function __construct(AuthStorageAdapterInterface $authStorageAdapter)
    {
        $this->authStorageAdapter = $authStorageAdapter;
    }

    /**
     * @return Identity
     */
    public function getIdentity(): Identity
    {
        if (!$this->isAuthenticated()) {
            throw new NotAuthenticatedException('Not authenticated, can not provide a valid identity.');
        }

        return $this->authStorageAdapter->getIdentity();
    }

    /**
     * @return bool
     */
    public function isAuthenticated(): bool
    {
        return $this->authStorageAdapter->isAuthenticated();
    }

    /**
     * @return bool
     */
    public function isB2b(): bool
    {
        try {
            $this->getIdentity();
        } catch (NotAuthenticatedException $e) {
            return false;
        } catch (NoIdentitySetException $e) {
            return false;
        }

        return true;
    }

    /**
     * @param $className
     * @return bool
     */
    public function is($className): bool
    {
        if (!$this->isB2b()) {
            return false;
        }

        return $this->getIdentity() instanceof $className;
    }
}
