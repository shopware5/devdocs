<?php declare(strict_types=1);

namespace Shopware\B2B\Cart\Bridge;

use Enlight\Event\SubscriberInterface;
use sBasket;
use Shopware\B2B\Cart\Framework\CartService;
use Shopware\B2B\Cart\Framework\MessageCollection;
use Shopware\B2B\LineItemList\Bridge\LineItemCheckoutSource;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContextRepository;
use Shopware\B2B\LineItemList\Framework\LineItemListService;
use Shopware\B2B\Order\Bridge\OrderRepository;
use Shopware\B2B\OrderClearance\Bridge\OrderClearanceEntityFactory;
use Shopware\B2B\OrderClearance\Bridge\OrderClearanceRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class CartAccessSubscriber implements SubscriberInterface
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var sBasket
     */
    private $sBasket;

    /**
     * @var CartService
     */
    private $cartService;

    /**
     * @var MessageCollection
     */
    private $messageCollection;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var OrderClearanceRepository
     */
    private $orderClearanceRepository;

    /**
     * @var OrderClearanceEntityFactory
     */
    private $entityFactory;

    /**
     * @var LineItemListService
     */
    private $lineItemListService;

    /**
     * @var LineItemListOrderContextRepository
     */
    private $lineItemListOrderContextRepository;

    /**
     * @param AuthenticationService $authenticationService
     * @param CartService $cartService
     * @param OrderRepository $orderRepository
     * @param OrderClearanceRepository $orderClearanceRepository
     * @param OrderClearanceEntityFactory $entityFactory
     * @param LineItemListService $lineItemListService
     * @param sBasket $sBasket
     * @param MessageCollection $messageCollection
     * @param LineItemListOrderContextRepository $lineItemListOrderContextRepository
     */
    public function __construct(
        AuthenticationService $authenticationService,
        CartService $cartService,
        OrderRepository $orderRepository,
        OrderClearanceRepository $orderClearanceRepository,
        OrderClearanceEntityFactory $entityFactory,
        LineItemListService $lineItemListService,
        sBasket $sBasket,
        MessageCollection $messageCollection,
        LineItemListOrderContextRepository $lineItemListOrderContextRepository
    ) {
        $this->authenticationService = $authenticationService;
        $this->cartService = $cartService;
        $this->orderRepository = $orderRepository;
        $this->orderClearanceRepository = $orderClearanceRepository;
        $this->entityFactory = $entityFactory;
        $this->sBasket = $sBasket;
        $this->messageCollection = $messageCollection;
        $this->lineItemListService = $lineItemListService;
        $this->lineItemListOrderContextRepository = $lineItemListOrderContextRepository;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Enlight_Controller_Action_PostDispatchSecure_Frontend_Checkout' => 'addTemplateMessagesAndError',
            'sOrder::sSaveOrder::after' => [
                ['addLineItemList'],
                ['setOrderIdentity'],
                ['checkOrderClearance'],
                ['assignDebtorToOrder'],
            ],
        ];
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function assignDebtorToOrder(\Enlight_Hook_HookArgs $args)
    {
        $orderNumber = $args->getReturn();
        $args->setReturn($orderNumber);

        if (!$this->authenticationService->isB2b()) {
            return;
        }

        $debtorId = $this->authenticationService
            ->getIdentity()
            ->getOwnershipContext()->shopOwnerUserId;

        $this->orderRepository->setOrderToDebtor((string) $orderNumber, $debtorId);
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function addLineItemList(\Enlight_Hook_HookArgs $args)
    {
        $orderNumber = $args->getReturn();
        $args->setReturn($orderNumber);

        if (!$this->authenticationService->isB2b()) {
            return;
        }

        $identity = $this->authenticationService
            ->getIdentity();

        $checkoutListSource = new LineItemCheckoutSource(
            Shopware()->Modules()->Order()->sBasketData,
            (string) $orderNumber,
            (int) Shopware()->Modules()->Order()->sUserData['billingaddress']['id'],
            (int) Shopware()->Modules()->Order()->sUserData['shippingaddress']['id']
        );

        $this->lineItemListService
            ->createListThroughCheckoutSource(
                $identity->getOwnershipContext(),
                $checkoutListSource
            );
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function setOrderIdentity(\Enlight_Hook_HookArgs $args)
    {
        $orderNumber = $args->getReturn();
        $args->setReturn($orderNumber);

        if (!$this->authenticationService->isB2b()) {
            return;
        }

        $contactId = $this->authenticationService
            ->getIdentity()
            ->getId();

        $orderUserReference = $this->authenticationService
            ->getIdentity()
            ->getOrderCredentials()
            ->orderUserReference;

        $this->orderRepository->setOrderIdentity((string) $orderNumber, $contactId, $orderUserReference);
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function checkOrderClearance(\Enlight_Hook_HookArgs $args)
    {
        $orderNumber = $args->getReturn();
        $args->setReturn($orderNumber);

        if (!$this->authenticationService->isB2b()) {
            return;
        }

        if (!$this->isOrderAllowed()) {
            $orderContext = $this->lineItemListOrderContextRepository
                ->fetchOneOrderContextByOrderNumber((string) $orderNumber);

            $this->orderClearanceRepository->sendToOrderClearance($orderContext->id);
        }
    }

    /**
     * @param \Enlight_Event_EventArgs $args
     */
    public function addTemplateMessagesAndError(\Enlight_Event_EventArgs $args)
    {
        if (!$this->authenticationService->isB2b()) {
            return;
        }

        /** @var \Shopware_Controllers_Frontend_Checkout $subject */
        $subject = $args->getSubject();
        $subject->View()->assign('orderAllowed', $this->isOrderAllowed());
        $subject->View()->assign('orderErrorMessages', $this->getErrorMessages());
    }

    /**
     * @return bool
     */
    private function isOrderAllowed(): bool
    {
        $identity = $this->authenticationService->getIdentity();

        if ($identity->isSuperAdmin()) {
            return true;
        }

        $order = $this->entityFactory
            ->createOrderEntityFromBasketArray($this->sBasket->sGetBasket());

        return $this->cartService
            ->isAccessible(
                $identity,
                $order,
                $this->messageCollection
            );
    }

    /**
     * @return array
     */
    private function getErrorMessages(): array
    {
        return $this->messageCollection->getErrors();
    }
}
