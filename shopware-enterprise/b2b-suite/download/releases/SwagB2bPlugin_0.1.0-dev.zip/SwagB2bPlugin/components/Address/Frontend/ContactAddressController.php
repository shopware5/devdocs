<?php declare(strict_types=1);

namespace Shopware\B2B\Address\Frontend;

use Shopware\B2B\Acl\Framework\AclAccessExtensionService;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Address\Framework\AddressRepository;
use Shopware\B2B\Address\Framework\AddressSearchStruct;
use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class ContactAddressController
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var AddressRepository
     */
    private $addressRepository;

    /**
     * @var AclRepository
     */
    private $addressAclRepository;

    /**
     * @var ContactRepository
     */
    private $contactRepository;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @var AclAccessExtensionService
     */
    private $aclAccessExtensionService;

    /**
     * @param AuthenticationService     $authenticationService
     * @param AddressRepository         $addressRepository
     * @param AclRepository             $addressAclRepository
     * @param ContactRepository         $contactRepository
     * @param GridHelper                $gridHelper
     * @param AclAccessExtensionService $aclAccessExtensionService
     */
    public function __construct(
        AuthenticationService $authenticationService,
        AddressRepository $addressRepository,
        AclRepository $addressAclRepository,
        ContactRepository $contactRepository,
        GridHelper $gridHelper,
        AclAccessExtensionService $aclAccessExtensionService
    ) {
        $this->authenticationService = $authenticationService;
        $this->addressRepository = $addressRepository;
        $this->addressAclRepository = $addressAclRepository;
        $this->contactRepository = $contactRepository;
        $this->gridHelper = $gridHelper;
        $this->aclAccessExtensionService = $aclAccessExtensionService;
    }

    /**
     * @param Request $request
     * @return array
     */
    public function billingAction(Request $request): array
    {
        return ['email' => $request->requireParam('email')];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function shippingAction(Request $request): array
    {
        return ['email' => $request->requireParam('email')];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $contactEmail = $request->requireParam('email');
        $addressType = $request->requireParam('type');

        $contact = $this->contactRepository
            ->fetchOneByEmail($contactEmail);

        $searchStruct = new AddressSearchStruct();
        $this->gridHelper->extractSearchDataInStoreFront($request, $searchStruct);

        $ownership = $this->authenticationService->getIdentity()->getOwnershipContext();

        $addresses = $this->addressRepository
            ->fetchList($addressType, $ownership, $searchStruct);

        $this->aclAccessExtensionService
            ->extendEntitiesWithAssignment($this->addressAclRepository, $contact, $addresses);

        $this->aclAccessExtensionService
            ->extendEntitiesWithIdentityOwnership($this->addressAclRepository, $ownership, $addresses);

        $count = $this->addressRepository
            ->fetchTotalCount($addressType, $ownership, $searchStruct);

        $maxPage = $this->gridHelper->getMaxPage($count);
        $currentPage = $this->gridHelper->getCurrentPage($request);

        return [
            'gridState' => $this->gridHelper->getGridState($request, $searchStruct, $addresses, $maxPage, $currentPage),
            'type' => $addressType,
            'addresses' => $addresses,
            'contact' => $contact,
        ];
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function assignAction(Request $request)
    {
        $request->checkPost('billing', ['email' => $request->getParam('email')]);

        $post = $request->getPost();

        $contact = $this->contactRepository
            ->fetchOneById((int) $post['contactId']);

        if ($request->getParam('allow', false)) {
            $this->addressAclRepository->allow($contact, (int) $post['addressId'], (bool) $request->getParam('grantable', false));
        } else {
            $this->addressAclRepository->deny($contact, (int) $post['addressId']);
        }

        throw new B2bControllerForwardException('grid', null, null, ['email' => $post['email'], 'type' => $post['type']]);
    }
}
