<?php declare(strict_types=1);

namespace Shopware\B2B\Common\Frontend;

use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\B2bControllerRedirectException;
use Shopware\B2B\Common\MvcExtension\EnlightRequest;

abstract class ControllerProxy extends \Enlight_Controller_Action
{
    /**
     * @return string
     */
    abstract protected function getControllerDiKey(): string;

    /**
     * @return object
     */
    protected function getController()
    {
        return $this->get($this->getControllerDiKey());
    }

    /**
     * @param string $action
     */
    public function dispatch($action)
    {
        try {
            parent::dispatch($action);
        } catch (B2bControllerRedirectException $e) {
            $baseParams = [
                'action' => $e->getAction(),
                'controller' => $e->getController(),
                'module' => $e->getModule(),
            ];

            $this->redirect(array_merge($baseParams, $e->getParams()));

            return;
        } catch (B2bControllerForwardException $e) {
            $this->forward($e->getAction(), $e->getController(), $e->getModule(), $e->getParams());

            return;
        }
    }

    /**
     * @param string $name
     * @param null $value
     * @return mixed|void
     */
    public function __call($name, $value = null)
    {
        $controller = $this->getController();
        $isAction = 'Action' === substr($name, -6);
        $controllerHasAction = method_exists($controller, $name);

        if ($isAction && $controllerHasAction) {
            $this->View()->assign($controller->{$name}(new EnlightRequest($this->Request())));

            return;
        }

        return parent::__call($name, $value);
    }
}
