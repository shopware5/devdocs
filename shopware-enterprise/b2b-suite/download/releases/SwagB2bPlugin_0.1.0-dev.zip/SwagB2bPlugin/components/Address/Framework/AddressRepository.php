<?php declare(strict_types=1);

namespace Shopware\B2B\Address\Framework;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Acl\Framework\AclUnsupportedContextException;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotRemoveUsedRecordException;
use Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

/**
 * ACL enabled Address access and CRUD
 */
class AddressRepository implements GridRepository
{
    const TABLE_NAME = 's_user_addresses';

    const TABLE_ALIAS = 'address';

    const TABLE_ATTRIBUTES_NAME = 's_user_addresses_attributes';

    const TABLE_ATTRIBUTES_ALIAS = 'attributes';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @var AclRepository
     */
    private $aclRepository;

    /**
     * @var CountryRepositoryInterface
     */
    private $countryRepositoryInterface;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param AclRepository $aclRepository
     * @param CountryRepositoryInterface $countryRepositoryInterface
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        AclRepository $aclRepository,
        CountryRepositoryInterface $countryRepositoryInterface
    ) {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
        $this->aclRepository = $aclRepository;
        $this->countryRepositoryInterface = $countryRepositoryInterface;
    }

    /**
     * @return array
     */
    public function getCountryList(): array
    {
        return $this->countryRepositoryInterface->getCountryList();
    }

    /**
     * @param string $type
     * @param OwnershipContext $context
     * @param AddressSearchStruct $searchStruct
     * @throws \InvalidArgumentException
     * @return AddressEntity[]
     */
    public function fetchList(string $type, OwnershipContext $context, AddressSearchStruct $searchStruct): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->addSelect(
                '(SELECT COUNT(*) FROM s_user 
                    WHERE (
                        default_billing_address_id = ' . self::TABLE_ALIAS . '.id 
                        OR default_shipping_address_id = ' . self::TABLE_ALIAS . '.id
                    )
                ) as is_used'
            )
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->leftJoin(
                self::TABLE_ALIAS,
                self::TABLE_ATTRIBUTES_NAME,
                self::TABLE_ATTRIBUTES_ALIAS,
                self::TABLE_ALIAS . '.id = ' . self::TABLE_ATTRIBUTES_ALIAS . '.address_id'
            )
            ->where(self::TABLE_ATTRIBUTES_ALIAS . '.b2b_type = :type')
            ->andWhere(self::TABLE_ALIAS . '.user_id = :owner')
            ->setParameter('owner', $context->shopOwnerUserId)
            ->setParameter('type', $type);

        $this->applyAcl($context, $query);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper->applySearchStruct($searchStruct, $query);

        $statement = $query->execute();

        $addressesData = $statement
            ->fetchAll(\PDO::FETCH_ASSOC);

        $addresses = [];
        foreach ($addressesData as $addressData) {
            $addresses[] = (new AddressEntity())->fromDatabaseArray($addressData);
        }

        return $addresses;
    }

    /**
     * @param string $type
     * @param OwnershipContext $context
     * @param AddressSearchStruct $addressSearchStruct
     * @return int
     */
    public function fetchTotalCount(
        string $type,
        OwnershipContext $context,
        AddressSearchStruct $addressSearchStruct
    ): int {
        $query = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->innerJoin(
                self::TABLE_ALIAS,
                self::TABLE_ATTRIBUTES_NAME,
                self::TABLE_ATTRIBUTES_ALIAS,
                self::TABLE_ALIAS . '.id = ' . self::TABLE_ATTRIBUTES_ALIAS . '.address_id'
            )
            ->where(self::TABLE_ATTRIBUTES_ALIAS . '.b2b_type = :type')
            ->andWhere(self::TABLE_ALIAS . '.user_id = :owner')
            ->setParameter('owner', $context->shopOwnerUserId)
            ->setParameter('type', $type);

        $this->applyAcl($context, $query);
        $this->dbalHelper->applyFilters($addressSearchStruct, $query);

        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * @param int $id
     * @param null|string $addressType optionally filter for a specific type
     * @throws NotFoundException
     * @return AddressEntity
     */
    public function fetchOneById(int $id, string $addressType = null): AddressEntity
    {
        $queryBuilder = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->addSelect(
                '(SELECT COUNT(*) FROM s_user 
                 WHERE default_billing_address_id = ' . self::TABLE_ALIAS . '.id 
                 OR default_shipping_address_id = ' . self::TABLE_ALIAS . '.id) as is_used'
            )
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->setParameter('id', $id);

        if ($addressType) {
            $queryBuilder
                ->innerJoin(
                    self::TABLE_ALIAS,
                    self::TABLE_ATTRIBUTES_NAME,
                    self::TABLE_ATTRIBUTES_ALIAS,
                    self::TABLE_ALIAS . '.id = ' . self::TABLE_ATTRIBUTES_ALIAS . '.address_id'
                )
                ->andWhere(self::TABLE_ATTRIBUTES_ALIAS . '.b2b_type = :addressType')
                ->setParameter('addressType', $addressType);
        }

        $statement = $queryBuilder->execute();

        $addressData = $statement->fetch(\PDO::FETCH_ASSOC);

        if (!$addressData) {
            throw new NotFoundException(sprintf('Unable to locate address with id "%s"', $id));
        }

        $address = new AddressEntity();

        return $address->fromDatabaseArray($addressData);
    }

    /**
     * @param int $id
     * @return mixed
     */
    public function fetchAttributesById(int $id): array
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_ATTRIBUTES_NAME, self::TABLE_ATTRIBUTES_ALIAS)
            ->where(self::TABLE_ATTRIBUTES_ALIAS . '.address_id = :id')
            ->setParameter('id', $id)
            ->execute();

        return $statement->fetch(\PDO::FETCH_ASSOC);
    }

    /**
     * @param AddressEntity $addressEntity
     * @param string $type
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @return AddressEntity
     */
    public function addAddress(AddressEntity $addressEntity, string $type): AddressEntity
    {
        if (!$addressEntity->isNew()) {
            throw new CanNotInsertExistingRecordException('The address provided already exists');
        }

        $this->connection->insert(
            self::TABLE_NAME,
            $addressEntity->toDatabaseArray()
        );

        $addressEntity->id = (int) $this->connection->lastInsertId();

        $this->connection->insert(
            self::TABLE_ATTRIBUTES_NAME,
            [
                'address_id' => $addressEntity->id,
                'b2b_type' => $type,
            ]
        );

        return $addressEntity;
    }

    /**
     * @param AddressEntity $addressEntity
     * @param string $type
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return AddressEntity
     */
    public function updateAddress(AddressEntity $addressEntity, string $type): AddressEntity
    {
        if ($addressEntity->isNew()) {
            throw new CanNotUpdateExistingRecordException('The address provided does not exist');
        }

        $this->connection->update(
            self::TABLE_NAME,
            $addressEntity->toDatabaseArray(),
            ['id' => $addressEntity->id]
        );

        $this->connection->update(
            self::TABLE_ATTRIBUTES_NAME,
            ['b2b_type' => $type],
            ['address_id' => $addressEntity->id]
        );

        return $addressEntity;
    }

    /**
     * @param AddressEntity $addressEntity
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveUsedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return AddressEntity
     */
    public function removeAddress(AddressEntity $addressEntity): AddressEntity
    {
        if ($addressEntity->isNew()) {
            throw new CanNotRemoveExistingRecordException('The address provided does not exist');
        }

        if ($this->isAddressUsed($addressEntity)) {
            throw new CanNotRemoveUsedRecordException('The address provided is in use');
        }

        $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $addressEntity->id]
        );

        $addressEntity->id = null;

        return $addressEntity;
    }

    /**
     * @return string query alias for filter construction
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'company',
            'department',
            'salutation',
            'title',
            'firstname',
            'lastname',
            'street',
            'zipcode',
            'city',
            'ustid',
            'phone',
            'additional_address_line1',
            'additional_address_line2',
        ];
    }

    /**
     * @param OwnershipContext $context
     * @param QueryBuilder $query
     */
    private function applyAcl(OwnershipContext $context, QueryBuilder $query)
    {
        try {
            $aclQuery = $this->aclRepository->getUnionizedSqlQuery($context);

            $query->innerJoin(
                self::TABLE_ALIAS,
                '(' . $aclQuery->sql . ')',
                'acl_query',
                self::TABLE_ALIAS . '.id = acl_query.referenced_entity_id'
            );

            foreach ($aclQuery->params as $name => $value) {
                $query->setParameter($name, $value);
            }
        } catch (AclUnsupportedContextException $e) {
            // nth
        }
    }

    /**
     * check if the given AddressEntity is in use
     *
     * @param AddressEntity $addressEntity
     * @return bool
     */
    private function isAddressUsed(AddressEntity $addressEntity): bool
    {
        return (bool) $this->connection->fetchColumn(
            'SELECT COUNT(*) FROM s_user
             WHERE default_billing_address_id = :id OR default_shipping_address_id = :id',
            [
                ':id' => (int) $addressEntity->id,
            ]
        );
    }
}
