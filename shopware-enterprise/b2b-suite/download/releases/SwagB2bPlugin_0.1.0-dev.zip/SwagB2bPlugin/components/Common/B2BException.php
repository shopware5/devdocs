<?php declare(strict_types=1);

namespace Shopware\B2B\Common;

interface B2BException extends \Throwable
{
}
