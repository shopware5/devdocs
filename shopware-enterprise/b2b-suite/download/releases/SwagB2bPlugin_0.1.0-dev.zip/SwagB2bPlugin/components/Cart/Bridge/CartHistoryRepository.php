<?php declare(strict_types=1);

namespace Shopware\B2B\Cart\Bridge;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Cart\Framework\CartHistory;
use Shopware\B2B\Cart\Framework\CartHistoryRepositoryInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class CartHistoryRepository implements CartHistoryRepositoryInterface
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * {@inheritdoc}
     */
    public function fetchHistory(
        array $timeRestrictions,
        OwnershipContext $ownershipContext
    ): array {
        $cartHistory = [];
        foreach ($timeRestrictions as $timeRestriction) {
            $orderHistory = $this->connection->fetchAssoc(
                'SELECT COUNT(*) AS orderQuantity, ROUND(SUM(invoice_amount_net)) AS orderAmount,
                 SUM((SELECT COUNT(*) FROM s_order_details WHERE orderID = sOrder.id AND modus = 0)) AS orderItemQuantity
                 FROM s_order sOrder                 
                 INNER JOIN s_user sUser ON sUser.id = sOrder.userID
                 INNER JOIN b2b_debtor_contact contact ON contact.email = sUser.email 
                 WHERE ' . $timeRestriction . '(ordertime) = ' . $timeRestriction . '(NOW())
                 AND contact.id = :identityId
                 AND sOrder.status >= 0
                 GROUP BY ' . $timeRestriction . '(ordertime)',
                [':identityId' => $ownershipContext->identityId]
            );

            /** @noinspection DisconnectedForeachInstructionInspection */
            $history = new CartHistory();
            $history->timeRestriction = $timeRestriction;

            if ($orderHistory) {
                $history->fromDatabaseArray($orderHistory);
            }

            $cartHistory[$timeRestriction] = $history;
        }

        return $cartHistory;
    }
}
