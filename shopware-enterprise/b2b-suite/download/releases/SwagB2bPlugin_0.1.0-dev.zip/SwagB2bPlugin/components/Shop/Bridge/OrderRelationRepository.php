<?php declare(strict_types=1);

namespace Shopware\B2B\Shop\Bridge;

use Doctrine\DBAL\Connection;

class OrderRelationRepository
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param int $shippingId
     * @return array
     */
    public function fetchShippingDataForId(int $shippingId): array
    {
        return $this->connection
            ->fetchAssoc('SELECT * FROM s_premium_dispatch WHERE id = :id', ['id' => $shippingId]);
    }

    /**
     * @param int $paymentId
     * @return array
     */
    public function fetchPaymentDataForId(int $paymentId): array
    {
        return $this->connection
            ->fetchAssoc('SELECT * FROM s_core_paymentmeans WHERE id = :id', ['id' => $paymentId]);
    }
}
