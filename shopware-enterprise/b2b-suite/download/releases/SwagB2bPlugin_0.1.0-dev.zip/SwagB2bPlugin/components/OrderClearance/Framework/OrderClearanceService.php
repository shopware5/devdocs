<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Framework;

use Shopware\B2B\AuditLog\Framework\AuditLogValueEntity;
use Shopware\B2B\Cart\Framework\CartService;
use Shopware\B2B\Cart\Framework\MessageCollection;
use Shopware\B2B\Common\Repository\NotAllowedRecordException;
use Shopware\B2B\OrderClearance\Bridge\OrderClearanceRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

class OrderClearanceService
{
    /**
     * @var OrderClearanceRepositoryInterface
     */
    private $orderClearanceRepository;

    /**
     * @var CartService
     */
    private $cartService;

    /**
     * @var MessageCollection
     */
    private $messageCollection;

    /**
     * @var OrderClearanceAuditLogService
     */
    private $auditLog;

    /**
     * @param OrderClearanceRepositoryInterface $orderClearanceRepository
     * @param CartService $cartService
     * @param MessageCollection $messageCollection
     * @param OrderClearanceAuditLogService $auditLog
     */
    public function __construct(
        OrderClearanceRepositoryInterface $orderClearanceRepository,
        CartService $cartService,
        MessageCollection $messageCollection,
        OrderClearanceAuditLogService $auditLog
    ) {
        $this->orderClearanceRepository = $orderClearanceRepository;
        $this->cartService = $cartService;
        $this->messageCollection = $messageCollection;
        $this->auditLog = $auditLog;
    }

    /**
     * @param Identity $identity
     * @return array
     */
    public function fetchAllOrderClearances(Identity $identity): array
    {
        $orders = $this->orderClearanceRepository
            ->fetchAllOrderClearances($identity);

        return array_filter($orders, function (OrderClearanceEntity $order) use ($identity): bool {
            try {
                $this->checkAllowed($order, $identity);
            } catch (NotAllowedRecordException $e) {
                return false;
            }

            return true;
        });
    }

    /**
     * @param Identity $identity
     * @param int $orderContextId
     * @param string $comment
     */
    public function acceptOrder(Identity $identity, int $orderContextId, string $comment)
    {
        $this->checkOrderAccess($identity, $orderContextId);

        $auditLogValue = $this
            ->createAuditLogValue(
                (string) OrderClearanceRepository::STATUS_ORDER_OPEN,
                (string) OrderClearanceRepository::STATUS_ORDER_CLEARANCE,
                $comment
            );

        $this->auditLog->createStatusChangeAuditLog(
            $orderContextId,
            $auditLogValue,
            $identity
        );

        $this->orderClearanceRepository
            ->acceptOrder($orderContextId, $comment);
    }

    /**
     * @param Identity $identity
     * @param int $orderContextId
     * @param string $comment
     */
    public function declineOrder(Identity $identity, int $orderContextId, string $comment)
    {
        $this->checkOrderAccess($identity, $orderContextId);

        $auditLogValue = $this
            ->createAuditLogValue(
                (string) OrderClearanceRepository::STATUS_ORDER_DENIED,
                (string) OrderClearanceRepository::STATUS_ORDER_CLEARANCE,
                $comment
            );

        $this->auditLog->createStatusChangeAuditLog(
            $orderContextId,
            $auditLogValue,
            $identity
        );

        $this->orderClearanceRepository
            ->declineOrder($orderContextId, $comment);
    }

    /**
     * @param Identity $identity
     * @param int $orderContextId
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     */
    public function deleteOrder(Identity $identity, int $orderContextId)
    {
        $this->checkOrderAccess($identity, $orderContextId);

        $this->orderClearanceRepository->deleteOrder($orderContextId);
    }

    /**
     * @param Identity $identity
     * @param int $orderContextId
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     */
    private function checkOrderAccess(Identity $identity, int $orderContextId)
    {
        $this->checkOrderContextIdBelongsToDebtor($identity, $orderContextId);

        $order = $this->orderClearanceRepository
            ->fetchOneByOrderContextId($orderContextId);

        $this->checkAllowed($order, $identity);
    }

    /**
     * @param OrderClearanceEntity $order
     * @param Identity $identity
     * @throws NotAllowedRecordException
     */
    private function checkAllowed(OrderClearanceEntity $order, Identity $identity)
    {
        if ($identity->isSuperAdmin()) {
            return;
        }

        if (!$this->cartService->isAccessible($identity, $order, $this->messageCollection)) {
            throw new NotAllowedRecordException('The given cart can not be reviewed by the current identity');
        }
    }

    /**
     * @param Identity $identity
     * @param int $orderContextId
     * @throws NotAllowedRecordException
     */
    private function checkOrderContextIdBelongsToDebtor(Identity $identity, int $orderContextId)
    {
        if ($identity->isSuperAdmin()) {
            return;
        }

        if (!$this->orderClearanceRepository->belongsOrderContextIdToDebtor($identity, $orderContextId)) {
            throw new NotAllowedRecordException(
                'The given order context id: ' . $orderContextId . ' belongs to another debtor!'
            );
        }
    }

    /**
     * @param string $newValue
     * @param string $oldValue
     * @param string $comment
     * @return AuditLogValueEntity
     */
    private function createAuditLogValue(string $newValue, string $oldValue, string $comment): AuditLogValueEntity
    {
        $auditLogValue = new AuditLogValueEntity();
        $auditLogValue->newValue = $newValue;
        $auditLogValue->oldValue = $oldValue;
        $auditLogValue->comment = $comment;

        return $auditLogValue;
    }
}
