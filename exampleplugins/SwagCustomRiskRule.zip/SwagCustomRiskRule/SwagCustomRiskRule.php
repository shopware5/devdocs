<?php

namespace SwagCustomRiskRule;

use Shopware\Components\Plugin;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class SwagCustomRiskRule extends Plugin
{
}

