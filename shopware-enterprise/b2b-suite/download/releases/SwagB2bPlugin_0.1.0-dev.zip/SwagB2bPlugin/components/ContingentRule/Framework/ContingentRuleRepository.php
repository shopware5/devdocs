<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class ContingentRuleRepository implements GridRepository
{
    const TABLE_NAME = 'b2b_contingent_group_rule';

    const TABLE_ALIAS = 'contingentGroupRule';

    /**
     * @var array
     */
    private static $mainTableFields = [
        'id',
        'contingent_group_id',
        'type',
    ];

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @var ContingentRuleTypeFactory
     */
    private $entityFactory;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     * @param ContingentRuleTypeFactory $entityFactory
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        ContingentRuleTypeFactory $entityFactory
    ) {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
        $this->entityFactory = $entityFactory;
    }

    /**
     * @param array $types
     * @param int $contingentGroupId
     * @param ContingentRuleSearchStruct $searchStruct
     * @throws \InvalidArgumentException
     * @return array|ContingentRuleEntity[]
     * @internal param OwnershipContext $context
     */
    public function fetchList(array $types, int $contingentGroupId, ContingentRuleSearchStruct $searchStruct): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.contingent_group_id = :contingentGroupId')
            ->andWhere(self::TABLE_ALIAS . '.type IN (:types)')
            ->setParameter('contingentGroupId', $contingentGroupId)
            ->setParameter('types', $types, Connection::PARAM_STR_ARRAY);

        $this->applyTypeQueries($types, $query);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper->applySearchStruct($searchStruct, $query);

        $statement = $query->execute();

        $contingentRulesData = $statement
            ->fetchAll(\PDO::FETCH_ASSOC);

        $contingentRules = [];
        foreach ($contingentRulesData as $contingentRuleData) {
            $contingentRules[] = $this->entityFactory
                ->createEntityFromTypeName($contingentRuleData['type'])
                ->fromDatabaseArray($contingentRuleData);
        }

        return $contingentRules;
    }

    /**
     * @param array $types
     * @param int $contingentGroupId
     * @param ContingentRuleSearchStruct $searchStruct
     * @return int
     */
    public function fetchTotalCount(array $types, int $contingentGroupId, ContingentRuleSearchStruct $searchStruct): int
    {
        $query = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.contingent_group_id = :contingentGroupId')
            ->andWhere(self::TABLE_ALIAS . '.type IN (:types)')
            ->setParameter('contingentGroupId', $contingentGroupId)
            ->setParameter('types', $types, Connection::PARAM_STR_ARRAY);

        $this->dbalHelper->applyFilters($searchStruct, $query);

        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * @param int $contingentGroupId
     * @throws \InvalidArgumentException
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return ContingentRuleEntity
     */
    public function fetchOneById(int $contingentGroupId): ContingentRuleEntity
    {
        $query = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->setParameter('id', $contingentGroupId);

        $this->applyTypeQueries($this->entityFactory->getAllTypeNames(), $query);

        $contingentRuleData = $query->execute()->fetch(\PDO::FETCH_ASSOC);

        if (!$contingentRuleData) {
            throw new NotFoundException();
        }

        $entity = $this->entityFactory
            ->createEntityFromTypeName($contingentRuleData['type']);

        $entity->fromDatabaseArray($contingentRuleData);

        return $entity;
    }

    /**
     * @param ContingentRuleEntity $contingentRuleEntity
     * @throws \InvalidArgumentException
     * @throws \RuntimeException
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @return ContingentRuleEntity
     */
    public function addContingentRule(ContingentRuleEntity $contingentRuleEntity): ContingentRuleEntity
    {
        if (!$contingentRuleEntity->isNew()) {
            throw new CanNotInsertExistingRecordException('The Contingent rule provided already exists');
        }

        $this->dbalHelper->transact(
            function () use ($contingentRuleEntity) {
                list($baseTableData, $extendedTableData) = $this->splitBaseAndExtendedTableData($contingentRuleEntity);
                $extendedTableName = $this->extractExtendedTableName($contingentRuleEntity);

                $this->connection->insert(
                    self::TABLE_NAME,
                    $baseTableData
                );

                $contingentRuleEntity->id = (int) $this->connection->lastInsertId();
                $extendedTableData['contingent_rule_id'] = $contingentRuleEntity->id;

                $this->connection->insert(
                    $extendedTableName,
                    $extendedTableData
                );
            }
        );

        return $contingentRuleEntity;
    }

    /**
     * @param ContingentRuleEntity $contingentRuleEntity
     * @throws \InvalidArgumentException
     * @throws \RuntimeException
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return ContingentRuleEntity
     */
    public function updateContingentRule(ContingentRuleEntity $contingentRuleEntity): ContingentRuleEntity
    {
        if ($contingentRuleEntity->isNew()) {
            throw new CanNotUpdateExistingRecordException('The Contingent rule provided does not exist');
        }

        $this->connection;
        $this->dbalHelper->transact(
            function () use ($contingentRuleEntity) {
                list($baseTableData, $extendedTableData) = $this->splitBaseAndExtendedTableData($contingentRuleEntity);
                $extendedTableName = $this->extractExtendedTableName($contingentRuleEntity);

                $this->connection->update(
                    self::TABLE_NAME,
                    $baseTableData,
                    ['id' => $contingentRuleEntity->id]
                );

                $this->connection->update(
                    $extendedTableName,
                    $extendedTableData,
                    ['contingent_rule_id' => $contingentRuleEntity->id]
                );
            }
        );

        return $contingentRuleEntity;
    }

    /**
     * @param ContingentRuleEntity $contingentRuleEntity
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveUsedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return ContingentRuleEntity
     */
    public function removeContingentRule(ContingentRuleEntity $contingentRuleEntity): ContingentRuleEntity
    {
        if ($contingentRuleEntity->isNew()) {
            throw new CanNotRemoveExistingRecordException('The Contingent rule provided does not exist');
        }

        $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $contingentRuleEntity->id]
        );

        $contingentRuleEntity->id = null;

        return $contingentRuleEntity;
    }

    /**
     * @return string query alias for filter construction
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @param int $contingentGroupId
     * @param OwnershipContext $ownershipContext
     * @return bool
     */
    public function isContingentGroupAllowedForOwner(int $contingentGroupId, OwnershipContext $ownershipContext): bool
    {
        return (bool) $this->connection->fetchColumn(
            'SELECT * FROM b2b_contingent_group
             WHERE s_user_id = :userId
             AND id = :contingentGroupId',
            [
                ':userId' => $ownershipContext->shopOwnerUserId,
                ':contingentGroupId' => $contingentGroupId,
            ]
        );
    }

    /**
     * not implemented yet
     *
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [];
    }

    /**
     * @param string $ruleType
     * @param int $contingentGroup
     * @return ContingentRuleEntity[]
     */
    public function fetchActiveRuleItemsForRuleType(string $ruleType, int $contingentGroup): array
    {
        $typedSubQuery = $this->entityFactory
            ->findTypeByName($ruleType)
            ->getRepository($this->connection)
            ->createSubQuery();

        $contingentRulesData = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*, typedTable.*')
            ->from('(' . $typedSubQuery . ')', 'typedTable')
            ->innerJoin('typedTable', self::TABLE_NAME, self::TABLE_ALIAS, self::TABLE_ALIAS . '.id = typedTable.contingent_rule_id')
            ->where(self::TABLE_ALIAS . '.contingent_group_id = :id AND ' . self::TABLE_ALIAS . '.type = :ruleType')
            ->setParameter(':id', $contingentGroup)
            ->setParameter(':ruleType', $ruleType)
            ->execute()
            ->fetchAll();

        $entities = [];
        foreach ($contingentRulesData as $contingentRuleData) {
            $entity = $this->entityFactory
                ->createEntityFromTypeName($ruleType);

            $entity->fromDatabaseArray($contingentRuleData);

            $entities[] = $entity;
        }

        return $entities;
    }

    /**
     * @param ContingentRuleEntity $contingentRuleEntity
     * @return ContingentRuleEntity[]
     */
    private function splitBaseAndExtendedTableData(ContingentRuleEntity $contingentRuleEntity): array
    {
        $data = $contingentRuleEntity->toDatabaseArray();
        $baseTableData = [];
        $extendedTableData = [];

        foreach ($data as $fieldName => $value) {
            if (false !== in_array($fieldName, self::$mainTableFields, true)) {
                $baseTableData[$fieldName] = $value;
                continue;
            }

            $extendedTableData[$fieldName] = $value;
        }

        return [$baseTableData, $extendedTableData];
    }

    /**
     * @param $contingentRuleEntity
     * @throws \InvalidArgumentException
     * @return string
     */
    private function extractExtendedTableName(ContingentRuleEntity $contingentRuleEntity): string
    {
        return $this->entityFactory
            ->findTypeByName($contingentRuleEntity->type)
            ->getRepository($this->connection)
            ->getTableName();
    }

    /**
     * @param $query
     * @param array $types
     */
    private function applyTypeQueries(array $types, QueryBuilder $query)
    {
        foreach ($types as $type) {
            $typeRepository = $this->entityFactory
                ->findTypeByName($type)
                ->getRepository($this->connection);

            $query
                ->addSelect($type . '.*')
                ->leftJoin(self::TABLE_ALIAS, '(' . $typeRepository->createSubQuery() . ')', $type, self::TABLE_ALIAS . '.id = ' . $type . '.contingent_rule_id');
        }
    }
}
