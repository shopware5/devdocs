/**
 * Loads occurred per ajax, replaces it in the DOM and intercepts all it's submit and link click events.
 *
 * USAGE:
 *
 * Basic container needs to look like this:
 *
 * <div class="b2b--ajax-panel" data-url="http://foo/bar"></div>
 *
 * If DOM element should be a trigger, but can neither be <a>, nor <form>, you can add a special class
 *
 * <button class="ajax-panel-link" data-href="http://foo/bar">Click</a>
 *
 * If a link should use a different target:
 *
 * Container:  <div ... data-id="foreign"></div>
 * Link: <a [...] data-target="foreign">Open in another component</a>
 *
 * If you want a link to be ignored, add the class '.ignore--b2b-ajax-panel'.
 *
 * EVENTS:
 *
 * Triggered:
 *    'b2b--ajax-panel_loading': triggered on the panel before loading new data
 *    'b2b--ajax-panel_loading': triggered on the panel after loading and replacing the data
 *
 * Handled:
 *      'b2b--ajax-panel_refresh': triggered on the panel reissues the last request on the panel
 *
 * global: CSRF
 */
$.plugin('b2bAjaxPanel', {
    defaults: {
        panelSelector: '.b2b--ajax-panel',

        panelLinkDataKey: 'href',
        panelUrlDataKey: 'url',
        panelHistoryDataKey : 'lastPanelRequest',

        panelLoadingClass: 'is--loading',

        ignoreSelector: '.ignore--b2b-ajax-panel',

        panelLinkSelector: '.ajax-panel-link',

        panelBeforeLoadEvent: 'b2b--ajax-panel_loading',
        panelAfterLoadEvent: 'b2b--ajax-panel_loaded',

        panelRefreshEvent: 'b2b--ajax-panel_refresh',
        panelRegisterEvent: 'b2b--ajax-panel_register'
    },

    init: function() {
        var me = this;

        this.applyDataAttributes();
        this.registerGlobalListeners();

        $(me.defaults.panelSelector).each(function (index, panel) {
            me.register(panel);
        });
    },

    register: function (panel) {
        var $panel = $(panel);
        var url = $panel.data(this.defaults.panelUrlDataKey);

        if(url && url.length) {
            this.load(url, panel, $panel);
        }
    },

    error: function(target) {
        $(target).html('<h1>An error occurred:(</h1>');
    },

    load: function(url, target, source) {
        var me = this;
        var $target = $(target);
        var serializedData = {};
        var method = 'GET';

        if (source && source.length && source.is('form')) {
            method = 'POST';
            serializedData = source.serialize();
        }

        var ajaxData = {
            type: method,
            url: url,
            data: serializedData
        };

        me.doAjaxCall(ajaxData, $target, source);
    },

    doAjaxCall: function(ajaxData, $target, $source) {
        var me = this;

        if (me.notify($target, me.defaults.panelBeforeLoadEvent, {'panel': $target, 'source': $source, 'ajaxData': ajaxData})) {
            return;
        }

        $target.data(me.defaults.panelHistoryDataKey, ajaxData);
        $target.addClass(me.defaults.panelLoadingClass);

        $.ajax(ajaxData)
            .success(function(response, status, xhr) {

                /** global: window */
                if(xhr.getResponseHeader('B2b-no-login')) {
                    window.location.reload();
                    return;
                }

                $target.html(response);

                me.refreshShopwarePlugins();

                $target.trigger(me.defaults.panelAfterLoadEvent, {
                    'panel': $target,
                    'source': $source,
                    'ajaxData': ajaxData
                });

            }).error(function () {

                me.error($target);

            }).always(function () {
                $target.removeClass(me.defaults.panelLoadingClass);
            });
    },

    breakEventExecution: function(event) {
        event.preventDefault();
    },

    registerGlobalListeners: function() {
        var me = this;

        me._on(document, 'click', me.defaults.panelSelector + ' a, ' + me.defaults.panelSelector + ' ' + me.defaults.panelLinkSelector, function (event) {
            if(event.isDefaultPrevented()) {
                return;
            }

            var $eventTarget = $(event.target);

            if(!$eventTarget.is(this) && $eventTarget.closest('form').length) {
                return;
            }

            me.breakEventExecution(event);

            var $anchor = $(this),
                url,
                $panel = $anchor.closest(me.defaults.panelSelector),
                targetPanel = $anchor.data('target'),
                $targetPanel = $(me.defaults.panelSelector + '[data-id="' + targetPanel + '"]');

            if($anchor.is(me.defaults.ignoreSelector)) {
                return;
            }

            if($anchor[0].hasAttribute(me.defaults.panelLinkDataKey)) {
                url = $anchor.attr(me.defaults.panelLinkDataKey);
            } else {
                url = $anchor.data(me.defaults.panelLinkDataKey);
            }

            if ($targetPanel.length) {
                me.load(url, $targetPanel, $anchor);
            } else {
                me.load(url, $panel, $anchor);
            }
        });

        me._on(document, 'submit', me.defaults.panelSelector + ' form', function (event) {
            if(event.isDefaultPrevented()) {
                return;
            }

            me.breakEventExecution(event);

            var $form = $(this),
                $panel = $form.closest(me.defaults.panelSelector),
                url = $form.attr('action');

            if($form.is(me.defaults.ignoreSelector)) {
                return;
            }

            me.load(url, $panel, $form);
        });

        me._on(document, me.defaults.panelAfterLoadEvent, me.defaults.panelSelector, function(event) {
            if(event.isDefaultPrevented()) {
                return;
            }

            var $panel = $(this);

            me.breakEventExecution(event);

            $panel.find(me.defaults.panelSelector).each(function() {
                var panel = this;

                me.register(panel);
            });
        });

        me._on(document, me.defaults.panelRefreshEvent, me.defaults.panelSelector, function(event) {
            if(event.isDefaultPrevented()) {
                return;
            }

            var $panel = $(this),
                ajaxData = $panel.data(me.defaults.panelHistoryDataKey);

            if(!ajaxData) {
                return;
            }

            me.breakEventExecution(event);
            me.doAjaxCall(ajaxData, $panel, $panel);
        });

        me._on(document, me.defaults.panelRegisterEvent, me.defaults.panelSelector, function(event) {
            if(event.isDefaultPrevented()) {
                return;
            }

            var $panel = $(this);

            me.register($panel);
        });
    },

    notify: function($panel, eventName, data) {
        var beforeEvent = $.Event(eventName);
        $panel.trigger(beforeEvent, data);

        return beforeEvent.isDefaultPrevented();
    },

    refreshShopwarePlugins: function() {
        $.modal.onWindowResize();

        CSRF.updateForms();
    },

    destroy: function() {
        var me = this;
        me._destroy();
    }
});

$(document).b2bAjaxPanel();
