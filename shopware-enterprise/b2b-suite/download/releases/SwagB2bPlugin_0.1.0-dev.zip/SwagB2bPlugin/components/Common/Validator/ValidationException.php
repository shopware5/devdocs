<?php declare(strict_types=1);

namespace Shopware\B2B\Common\Validator;

use Exception;
use Shopware\B2B\Common\B2BException;
use Shopware\B2B\Common\Entity;

class ValidationException extends \InvalidArgumentException implements B2BException
{
    private $violations;
    /**
     * @var Entity
     */
    private $entity;

    /**
     * @param Entity $entity
     * @param int $violations
     * @param Exception $message
     * @param null $code
     * @param Exception|null $previous
     */
    public function __construct(Entity $entity, $violations, $message, $code = null, Exception $previous = null)
    {
        parent::__construct($message, $code, $previous);

        $this->violations = $violations;
        $this->entity = $entity;
    }

    /**
     * @return int
     */
    public function getViolations()
    {
        return $this->violations;
    }

    /**
     * @return Entity
     */
    public function getEntity(): Entity
    {
        return $this->entity;
    }
}
