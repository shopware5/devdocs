<?php declare(strict_types=1);

namespace Shopware\B2B\Cart\Framework;

class MessageCollection
{
    /**
     * @var int
     */
    public $messageCount = 0;

    /**
     * @var array
     */
    private $errors = [];

    /**
     * @param string $sender
     * @param string $error
     * @param array $params
     */
    public function addError(string $sender, string $error, array $params = [])
    {
        $this->errors[] = new ErrorMessage($sender, $error, $params);
        $this->messageCount++;
    }

    /**
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * @return bool
     */
    public function clearErrors(): bool
    {
        $this->errors = [];
        $this->messageCount = 0;

        return true;
    }
}
