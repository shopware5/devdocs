<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Frontend;

use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContextRepository;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceRepositoryInterface;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceSearchStruct;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceService;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class OrderClearanceController
{
    /**
     * @var OrderClearanceService
     */
    private $orderClearanceService;

    /**
     * @var OrderClearanceRepositoryInterface
     */
    private $orderClearanceRepository;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var LineItemListOrderContextRepository
     */
    private $orderContextRepository;

    /**
     * @param AuthenticationService $authenticationService
     * @param OrderClearanceService $orderClearanceService
     * @param OrderClearanceRepositoryInterface $orderClearanceRepository
     * @param GridHelper $gridHelper
     * @param LineItemListOrderContextRepository $orderContextRepository
     */
    public function __construct(
        AuthenticationService $authenticationService,
        OrderClearanceService $orderClearanceService,
        OrderClearanceRepositoryInterface $orderClearanceRepository,
        GridHelper $gridHelper,
        LineItemListOrderContextRepository $orderContextRepository
    ) {
        $this->authenticationService = $authenticationService;
        $this->orderClearanceRepository = $orderClearanceRepository;
        $this->gridHelper = $gridHelper;
        $this->orderClearanceService = $orderClearanceService;
        $this->orderContextRepository = $orderContextRepository;
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $identity = $this->authenticationService->getIdentity();

        $searchStruct = new OrderClearanceSearchStruct();

        $this->gridHelper
            ->extractSearchDataInStoreFront($request, $searchStruct);

        $orderClearance = $this->orderClearanceService
            ->fetchAllOrderClearances($identity);

        $totalCount = $this->orderClearanceRepository
            ->fetchTotalCount($identity, $searchStruct);

        $maxPage = $this->gridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $request->getParam('page', 1);

        $gridState = $this->gridHelper
            ->getGridState($request, $searchStruct, $orderClearance, $maxPage, $currentPage);

        return [
            'gridState' => $gridState,
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function detailAction(Request $request): array
    {
        $listId = (int) $request->requireParam('listId');

        $orderContext = $this->orderContextRepository->fetchOneOrderContextByListId($listId);

        return [
            'list' => $this->orderClearanceRepository->fetchOneByListId($listId),
            'orderContext' => $orderContext,
        ];
    }

    /**
     * @param Request $request
     * @throws B2bControllerForwardException
     */
    public function deleteAction(Request $request)
    {
        $request->checkPost();

        $orderContextId = (int) $request
            ->requireParam('orderContextId');

        $identity = $this->authenticationService
            ->getIdentity();

        $this->orderClearanceService
            ->deleteOrder($identity, $orderContextId);

        throw new B2bControllerForwardException('grid');
    }

    /**
     * @param Request $request
     * @return array
     */
    public function acceptAction(Request $request): array
    {
        return $this->loadOrder($request);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function declineAction(Request $request): array
    {
        return $this->loadOrder($request);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function acceptOrderAction(Request $request): array
    {
        $request->checkPost('grid');

        $orderContextId = (int) $request
            ->requireParam('orderContextId');

        $comment = $request->getParam('comment', '');

        $identity = $this->authenticationService
            ->getIdentity();

        $this->orderClearanceService
            ->acceptOrder($identity, $orderContextId, $comment);

        return [];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function declineOrderAction(Request $request): array
    {
        $request->checkPost('grid');

        $orderContextId = (int) $request
            ->requireParam('orderContextId');

        $comment = $request->getParam('comment', '');

        $identity = $this->authenticationService
            ->getIdentity();

        $this->orderClearanceService
            ->declineOrder($identity, $orderContextId, $comment);

        return [];
    }

    /**
     * @param Request $request
     * @return array
     */
    private function loadOrder(Request $request): array
    {
        $orderContextId = (int) $request
            ->requireParam('orderContextId');

        $order = $this->orderClearanceRepository
            ->fetchOneByOrderContextId($orderContextId);

        return ['order' => $order];
    }
}
