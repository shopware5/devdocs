<?php declare(strict_types=1);

namespace Shopware\B2B\StoreFrontAuthentication\Bridge;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Repository\NotFoundException;

class UserRepository
{
    const TABLE_NAME = 's_user';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param string $contactEmail
     * @param array $contactData
     * @return int
     */
    public function syncContact(string $contactEmail, array $contactData): int
    {
        $check = $this->connection
            ->fetchColumn(
                'SELECT id FROM ' . self::TABLE_NAME . ' WHERE email LIKE :email LIMIT 1',
                ['email' => $contactEmail]
            );

        if (!$check) {
            $this->connection->insert(
                self::TABLE_NAME,
                array_merge(
                    $contactData,
                    ['email' => $contactEmail]
                )
            );

            return (int) $this->connection->lastInsertId();
        }

        $this->connection
            ->update(
                self::TABLE_NAME,
                $contactData,
                ['email' => $contactEmail]
            );

        return (int) $check;
    }

    /**
     * @param int $id
     * @return array
     */
    public function fetchOneById(int $id): array
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, 'user')
            ->where('user.id = :id')
            ->setParameter('id', $id)
            ->execute();

        $user = $statement->fetch(\PDO::FETCH_ASSOC);

        if (!$user) {
            throw new NotFoundException(sprintf('User not found for %s', $id));
        }

        return $user;
    }
}
