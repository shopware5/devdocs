/**
 * Handles the assignment grid view extensions
 *
 * * Submit the form through ajax
 * * Disable Grant buttons if access is disabled
 *
 * global: event
 */
$.plugin('b2bAssignmentGrid', {
    defaults: {
        gridFormSelector: 'form.b2b--assignment-form',

        allowInputSelector: '.assign--allow',

        denyInputSelector: '.assign--grantable'
    },

    init: function() {
        var me = this;

        this.applyDataAttributes();

        var $forms = me.$el.find(me.defaults.gridFormSelector);

        $forms.each(function() {
            var $form = $(this),
                allowCheckbox = $form.find(me.defaults.allowInputSelector),
                grantableCheckbox = $form.find(me.defaults.denyInputSelector);

            if(!allowCheckbox.is(':checked')) {
                grantableCheckbox.prop('disabled', true);
            }

            me._on(allowCheckbox, 'change', function() {
                if(allowCheckbox.is(':checked')) {
                    grantableCheckbox.prop('disabled', false);
                } else {
                    grantableCheckbox.attr('checked', false);
                    grantableCheckbox.prop('disabled', true);
                }
            });
        });

        this._on($forms, 'submit', function() {
            event.preventDefault();

            var $form = $(this);
            var $checkbox = $(document.activeElement);
            $checkbox.closest('span.checkbox').addClass('is--loading');

            $.ajax({
                url: $form.attr('action'),
                method: $form.attr('method'),
                data: $form.serialize()
            }).success(function() {
                // nth
            }).error(function() {
                alert("An error occurred.");
            }).always(function() {
                $checkbox.closest('span.checkbox').removeClass('is--loading');
            });
        });
    },

    destroy: function() {
        var me = this;
        me._destroy();
    }
});

$('.b2b--assignment-grid').b2bAssignmentGrid();