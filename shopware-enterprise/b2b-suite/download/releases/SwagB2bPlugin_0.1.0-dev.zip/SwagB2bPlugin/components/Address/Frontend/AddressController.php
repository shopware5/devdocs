<?php declare(strict_types=1);

namespace Shopware\B2B\Address\Frontend;

use Shopware\B2B\Address\Framework\AddressCrudService;
use Shopware\B2B\Address\Framework\AddressEntity;
use Shopware\B2B\Address\Framework\AddressRepository;
use Shopware\B2B\Address\Framework\AddressSearchStruct;
use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Validator\ValidationException;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class AddressController
{
    /**
     * @var AddressRepository
     */
    private $addressRepository;

    /**
     * @var AddressCrudService
     */
    private $addressCrudService;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @param AuthenticationService $authenticationService
     * @param AddressRepository $addressRepository
     * @param AddressCrudService $addressCrudService
     * @param GridHelper $gridHelper
     */
    public function __construct(
        AuthenticationService $authenticationService,
        AddressRepository $addressRepository,
        AddressCrudService $addressCrudService,
        GridHelper $gridHelper
    ) {
        $this->authenticationService = $authenticationService;
        $this->addressRepository = $addressRepository;
        $this->addressCrudService = $addressCrudService;
        $this->gridHelper = $gridHelper;
    }

    public function indexAction()
    {
        //nth
    }

    /**
     * @param Request $request
     * @return array
     */
    public function billingGridAction(Request $request): array
    {
        $gridState = $this->createGridState($request, AddressEntity::TYPE_BILLING, $this->gridHelper);

        return ['gridState' => $gridState];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function shippingGridAction(Request $request): array
    {
        $gridState = $this->createGridState($request, AddressEntity::TYPE_SHIPPING, $this->gridHelper);

        return ['gridState' => $gridState];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function newAction(Request $request): array
    {
        $validationResponse = $this->gridHelper->getValidationResponse('address');

        return array_merge([
            'type' => $request->getParam('type', 'billing'),
            'countryList' => $this->addressRepository->getCountryList(),
        ], $validationResponse);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function createAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();

        $serviceRequest = $this->addressCrudService
            ->createNewRecordRequest($post);

        $identity = $this->authenticationService
            ->getIdentity();

        try {
            $address = $this->addressCrudService
                ->create($serviceRequest, $identity->getOwnershipContext(), $post['type']);
        } catch (ValidationException $e) {
            $this->gridHelper->pushValidationException($e);
            throw new B2bControllerForwardException('new');
        }

        throw new B2bControllerForwardException('detail', null, null, ['id' => $address->id]);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function removeAction(Request $request)
    {
        $request->checkPost();

        $type = $request->getParam('type', 'billing');

        $serviceRequest = $this->addressCrudService
            ->createExistingRecordRequest($request->getPost());

        try {
            $this->addressCrudService->remove($serviceRequest);
        } catch (CanNotRemoveExistingRecordException $e) {
            // nth
        }

        throw new B2bControllerForwardException($type . 'Grid');
    }

    /**
     * @param Request $request
     * @return array
     */
    public function detailAction(Request $request): array
    {
        $addressId = (int) $request->requireParam('id');

        $addressAttributes = $this->addressRepository
            ->fetchAttributesById($addressId);

        $validationResponse = $this->gridHelper->getValidationResponse('address');

        return array_merge([
            'countryList' => $this->addressRepository->getCountryList(),
            'type' => $addressAttributes['b2b_type'],
            'address' => $this->addressRepository->fetchOneById($addressId),
        ], $validationResponse);
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function updateAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();
        $serviceRequest = $this->addressCrudService
            ->createExistingRecordRequest($post);

        $ownershipContext = $this->authenticationService->getIdentity()
            ->getOwnershipContext();

        try {
            $this->addressCrudService
                ->update($serviceRequest, $ownershipContext, $post['type']);
        } catch (ValidationException $e) {
            $this->gridHelper->pushValidationException($e);
        }

        throw new B2bControllerForwardException('detail', null, null, ['id' => $post['id']]);
    }

    /**
     * @param Request $request
     * @param string $addressType
     * @param GridHelper $gridHelper
     * @return array
     */
    private function createGridState(Request $request, string $addressType, GridHelper $gridHelper): array
    {
        $searchStruct = new AddressSearchStruct();
        $ownership = $this->authenticationService->getIdentity()->getOwnershipContext();

        $gridHelper->extractSearchDataInStoreFront($request, $searchStruct);

        $billingAddresses = $this->addressRepository
            ->fetchList($addressType, $ownership, $searchStruct);

        $totalCount = $this->addressRepository
            ->fetchTotalCount($addressType, $ownership, $searchStruct);

        $maxPage = $gridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $gridHelper->getCurrentPage($request);

        $gridState = $gridHelper
            ->getGridState($request, $searchStruct, $billingAddresses, $maxPage, $currentPage);

        return $gridState;
    }
}
