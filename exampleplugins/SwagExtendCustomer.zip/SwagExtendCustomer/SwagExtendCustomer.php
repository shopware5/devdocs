<?php

namespace SwagExtendCustomer;

use Shopware\Components\Plugin;

class SwagExtendCustomer extends Plugin
{

}