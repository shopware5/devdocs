<?php declare(strict_types=1);

namespace B2bServiceExtension;

use Shopware\Components\Plugin;

class B2bServiceExtension extends Plugin
{
}
