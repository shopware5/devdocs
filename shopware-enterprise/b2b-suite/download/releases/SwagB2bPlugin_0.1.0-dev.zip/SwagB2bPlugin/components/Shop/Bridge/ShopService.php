<?php declare(strict_types=1);

namespace Shopware\B2B\Shop\Bridge;

use Shopware\B2B\Shop\Framework\ShopServiceInterface;
use Shopware\Components\DependencyInjection\Container;

class ShopService implements ShopServiceInterface
{
    /**
     * @var Container
     */
    private $container;

    /**
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * @return int
     */
    public function getRootCategoryId(): int
    {
        /** @var \Shopware\Models\Shop\Shop $shop */
        $shop = $this->container->get('shop');

        return (int) $shop->getCategory()->getId();
    }
}
