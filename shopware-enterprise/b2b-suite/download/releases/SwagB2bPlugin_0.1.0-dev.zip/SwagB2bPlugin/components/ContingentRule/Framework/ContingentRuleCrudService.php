<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework;

use Shopware\B2B\Common\Repository\NotAllowedRecordException;
use Shopware\B2B\Common\Service\AbstractCrudService;
use Shopware\B2B\Common\Service\CrudServiceRequest;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class ContingentRuleCrudService extends AbstractCrudService
{
    /**
     * @var ContingentRuleRepository
     */
    private $contingentRuleRepository;

    /**
     * @var ContingentRuleValidationService
     */
    private $groupValidationService;

    /**
     * @var ContingentRuleTypeFactory
     */
    private $entityFactory;

    /**
     * @param ContingentRuleRepository $contingentRuleRepository
     * @param ContingentRuleValidationService $groupValidationService
     * @param ContingentRuleTypeFactory $entityFactory
     */
    public function __construct(
        ContingentRuleRepository $contingentRuleRepository,
        ContingentRuleValidationService $groupValidationService,
        ContingentRuleTypeFactory $entityFactory
    ) {
        $this->contingentRuleRepository = $contingentRuleRepository;
        $this->groupValidationService = $groupValidationService;
        $this->entityFactory = $entityFactory;
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createNewRecordRequest(array $data): CrudServiceRequest
    {
        $baseKeys = [
            'type',
            'contingentGroupId',
        ];

        $request = new CrudServiceRequest($data, $baseKeys);
        $typeKeys = $this->entityFactory
            ->getRequestKeys($request->requireParam('type'));

        return new CrudServiceRequest(
            $data,
            array_merge($baseKeys, $typeKeys)
        );
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createExistingRecordRequest(array $data): CrudServiceRequest
    {
        $baseKeys = [
            'id',
            'type',
            'contingentGroupId',
        ];

        $request = new CrudServiceRequest($data, $baseKeys);
        $typeKeys = $this->entityFactory
            ->getRequestKeys($request->requireParam('type'));

        return new CrudServiceRequest(
            $data,
            array_merge($baseKeys, $typeKeys)
        );
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @throws \RuntimeException
     * @throws \InvalidArgumentException
     * @throws \DomainException
     * @throws \Shopware\B2B\Common\Repository\NotAllowedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @return ContingentRuleEntity
     */
    public function create(CrudServiceRequest $request, OwnershipContext $ownershipContext): ContingentRuleEntity
    {
        $data = $request->getFilteredData();

        $data['contingentGroupId'] = (int) $data['contingentGroupId'];

        $this->checkPermission($data['contingentGroupId'], $ownershipContext);

        $contingentRule = $this->entityFactory
            ->createEntityFromServiceRequest($request);

        $contingentRule->setData($data);

        $validation = $this->groupValidationService
            ->createInsertValidation($contingentRule);

        $this->testValidation($contingentRule, $validation);

        $contingentRule = $this->contingentRuleRepository
            ->addContingentRule($contingentRule);

        return $contingentRule;
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @throws \RuntimeException
     * @throws \InvalidArgumentException
     * @throws \DomainException
     * @throws \Shopware\B2B\Common\Repository\NotAllowedRecordException
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return ContingentRuleEntity
     */
    public function update(CrudServiceRequest $request, OwnershipContext $ownershipContext): ContingentRuleEntity
    {
        $data = $request->getFilteredData();

        $data['contingentGroupId'] = (int) $data['contingentGroupId'];

        $this->checkPermission($data['contingentGroupId'], $ownershipContext);

        $contingentRule = $this->entityFactory
            ->createEntityFromServiceRequest($request);

        $contingentRule->setData($data);
        $contingentRule->id = (int) $contingentRule->id;

        $validation = $this->groupValidationService->createUpdateValidation($contingentRule);

        $this->testValidation($contingentRule, $validation);

        $this->contingentRuleRepository->updateContingentRule($contingentRule);

        return $contingentRule;
    }

    /**
     * @param CrudServiceRequest $request
     * @param OwnershipContext $ownershipContext
     * @throws \InvalidArgumentException
     * @throws \DomainException
     * @throws \Shopware\B2B\Common\Repository\NotAllowedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveUsedRecordException
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return ContingentRuleEntity
     */
    public function remove(CrudServiceRequest $request, OwnershipContext $ownershipContext): ContingentRuleEntity
    {
        $data = $request->getFilteredData();

        $data['contingentGroupId'] = (int) $data['contingentGroupId'];

        $this->checkPermission($data['contingentGroupId'], $ownershipContext);

        $contingentRule = $this->entityFactory
            ->createEntityFromServiceRequest($request);

        $contingentRule->setData($data);

        $this->contingentRuleRepository->removeContingentRule($contingentRule);

        return $contingentRule;
    }

    /**
     * checks if the user is connected to the contingent group
     *
     * @param int $contingentGroupId
     * @param OwnershipContext $ownershipContext
     * @throws \Shopware\B2B\Common\Repository\NotAllowedRecordException
     */
    private function checkPermission(int $contingentGroupId, OwnershipContext $ownershipContext)
    {
        $contingentGroupAccessAllowed = $this->contingentRuleRepository->isContingentGroupAllowedForOwner(
            $contingentGroupId,
            $ownershipContext
        );

        if (!$contingentGroupAccessAllowed) {
            throw new NotAllowedRecordException();
        }
    }
}
