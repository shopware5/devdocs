//{block name="backend/order/controller/detail"}
//{$smarty.block.parent}
/** global: Ext */
Ext.define('Shopware.apps.Order.Reference.controller.Detail', {
    override: 'Shopware.apps.Order.controller.Detail',

    onSaveOverview: function (record) {
        var me = this;

        Ext.Ajax.request({
            method: 'POST',
            url: '{url controller=AttributeData action=saveData}',
            params: {
                _foreignKey: record.data.id,
                _table: 's_order_attributes',
                __attribute_b2b_order_reference: Ext.ComponentQuery.query('textfield[name=orderReference]')[0].getValue(),
                __attribute_b2b_requested_delivery_date: Ext.ComponentQuery.query('datefield[name=requestedDeliveryDate]')[0].getValue()
            }
        });

        me.callParent(arguments);
    }
});
//{/block}