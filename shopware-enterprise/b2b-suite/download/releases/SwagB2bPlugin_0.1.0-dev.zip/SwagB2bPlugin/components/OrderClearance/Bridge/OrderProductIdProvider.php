<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Bridge;

use Shopware\B2B\Order\Bridge\OrderRepository;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceEntity;
use Shopware\B2B\OrderClearance\Framework\OrderItemEntity;
use Shopware\B2B\OrderClearance\Framework\OrderProductItem;

class OrderProductIdProvider implements OrderItemLoaderInterface
{
    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @param OrderRepository $orderRepository
     */
    public function __construct(OrderRepository $orderRepository)
    {
        $this->orderRepository = $orderRepository;
    }

    /**
     * @param OrderClearanceEntity $itemEntity
     * @return OrderItemEntity[]
     */
    public function fetchItemsFromStorage(OrderClearanceEntity $itemEntity): array
    {
        $products = $this->orderRepository
            ->fetchAllContainedProducts($itemEntity->orderNumber);

        return $this->createProductsItems($products);
    }

    /**
     * @param OrderClearanceEntity $itemEntity
     * @param array $basketArray
     * @return OrderItemEntity[]
     */
    public function fetchItemsFromBasketArray(OrderClearanceEntity $itemEntity, array $basketArray): array
    {
        if (!isset($basketArray['content']) || !is_array($basketArray['content'])) {
            $basketArray['content'] = [];
        }

        $allProducts = array_map(function (array $product) {
            return [
                'productId' => (int) $product['articleID'],
                'productPrice' => (float) $product['netprice'],

            ];
        }, $basketArray['content']);

        $realProducts = array_filter($allProducts, function (array $product) {
            return $product['productId'] > 0;
        });

        return $this->createProductsItems($realProducts);
    }

    /**
     * @param array $product
     * @return OrderProductItem
     */
    private function createProductItem(array $product): OrderProductItem
    {
        $productItem = new OrderProductItem();
        $productItem->identifier = $product['productId'];
        $productItem->productPrice = $product['productPrice'];

        return $productItem;
    }

    /**
     * @param array $products
     * @return OrderProductItem[]
     */
    private function createProductsItems(array $products): array
    {
        $productItems = [];

        foreach ($products as $product) {
            $productItems[] = $this
                ->createProductItem($product);
        }

        return $productItems;
    }
}
