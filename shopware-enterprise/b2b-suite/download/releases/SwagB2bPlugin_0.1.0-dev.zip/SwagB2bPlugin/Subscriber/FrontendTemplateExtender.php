<?php declare(strict_types=1);

namespace SwagB2bPlugin\Subscriber;

use Doctrine\Common\Collections\ArrayCollection;
use Enlight\Event\SubscriberInterface;
use Shopware\Components\Theme\LessDefinition;
use Symfony\Component\DependencyInjection\Container;

class FrontendTemplateExtender implements SubscriberInterface
{
    /**
     * @var Container
     */
    private $container;

    /**
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Enlight_Controller_Action_PostDispatchSecure_Frontend' => 'addViewDirectories',
            'Theme_Compiler_Collect_Plugin_Less' => 'getLessCollection',
            'Theme_Compiler_Collect_Plugin_JavaScript' => 'getJavaScriptCollection',
            'Enlight_Controller_Action_PreDispatch' => 'addFrontendSmartyHelpers',
        ];
    }

    /**
     * Register the b2b widget plugin
     *
     * @param \Enlight_Controller_ActionEventArgs $args
     */
    public function addFrontendSmartyHelpers(\Enlight_Controller_ActionEventArgs $args)
    {
        $request = $args->getRequest();
        /** @var \Enlight_Template_Manager $template */
        $template = $this->container->get('template');

        if (!in_array($request->getModuleName(), ['frontend', 'widgets'], true)) {
            return;
        }

        $template->addPluginsDir(__DIR__ . '/../Resources/views/frontend/_private/smarty/');
    }

    /**
     * @param \Enlight_Controller_ActionEventArgs $args
     */
    public function addViewDirectories(\Enlight_Controller_ActionEventArgs $args)
    {
        $args->getSubject()->View()->addTemplateDir(__DIR__ . '/../Resources/views');

        if ($this->container->get('b2b_front_auth.authentication_service')->isB2b()) {
            $args->getSubject()->View()->addTemplateDir(__DIR__ . '/../Resources/extendedViews');
        }
    }

    /**
     * @return ArrayCollection
     */
    public function getLessCollection()
    {
        $less = new LessDefinition(
            [],
            [__DIR__ . '/../Resources/views/frontend/_public/src/less/all.less'],
            __DIR__ . '/..'
        );

        return new ArrayCollection([$less]);
    }

    /**
     * @return ArrayCollection
     */
    public function getJavaScriptCollection()
    {
        $jsFiles = [
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-acl-form.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-acl-grid.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/grid-component.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/assignment-grid.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/auto-submit.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-plugin-loader.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-trigger-reload.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-form-disable.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-form-select.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-modal.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-loading.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-tab.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/ajax-panel-edit-inline.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/tree.js',
            __DIR__ . '/../Resources/views/frontend/_public/src/js/form-input-holder.js',
        ];

        return new ArrayCollection($jsFiles);
    }
}
