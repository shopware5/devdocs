<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class LineItemListService
{
    /**
     * @var LineItemListRepository
     */
    private $listRepository;

    /**
     * @var LineItemReferenceRepository
     */
    private $referenceRepository;

    /**
     * @var LineItemShopWriterServiceInterface
     */
    private $bridgeService;

    /**
     * @var LineItemCheckoutProviderInterface
     */
    private $checkoutProvider;

    /**
     * @var LineItemListOrderContextRepository
     */
    private $orderContextRepository;

    /**
     * @param LineItemListRepository $listRepository
     * @param LineItemReferenceRepository $referenceRepository
     * @param LineItemShopWriterServiceInterface $bridgeService
     * @param LineItemCheckoutProviderInterface $checkoutProvider
     * @param LineItemListOrderContextRepository $orderContextRepository
     */
    public function __construct(
        LineItemListRepository $listRepository,
        LineItemReferenceRepository $referenceRepository,
        LineItemListOrderContextRepository $orderContextRepository,
        LineItemShopWriterServiceInterface $bridgeService,
        LineItemCheckoutProviderInterface $checkoutProvider
    ) {
        $this->listRepository = $listRepository;
        $this->referenceRepository = $referenceRepository;
        $this->bridgeService = $bridgeService;
        $this->checkoutProvider = $checkoutProvider;
        $this->orderContextRepository = $orderContextRepository;
    }

    /**
     * @param int $listId
     * @param LineItemListOrderContext $context
     */
    public function produceCart(int $listId, LineItemListOrderContext $context)
    {
        $list = $this->listRepository->fetchOneListById($listId);

        $this->bridgeService->triggerCart($list, $context);
    }

    /**
     * @param int $listId
     * @param LineItemListOrderContext $context
     * @param array $basket
     */
    public function produceOrder(int $listId, LineItemListOrderContext $context, array $basket)
    {
        $list = $this->listRepository->fetchOneListById($listId);

        $this->bridgeService->triggerOrder($list, $context, $basket);
    }

    /**
     * @param LineItemList $list
     */
    private function storeList(LineItemList $list)
    {
        $list = $this->listRepository
            ->addList($list);

        foreach ($list->references as $reference) {
            $this->referenceRepository
                ->addReference($list->id, $reference);
        }
    }

    /**
     * @param LineItemList $list
     * @param LineItemListOrderContext $orderContext
     */
    private function storeOrder(LineItemList $list, LineItemListOrderContext $orderContext)
    {
        $orderContext->listId = $list->id;

        $this->orderContextRepository
            ->addOrderContext($orderContext);
    }

    /**
     * @param OwnershipContext $ownershipContext
     * @param LineItemListSource $lineItemListSources
     * @return LineItemList
     */
    public function createListThroughCheckoutSource(OwnershipContext $ownershipContext, LineItemListSource $lineItemListSources): LineItemList
    {
        $list = $this->checkoutProvider->createList($lineItemListSources);
        $order = $this->checkoutProvider->createOrder($lineItemListSources);

        $list->debtorId = $ownershipContext->shopOwnerUserId;

        if ($ownershipContext->shopOwnerUserId !== $ownershipContext->identityId) {
            $order->contactId = $ownershipContext->identityId;
        }

        $this->storeList($list);
        $this->storeOrder($list, $order);

        return $list;
    }
}
