<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Api;

use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Role\Framework\RoleCrudService;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\Role\Framework\RoleSearchStruct;

class RoleController
{
    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @var GridHelper
     */
    private $requestHelper;

    /**
     * @var RoleCrudService
     */
    private $roleCrudService;

    /**
     * @param RoleRepository $roleRepository
     * @param GridHelper $requestHelper
     * @param RoleCrudService $roleCrudService
     */
    public function __construct(
        RoleRepository $roleRepository,
        GridHelper $requestHelper,
        RoleCrudService $roleCrudService
    ) {
        $this->roleRepository = $roleRepository;
        $this->requestHelper = $requestHelper;
        $this->roleCrudService = $roleCrudService;
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function getListAction(string $debtorEmail, Request $request): array
    {
        $search = new RoleSearchStruct();

        $this->requestHelper
            ->extractSearchDataInRestApi($request, $search);

        $roles = $this->roleRepository
            ->fetchList($search, $debtorEmail);

        $totalCount = $this->roleRepository
            ->fetchTotalCount($search, $debtorEmail);

        return ['success' => true, 'roles' => $roles, 'totalCount' => $totalCount];
    }

    /**
     * @param string $debtorEmail
     * @param int $roleId
     * @return array
     */
    public function getAction(string $debtorEmail, int $roleId): array
    {
        $role = $this->roleRepository
            ->fetchOneById($roleId);

        return ['success' => true, 'role' => $role];
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function createAction(string $debtorEmail, Request $request): array
    {
        $data = [
            'name' => $request->getParam('name'),
            'debtorEmail' => $debtorEmail,
        ];

        $newRecord = $this->roleCrudService
            ->createNewRecordRequest($data);

        $role = $this->roleCrudService
            ->create($newRecord);

        return ['success' => true, 'role' => $role];
    }

    /**
     * @param string $debtorEmail
     * @param int $roleId
     * @param Request $request
     * @return array
     */
    public function updateAction(string $debtorEmail, int $roleId, Request $request): array
    {
        $data = [
            'id' => $roleId,
            'name' => $request->getParam('name'),
            'debtorEmail' => $debtorEmail,
        ];

        $existingRecord = $this->roleCrudService
            ->createExistingRecordRequest($data);

        $role = $this->roleCrudService
            ->update($existingRecord);

        return ['success' => true, 'role' => $role];
    }

    /**
     * @param string $debtorEmail
     * @param int $roleId
     * @param Request $request
     * @return array
     */
    public function removeAction(string $debtorEmail, int $roleId): array
    {
        $data = [
            'id' => $roleId,
            'debtorEmail' => $debtorEmail,
        ];

        $existingRecord = $this->roleCrudService
            ->createExistingRecordRequest($data);

        $role = $this->roleCrudService
            ->remove($existingRecord);

        return ['success' => true, 'role' => $role];
    }
}
