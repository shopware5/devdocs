<?php declare(strict_types=1);

namespace Shopware\B2B\Order\Framework;

use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\UserOrderCredentials;

interface OrderRepositoryInterface extends GridRepository
{
    /**
     * @param UserOrderCredentials $userOrderCredentials
     * @param OrderSearchStruct $searchStruct
     * @return OrderEntity[]
     */
    public function fetchList(UserOrderCredentials $userOrderCredentials, OrderSearchStruct $searchStruct): array;

    /**
     * @param UserOrderCredentials $userOrderCredentials
     * @param OrderSearchStruct $searchStruct
     * @return int
     */
    public function fetchTotalCount(UserOrderCredentials $userOrderCredentials, OrderSearchStruct $searchStruct): int;

    /**
     * @param string $orderNumber
     * @param int $contactId
     * @param string $email
     */
    public function setOrderIdentity(string $orderNumber, int $contactId, string $email);
}
