<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\ProductPriceType;

use Shopware\B2B\Common\CrudEntity;
use Shopware\B2B\ContingentRule\Framework\ContingentRuleEntity;

class ProductPriceRuleEntity extends ContingentRuleEntity
{
    /**
     * @var int
     */
    public $productPrice;

    /**
     * {@inheritdoc}
     */
    public function toDatabaseArray(): array
    {
        return array_merge(
            parent::toDatabaseArray(),
            ['product_price' => $this->productPrice]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function fromDatabaseArray(array $data): CrudEntity
    {
        $this->productPrice = (int) $data['product_price'];

        return parent::fromDatabaseArray($data);
    }
}
