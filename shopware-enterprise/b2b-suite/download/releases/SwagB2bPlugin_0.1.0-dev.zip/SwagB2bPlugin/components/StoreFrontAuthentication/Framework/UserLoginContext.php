<?php declare(strict_types=1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

class UserLoginContext
{
    /**
     * @var int
     */
    public $subShopId;

    /**
     * @var string
     */
    public $customerGroupName;

    /**
     * @var int
     */
    public $paymentId;

    /**
     * @param int $subShopId
     * @param string $customerGroupName
     * @param int $paymentId
     */
    public function __construct(int $subShopId, string $customerGroupName, int $paymentId)
    {
        $this->subShopId = $subShopId;
        $this->customerGroupName = $customerGroupName;
        $this->paymentId = $paymentId;
    }
}
