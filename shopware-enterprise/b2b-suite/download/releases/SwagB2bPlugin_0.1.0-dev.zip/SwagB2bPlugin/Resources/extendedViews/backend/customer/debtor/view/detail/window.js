//{block name="backend/customer/view/detail/window"}
//{$smarty.block.parent}
/** global: Ext */
Ext.define('Shopware.apps.Customer.debtor.view.detail.Window', {
    override: 'Shopware.apps.Customer.view.detail.Window',

    setStores: function() {
        var me = this,
            elements = me.callParent(arguments);

        if(!me.record.get('id')) {
            return elements;
        }

        return Ext.Ajax.request({
            url: '{url controller=AttributeData action=loadData}',
            params: {
                _foreignKey: me.record.get('id'),
                _table: 's_user_attributes'
            },
            success: function(responseData) {
                var response = Ext.JSON.decode(responseData.responseText);
                
                me.baseFieldSet.checkbox.setValue(response.data['__attribute_b2b_is_debtor']);

                return elements;
            }
        });
    }

});
//{/block}