<?php declare(strict_types=1);

namespace Shopware\B2B\Cart\Framework;

class BlackListCartAccess implements CartAccessStrategyInterface
{
    /**
     * @var CartAccessStrategyInterface[]
     */
    private $strategies;

    /**
     * @param CartAccessStrategyInterface[] $strategies, ...
     */
    public function __construct(CartAccessStrategyInterface ... $strategies)
    {
        $this->strategies = $strategies;
    }

    /**
     * {@inheritdoc}
     */
    public function isAllowed(CartAccessContext $context, MessageCollection $messageCollection): bool
    {
        $allowed = true;
        foreach ($this->strategies as $strategy) {
            if (!$strategy->isAllowed($context, $messageCollection)) {
                $allowed = false;
            }
        }

        return $allowed;
    }
}
