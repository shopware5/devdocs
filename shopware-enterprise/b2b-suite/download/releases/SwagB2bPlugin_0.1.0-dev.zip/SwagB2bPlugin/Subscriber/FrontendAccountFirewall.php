<?php declare(strict_types=1);

namespace SwagB2bPlugin\Subscriber;

use Enlight\Event\SubscriberInterface;
use Symfony\Component\DependencyInjection\Container;

class FrontendAccountFirewall implements SubscriberInterface
{
    /**
     * @var array
     */
    private static $routes = [
        'account' => [
            'ignore' => ['logout'],
            'redirectTo' => 'b2bcontact',
        ],
        'address' => [
            'ignore' => [],
            'redirectTo' => 'b2baddress',
        ],
        'note' => [
            'ignore' => [],
            'redirectTo' => 'b2bcontact',
        ],
    ];
    /**
     * @var Container
     */
    private $container;

    /**
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Enlight_Controller_Action_PreDispatch_Frontend_Account' => 'redirectToController',
            'Enlight_Controller_Action_PreDispatch_Frontend_Address' => 'redirectToController',
            'Enlight_Controller_Action_PreDispatch_Frontend_Note' => 'redirectToController',
        ];
    }

    /**
     * @param \Enlight_Controller_ActionEventArgs $args
     */
    public function redirectToController(\Enlight_Controller_ActionEventArgs $args)
    {
        $authService = $this->container->get('b2b_front_auth.authentication_service');
        $requestedController = $args->getRequest()->getControllerName();
        $requestedAction = $args->getRequest()->getActionName();

        if (!$authService->isB2b()) {
            return;
        }

        $routingSettings = self::$routes[$requestedController];
        $actionsToIgnore = $routingSettings['ignore'];

        if (in_array($requestedAction, $actionsToIgnore, true)) {
            return;
        }

        $redirectToController = $routingSettings['redirectTo'];

        $args->getSubject()->redirect([
            'controller' => $redirectToController,
            'action' => 'index',
        ]);
    }
}
