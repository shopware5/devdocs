<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\CrudEntity;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Common\Repository\NotFoundException;

class RoleRepository implements GridRepository
{
    const TABLE_NAME =  'b2b_role';
    const TABLE_ALIAS = 'role';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     */
    public function __construct(Connection $connection, DbalHelper $dbalHelper)
    {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
    }

    /**
     * @param RoleSearchStruct $searchStruct
     * @param string $debtorEmail
     * @return array
     */
    public function fetchList(RoleSearchStruct $searchStruct, string $debtorEmail): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS .'.s_user_debtor_email = :email')
            ->setParameter('email', $debtorEmail);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper->applySearchStruct($searchStruct, $query);

        $statement = $query->execute();
        $rolesData = $statement->fetchAll(\PDO::FETCH_ASSOC);

        $roles = [];
        foreach ($rolesData as $roleData) {
            $roles[] = (new RoleEntity())->fromDatabaseArray($roleData);
        }

        return $roles;
    }

    /**
     * @param RoleSearchStruct $searchStruct
     * @param string $debtorEmail
     * @return int
     */
    public function fetchTotalCount(RoleSearchStruct $searchStruct, string $debtorEmail): int
    {
        $query = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS .'.s_user_debtor_email = :email')
            ->setParameter('email', $debtorEmail);

        $this->dbalHelper->applyFilters($searchStruct, $query);

        $statement = $query->execute();

        return (int) $statement->fetchColumn(0);
    }

    /**
     * @param RoleEntity $roleEntity
     * @throws \Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException
     * @return RoleEntity
     */
    public function removeRole(RoleEntity $roleEntity): RoleEntity
    {
        if ($roleEntity->isNew()) {
            throw new CanNotRemoveExistingRecordException('The role provided does not exist');
        }

        $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $roleEntity->id]
        );

        $roleEntity->id = null;

        return $roleEntity;
    }

    /**
     * @param RoleEntity $role
     * @throws \Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException
     * @return RoleEntity
     */
    public function addRole(RoleEntity $role): RoleEntity
    {
        if (!$role->isNew()) {
            throw new CanNotInsertExistingRecordException('The role provided already exists');
        }

        $this->connection->insert(
            self::TABLE_NAME,
            $role->toDatabaseArray()
        );

        $role->id = (int) $this->connection->lastInsertId();

        return $role;
    }

    /**
     * @param RoleEntity $role
     * @throws \Shopware\B2B\Common\Repository\CanNotUpdateExistingRecordException
     * @return RoleEntity
     */
    public function updateRole(RoleEntity $role): RoleEntity
    {
        if ($role->isNew()) {
            throw new CanNotUpdateExistingRecordException('The role provided does not exist');
        }

        $this->connection->update(
            self::TABLE_NAME,
            $role->toDatabaseArray(),
            ['id' => $role->id]
        );

        return $role;
    }

    /**
     * @param int $id
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return CrudEntity
     */
    public function fetchOneById(int $id): CrudEntity
    {
        $query = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS .'.id = :id')
            ->setParameter('id', $id);

        $statement = $query->execute();
        $roleData = $statement->fetch(\PDO::FETCH_ASSOC);

        if (!$roleData) {
            throw new NotFoundException(sprintf('Role not found for %s', $id));
        }

        return (new RoleEntity())->fromDatabaseArray($roleData);
    }

    /**
     * @param int $contactId
     * @param RoleSearchStruct $searchStruct
     * @param string $debtorEmail
     * @return array
     */
    public function fetchAllRolesAndCheckForContactAssignment(
        int $contactId,
        RoleSearchStruct $searchStruct,
        string $debtorEmail
    ): array {
        $query = $this->connection->createQueryBuilder()
            ->select(
                self::TABLE_ALIAS . '.id',
                self::TABLE_ALIAS . '.name',
                self::TABLE_ALIAS . '.s_user_debtor_email',
                'rc.id as assignmentId'
            )
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->leftJoin(
                self::TABLE_ALIAS,
                'b2b_role_contact',
                'rc',
                self::TABLE_ALIAS . '.id = rc.role_id and rc.debtor_contact_id = :id'
            )
            ->where(self::TABLE_ALIAS . '.s_user_debtor_email = :debtorEmail')
            ->setParameter('id', $contactId)
            ->setParameter('debtorEmail', $debtorEmail);

        if (!$searchStruct->orderBy) {
            $searchStruct->orderBy = self::TABLE_ALIAS . '.id';
            $searchStruct->orderDirection = 'DESC';
        }

        $this->dbalHelper->applySearchStruct($searchStruct, $query);

        $statement = $query->execute();
        $rolesData = $statement->fetchAll(\PDO::FETCH_ASSOC);

        $roles = [];
        foreach ($rolesData as $roleData) {
            $roles[] = (new RoleAssignmentEntity())->fromDatabaseArray($roleData);
        }

        return $roles;
    }

    /**
     * @param int $roleId
     * @param string $debtorEmail
     * @return array
     */
    public function fetchAllRolesAndCheckForContingentGroupAssignment(
        int $roleId,
        string $debtorEmail
    ): array {
        $query = $this->connection->createQueryBuilder()
            ->select(
                self::TABLE_ALIAS . '.id',
                self::TABLE_ALIAS . '.name',
                self::TABLE_ALIAS . '.s_user_debtor_email',
                'rcg.id as assignmentId'
            )
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->leftJoin(
                self::TABLE_ALIAS,
                'b2b_role_contingent_group',
                'rcg',
                self::TABLE_ALIAS . '.id = rcg.role_id'
            )
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->andWhere(self::TABLE_ALIAS . '.s_user_debtor_email = :debtorEmail')
            ->setParameter('id', $roleId)
            ->setParameter('debtorEmail', $debtorEmail)
            ->execute();

        $rolesData = $query->fetchAll(\PDO::FETCH_ASSOC);

        $roles = [];
        foreach ($rolesData as $roleData) {
            $roles[] = (new RoleAssignmentEntity())->fromDatabaseArray($roleData);
        }

        return $roles;
    }

    /**
     * @return string
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * @return string[]
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'name',
        ];
    }
}
