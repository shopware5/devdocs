<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Framework\DependencyInjection;

use Shopware\B2B\Acl\Framework\AclTable;
use Shopware\B2B\Acl\Framework\DependencyInjection\AclFrameworkConfiguration;
use Shopware\B2B\Address\Framework\DependencyInjection\AddressFrameworkConfiguration;
use Shopware\B2B\Common\Controller\DependencyInjection\ControllerConfiguration;
use Shopware\B2B\Common\DependencyInjectionConfiguration;
use Shopware\B2B\Common\Filter\DependencyInjection\FilterConfiguration;
use Shopware\B2B\Common\Repository\DependencyInjection\RepositoryConfiguration;
use Shopware\B2B\Common\Validator\DependencyInjection\ValidatorConfiguration;
use Shopware\B2B\Contact\Bridge\DependencyInjection\ContactBridgeConfiguration;
use Shopware\B2B\Contact\Framework\AclRouteAclTable;
use Shopware\B2B\Contact\Framework\AddressAclTable;
use Shopware\B2B\Contact\Framework\ContingentGroupAclTable;
use Shopware\B2B\Debtor\Framework\DependencyInjection\DebtorFrameworkConfiguration;
use Shopware\B2B\StoreFrontAuthentication\Framework\DependencyInjection\StoreFrontAuthenticationFrameworkConfiguration;

class ContactFrameworkConfiguration extends DependencyInjectionConfiguration
{
    /**
     * @return AclTable[]
     */
    public static function createAclTables()
    {
        return [
            new AddressAclTable(),
            new AclRouteAclTable(),
            new ContingentGroupAclTable(),
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getServiceFiles(): array
    {
        return [
            __DIR__ . '/framework-services.xml',
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getCompilerPasses(): array
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getDependingConfigurations(): array
    {
        return [
            new AddressFrameworkConfiguration(),
            new AclFrameworkConfiguration(),
            new ContactBridgeConfiguration(),
            new ControllerConfiguration(),
            new DebtorFrameworkConfiguration(),
            new FilterConfiguration(),
            new RepositoryConfiguration(),
            new StoreFrontAuthenticationFrameworkConfiguration(),
            new ValidatorConfiguration(),
        ];
    }
}
