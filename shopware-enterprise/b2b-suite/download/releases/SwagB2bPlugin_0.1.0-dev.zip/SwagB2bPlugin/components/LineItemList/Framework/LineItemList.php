<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

use Shopware\B2B\Common\CrudEntity;

class LineItemList implements CrudEntity
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var int
     */
    public $debtorId;

    /**
     * @var LineItemReference[]
     */
    public $references = [];

    /**
     * @var string
     */
    public $amount;

    /**
     * @var string
     */
    public $amountNet;

    /**
     * {@inheritdoc}
     */
    public function isNew(): bool
    {
        return ! (bool) $this->id;
    }

    /**
     * {@inheritdoc}
     */
    public function toDatabaseArray(): array
    {
        return [
            'id' => $this->id,
            's_user_debtor_id' => $this->debtorId,
            'amount' => $this->amount,
            'amount_net' => $this->amountNet,
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function fromDatabaseArray(array $data): CrudEntity
    {
        $this->id = (int) $data['id'];
        $this->debtorId = (int) $data['s_user_debtor_id'];
        $this->amount = $data['amount'];
        $this->amountNet = $data['amount_net'];

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'references' => $this->references,
        ];
    }
}
