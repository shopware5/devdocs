<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Framework;

use Shopware\B2B\Acl\Framework\AclContextResolverMain;
use Shopware\B2B\Acl\Framework\AclUnsupportedContextException;

class AclTableRoleContextResolver extends AclContextResolverMain
{
    /**
     * @param $context
     * @throws AclUnsupportedContextException
     * @return int
     */
    public function extractId($context): int
    {
        if (!$context instanceof RoleEntity || $context->isNew()) {
            throw new AclUnsupportedContextException();
        }

        return $context->id;
    }
}
