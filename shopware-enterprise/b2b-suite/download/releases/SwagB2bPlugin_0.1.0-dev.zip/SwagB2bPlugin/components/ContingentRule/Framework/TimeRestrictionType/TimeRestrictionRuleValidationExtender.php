<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\TimeRestrictionType;

use Shopware\B2B\Common\Validator\ValidationBuilder;
use Shopware\B2B\ContingentRule\Framework\ContingentRuleTypeValidationExtender;

class TimeRestrictionRuleValidationExtender implements ContingentRuleTypeValidationExtender
{
    /**
     * @var TimeRestrictionRuleEntity
     */
    private $timeRestrictionRuleEntity;

    /**
     * @param TimeRestrictionRuleEntity $timeRestrictionRuleEntity
     */
    public function __construct(TimeRestrictionRuleEntity $timeRestrictionRuleEntity)
    {
        $this->timeRestrictionRuleEntity = $timeRestrictionRuleEntity;
    }

    /**
     * @param ValidationBuilder $validationBuilder
     * @return ValidationBuilder
     */
    public function extendValidator(ValidationBuilder $validationBuilder): ValidationBuilder
    {
        return $validationBuilder

            ->validateThat('timeRestriction', $this->timeRestrictionRuleEntity->timeRestriction)
            ->isNotBlank()

            ->validateThat('value', $this->timeRestrictionRuleEntity->value)
            ->isNotBlank();
    }
}
