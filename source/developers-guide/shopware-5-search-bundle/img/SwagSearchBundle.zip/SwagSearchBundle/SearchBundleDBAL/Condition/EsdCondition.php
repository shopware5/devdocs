<?php

namespace ShopwarePlugins\SwagSearchBundle\SearchBundleDBAL\Condition;

use Shopware\Bundle\SearchBundle\ConditionInterface;

class EsdCondition implements ConditionInterface
{
    /**
     * @return string
     */
    public function getName()
    {
        return 'swag_search_bundle_esd';
    }

    /**
     * @inheritdoc
     */
    function jsonSerialize()
    {
        return get_object_vars($this);
    }

}