<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework;

use Shopware\B2B\Common\Repository\SearchStruct;

class ContingentRuleSearchStruct extends SearchStruct
{
}
