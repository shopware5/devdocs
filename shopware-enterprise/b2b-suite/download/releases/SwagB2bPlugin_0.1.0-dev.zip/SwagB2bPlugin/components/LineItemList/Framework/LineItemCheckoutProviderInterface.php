<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

interface LineItemCheckoutProviderInterface
{
    /**
     * @param LineItemListSource $source
     * @return LineItemListOrderContext
     */
    public function createOrder(LineItemListSource $source): LineItemListOrderContext;

    /**
     * @param LineItemListSource $source
     * @return LineItemList
     */
    public function createList(LineItemListSource $source): LineItemList;
}
