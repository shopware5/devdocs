<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Frontend;

use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\ContingentRule\Framework\ContingentRuleRepository;
use Shopware\B2B\ContingentRule\Framework\ContingentRuleService;

class TimeRestrictionController
{
    /**
     * @var ContingentRuleRepository
     */
    private $contingentRulesRepository;

    /**
     * @var ContingentRuleService
     */
    private $contingentRuleService;

    /**
     * @param ContingentRuleRepository $contingentRuleRepository
     * @param ContingentRuleService $contingentRuleService
     */
    public function __construct(ContingentRuleRepository $contingentRuleRepository, ContingentRuleService $contingentRuleService)
    {
        $this->contingentRulesRepository = $contingentRuleRepository;
        $this->contingentRuleService = $contingentRuleService;
    }

    /**
     * @return array
     */
    public function newAction(): array
    {
        return ['timeUnits' => $this->contingentRuleService->getTimeRestrictions()];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function editAction(Request $request): array
    {
        $id = (int) $request->requireParam('id');

        return [
            'rule' => $this->contingentRulesRepository->fetchOneById($id),
            'timeUnits' => $this->contingentRuleService->getTimeRestrictions(),
        ];
    }
}
