<?php declare(strict_types=1);

namespace Shopware\B2B\Debtor\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationRepositoryInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;

class DebtorRepository implements AuthenticationRepositoryInterface
{
    const TABLE_NAME = 's_user';

    const TABLE_ALIAS = 's_user';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param string $email
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return DebtorEntity
     */
    public function fetchOneByEmail(string $email): DebtorEntity
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('user.*')
            ->from(self::TABLE_NAME, 'user')
            ->innerJoin('user', 's_user_attributes', 'attributes', 'attributes.userID = user.id')
            ->where('user.email = :email')
            ->andWhere('attributes.b2b_is_debtor = 1')
            ->setParameter('email', $email)
            ->execute();

        $user = $statement->fetch(\PDO::FETCH_ASSOC);

        if (!$user) {
            throw new NotFoundException(sprintf('Debtor not found for %s', $email));
        }

        return (new DebtorEntity())->fromDatabaseArray($user);
    }

    /**
     * @param int $id
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return DebtorEntity
     */
    public function fetchOneById(int $id): DebtorEntity
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('user.*')
            ->from(self::TABLE_NAME, 'user')
            ->innerJoin('user', 's_user_attributes', 'attributes', 'attributes.userID = user.id')
            ->where('user.id = :id')
            ->andWhere('attributes.b2b_is_debtor = 1')
            ->setParameter('id', $id)
            ->execute();

        $user = $statement->fetch(\PDO::FETCH_ASSOC);

        if (!$user) {
            throw new NotFoundException(sprintf('Debtor not found for %s', $id));
        }

        return (new DebtorEntity())->fromDatabaseArray($user);
    }

    /**
     * @param string $email
     * @param LoginContextService $contextService
     * @throws NotFoundException
     * @return Identity
     */
    public function fetchIdentityByEmail(string $email, LoginContextService $contextService): Identity
    {
        $entity = $this->fetchOneByEmail($email);

        $authId = $contextService->getAuthId(__CLASS__, $email);

        return new DebtorIdentity($authId, (int) $entity->id, self::TABLE_NAME, $entity);
    }

    /**
     * @param string $email
     * @param LoginContextService $contextService
     * @param int $id
     * @throws NotFoundException
     * @return Identity
     */
    public function fetchIdentityById(int $id, LoginContextService $contextService): Identity
    {
        $entity = $this->fetchOneById($id);

        $authId = $contextService->getAuthId(__CLASS__, $entity->email);

        return new DebtorIdentity($authId, (int) $entity->id, self::TABLE_NAME, $entity);
    }

    /**
     * @param string $email
     * @return bool
     */
    public function hasDebtorWithEmail(string $email): bool
    {
        $count = $this->fetchDebtorWithEmailCount($email);

        return (bool) $count;
    }

    /**
     * @param string $email
     * @return int
     */
    public function fetchDebtorWithEmailCount(string $email): int
    {
        $statement = $this->connection->createQueryBuilder()
              ->select('COUNT(*)')
              ->from(self::TABLE_NAME, self::TABLE_ALIAS)
              ->where(self::TABLE_ALIAS . '.email = :email')
              ->setParameter('email', $email)
              ->execute();

        return (int) $statement->fetch(\PDO::FETCH_COLUMN);
    }
}
