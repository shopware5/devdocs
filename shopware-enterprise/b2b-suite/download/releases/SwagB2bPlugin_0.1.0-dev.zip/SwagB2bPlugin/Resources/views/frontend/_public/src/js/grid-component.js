/**
 * Handles selection of rows in the grid view.
 *
 * * store the last selected data-row-id to enable reloads
 * * mark the currently selected row
 * * reset the stored id on click on 'component-action-create'
 * * preselect a row by adding `data-b2b-grid-preselect="ID"` somewhere in its parent chain
 */
$.plugin('b2bGridComponent', {
    defaults: {
        gridContainerSelector: '.b2b--grid-container',

        selectRowSelector: 'tbody td:not(".col-actions")',

        tableRowSelector: 'tr',

        resetSelectionClickSelector: '.component-action-create',

        preselectedIdDataKey: 'b2bGridPreselect',

        isActiveClass: 'is--active',

        ajaxPanelSelector: '.b2b--ajax-panel',

        deleteItemSelector: '.component-action-delete',

        panelRefreshEvent: 'b2b--ajax-panel_refresh'
    },

    init: function() {
        var me = this,
            grid = me.$el.find(me.defaults.gridContainerSelector),
            preselectedId = grid.closest('*[data-b2b-grid-preselect]').data(me.defaults.preselectedIdDataKey),
            storedSelectedId = this.getStorageItem().data('gridSelectedId');

        this.applyDataAttributes();

        if(storedSelectedId) {
            me.selectRow(grid, storedSelectedId);
        } else if(preselectedId) {
            me.selectRow(grid, preselectedId);
        }

        me._on(
            grid.find(me.defaults.resetSelectionClickSelector),
            'click',
            function () {
                grid.find('tr').removeClass(me.defaults.isActiveClass);
                me.getStorageItem().removeData('gridSelectedId');
            }
        );

        me._on(
            grid.find(me.defaults.selectRowSelector),
            'click',
            $.proxy(me.onTableDataClick, me)
        );

        me._on(
            grid.find(me.defaults.deleteItemSelector),
            'click',
            $.proxy(me.onDeleteClick, me)
        );
    },

    onDeleteClick: function(event) {
        event.preventDefault();

        var me = this,
            $target = $(event.target),
            $form = $target.closest('form');

        $.ajax({
            'url': $form.attr('action'),
            'type': $form.attr('method'),
            'data': $form.serialize(),
            success: function() {
                me.$el.trigger(me.defaults.panelRefreshEvent);
            },
            error: function() {
                alert("An error occurred while deleting the item. Please try again.");
            }
        });
    },

    selectRow: function(grid, id) {
        grid.find('tr[data-row-id="' + id + '"]').addClass(this.defaults.isActiveClass);
    },

    onTableDataClick: function (event) {
        var me = this,
            $target = $(event.target),
            $parent = $target.parent(me.defaults.tableRowSelector),
            $siblings = $parent.siblings(me.defaults.tableRowSelector);

        $siblings.removeClass(me.defaults.isActiveClass);
        $parent.addClass(me.defaults.isActiveClass);
        me.getStorageItem().data('gridSelectedId', $parent.data('rowId'));
    },

    getStorageItem: function() {
        var me = this,
            panel = me.$el.closest(me.defaults.ajaxPanelSelector);

        if(!panel.length) {
            return $(document);
        }

        return panel;
    },

    destroy: function() {
        var me = this;
        me._destroy();
    }
});

$(document).b2bGridComponent();