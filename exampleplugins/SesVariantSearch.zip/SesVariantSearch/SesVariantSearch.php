<?php declare(strict_types=1);

namespace SesVariantSearch;

use Shopware\Components\Plugin;

class SesVariantSearch extends Plugin
{
}
