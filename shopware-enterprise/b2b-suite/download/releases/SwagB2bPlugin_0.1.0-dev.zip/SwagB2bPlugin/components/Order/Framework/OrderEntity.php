<?php declare(strict_types=1);

namespace Shopware\B2B\Order\Framework;

use Shopware\B2B\Common\CrudEntity;
use Shopware\B2B\LineItemList\Framework\LineItemList;

class OrderEntity extends LineItemList
{
    /**
     * @var string
     */
    public $orderNumber;

    /**
     * @var string
     */
    public $createdAt;

    /**
     * @var string
     */
    public $comment;

    /**
     * @var string
     */
    public $status;

    /**
     * @var string
     */
    public $orderReference;

    /**
     * @var string
     */
    public $requestedDeliveryDate;

    /**
     * @var int
     */
    public $orderId;

    /**
     * @var int
     */
    public $orderContextId;

    /**
     * {@inheritdoc}
     */
    public function fromDatabaseArray(array $data): CrudEntity
    {
        parent::fromDatabaseArray($data);

        // b2b_order_context
        $this->orderContextId = (int) $data['order_context_id'];
        $this->createdAt = $data['created_at'];
        $this->comment = $data['comment'];
        $this->orderNumber = $data['ordernumber'];

        // s_order
        $this->orderReference = $data['order_reference'];
        $this->status = $data['status'];
        $this->requestedDeliveryDate = $data['requested_delivery_date'];

        return $this;
    }
}
