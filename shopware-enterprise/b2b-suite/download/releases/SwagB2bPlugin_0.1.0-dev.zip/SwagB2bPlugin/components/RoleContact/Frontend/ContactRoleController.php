<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContact\Frontend;

use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\Role\Framework\RoleSearchStruct;
use Shopware\B2B\RoleContact\Framework\RoleContactAssignmentService;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class ContactRoleController
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @var RoleContactAssignmentService
     */
    private $roleContactAssign;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @param AuthenticationService $authenticationService
     * @param RoleRepository $roleRepository
     * @param RoleContactAssignmentService $roleContactAssign
     * @param GridHelper $gridHelper
     */
    public function __construct(
        AuthenticationService $authenticationService,
        RoleRepository $roleRepository,
        RoleContactAssignmentService $roleContactAssign,
        GridHelper $gridHelper
    ) {
        $this->authenticationService = $authenticationService;
        $this->roleRepository = $roleRepository;
        $this->roleContactAssign = $roleContactAssign;
        $this->gridHelper = $gridHelper;
    }

    /**
     * @param Request $request
     * @return array
     */
    public function indexAction(Request $request): array
    {
        return ['contactId' => $request->requireParam('contactId')];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $contactId = $request->requireParam('contactId');

        $debtorEmail = $this->authenticationService
            ->getIdentity()->getOwnershipContext()->shopOwnerEmail;

        $searchStruct = new RoleSearchStruct();
        $this->gridHelper->extractSearchDataInStoreFront($request, $searchStruct);

        $roles = $this->roleRepository
            ->fetchAllRolesAndCheckForContactAssignment((int) $contactId, $searchStruct, $debtorEmail);

        $rolesCount = $this->roleRepository->fetchTotalCount($searchStruct, $debtorEmail);

        $maxPage = $this->gridHelper->getMaxPage($rolesCount);

        $currentPage = (int) $this->gridHelper->getCurrentPage($request);

        $gridState = $this->gridHelper
            ->getGridState($request, $searchStruct, $roles, $maxPage, $currentPage);

        return [
            'contactId' => $contactId,
            'gridState' => $gridState,
        ];
    }

    /**
     * @param Request $request
     * @throws \Shopware\B2B\Common\Controller\B2bControllerForwardException
     */
    public function assignAction(Request $request)
    {
        $request->checkPost('grid', ['contactId' => $request->requireParam('contactId')]);

        $contactId = (int) $request->requireParam('contactId');
        $roleId = (int) $request->requireParam('roleId');

        if ($request->getParam('allow')) {
            $this->roleContactAssign->assign($roleId, $contactId);
        } else {
            $this->roleContactAssign->removeAssignment($roleId, $contactId);
        }

        throw new B2bControllerForwardException('grid', null, null, ['contactId' => $contactId]);
    }
}
