<?php declare(strict_types=1);

namespace Shopware\B2B\Address\Bridge;

use Doctrine\ORM\NoResultException;
use Enlight\Event\SubscriberInterface;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;
use Shopware\Components\Model\QueryBuilder;
use Shopware\Models\Customer\Address;

class AddressRepositorySubscriber implements SubscriberInterface
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var AclRepository
     */
    private $aclRepository;

    /**
     * @param AuthenticationService $authenticationService
     * @param AclRepository $aclRepository
     */
    public function __construct(
        AuthenticationService $authenticationService,
        AclRepository $aclRepository
    ) {
        $this->authenticationService = $authenticationService;
        $this->aclRepository = $aclRepository;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Shopware\Models\Customer\AddressRepository::getByUserQueryBuilder::after' => 'extendListingQuery',
            'Shopware\Models\Customer\AddressRepository::getOneByUser::after' => 'checkFetchOneQuery',
        ];
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function extendListingQuery(\Enlight_Hook_HookArgs $args)
    {
        if (!$this->authenticationService->isB2b()) {
            return;
        }

        $ownershipContext = $this->authenticationService->getIdentity()->getOwnershipContext();
        $allowedIds = $this->aclRepository
            ->getAllAllowedIds($ownershipContext);

        /** @var QueryBuilder $queryBuilder */
        $queryBuilder = $args->getReturn();
        $queryBuilder
            ->andWhere('address.id IN (:swagB2bAclAllowedIds)')
            ->setParameter('swagB2bAclAllowedIds', $allowedIds);
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     * @throws NoResultException No Address found. Reason: Record Access not allowed
     *                           important for shopware standard behavior
     */
    public function checkFetchOneQuery(\Enlight_Hook_HookArgs $args)
    {
        if (!$this->authenticationService->isB2b()) {
            return;
        }

        /** @var Address $address */
        $address = $args->getReturn();
        $ownershipContext = $this->authenticationService->getIdentity()->getOwnershipContext();

        if ($this->aclRepository->isAllowed($ownershipContext, $address->getId())) {
            return;
        }

        throw new NoResultException();
    }
}
