<?php declare(strict_types=1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

use Shopware\B2B\Common\Repository\NotFoundException;

class IdentityChainRepository implements AuthenticationRepositoryInterface
{
    /**
     * @var AuthenticationRepositoryInterface[]
     */
    private $authenticationRepositories;

    /**
     * @param AuthenticationRepositoryInterface[] $authenticationRepositories
     */
    public function __construct(array $authenticationRepositories)
    {
        $this->setRepositories($authenticationRepositories);
    }

    /**
     * @param AuthenticationRepositoryInterface[] $authenticationRepositories
     */
    public function setRepositories(array $authenticationRepositories)
    {
        $this->authenticationRepositories = [];

        foreach ($authenticationRepositories as $repository) {
            $this->addRepository($repository);
        }
    }

    /**
     * @param AuthenticationRepositoryInterface $repository
     */
    public function addRepository(AuthenticationRepositoryInterface $repository)
    {
        $this->authenticationRepositories[] = $repository;
    }

    /**
     * {@inheritdoc}
     */
    public function fetchIdentityByEmail(string $email, LoginContextService $contextService): Identity
    {
        foreach ($this->authenticationRepositories as $repository) {
            try {
                return $repository->fetchIdentityByEmail($email, $contextService);
            } catch (NotFoundException $e) {
                continue;
            }
        }

        throw new NotFoundException(sprintf('No identity found with email %s', $email));
    }
}
