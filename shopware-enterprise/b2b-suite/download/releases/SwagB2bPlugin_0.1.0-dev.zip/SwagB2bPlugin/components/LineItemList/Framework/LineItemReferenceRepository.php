<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\Common\Repository\CanNotInsertExistingRecordException;
use Shopware\B2B\Common\Repository\DbalHelper;

class LineItemReferenceRepository implements GridRepository
{
    const TABLE_NAME = 'b2b_line_item_reference';

    const TABLE_ALIAS = 'lineItem';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var DbalHelper
     */
    private $dbalHelper;

    /**
     * @param Connection $connection
     * @param DbalHelper $dbalHelper
     */
    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper
    ) {
        $this->connection = $connection;
        $this->dbalHelper = $dbalHelper;
    }

    /**
     * @param int $listId
     * @param LineItemReferenceSearchStruct $searchStruct
     * @return LineItemReference[]
     */
    public function fetchList(int $listId, LineItemReferenceSearchStruct $searchStruct): array
    {
        $queryBuilder = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.list_id = :listId')
            ->setParameter('listId', $listId);

        $this->dbalHelper->applyFilters($searchStruct, $queryBuilder);

        $rawItemReferences = $queryBuilder
            ->execute()
            ->fetchAll();

        $lineItemReferences = [];
        foreach ($rawItemReferences as $rawItemReference) {
            $lineItemReferences[] = (new LineItemReference())
                ->fromDatabaseArray($rawItemReference);
        }

        return $lineItemReferences;
    }

    /**
     * @param int $listId
     * @param LineItemReferenceSearchStruct $searchStruct
     * @return int
     */
    public function fetchTotalCount(int $listId, LineItemReferenceSearchStruct $searchStruct): int
    {
        $queryBuilder = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.list_id = :listId')
            ->setParameter('listId', $listId);

        $this->dbalHelper->applyFilters($searchStruct, $queryBuilder);

        return (int) $queryBuilder
            ->execute()
            ->fetchColumn();
    }

    /**
     * @param $listId
     * @return LineItemReference[]
     */
    public function fetchAllForList($listId): array
    {
        $lineItemData = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.list_id = :listId')
            ->setParameter('listId', $listId)
            ->execute()
            ->fetchAll();

        $lineItems = [];

        foreach ($lineItemData as $rawLineItem) {
            $lineItem = new LineItemReference();

            $lineItem->id = $rawLineItem['id'];
            $lineItem->referenceNumber = $rawLineItem['reference_number'];
            $lineItem->quantity = $rawLineItem['quantity'];
            $lineItem->comment = $rawLineItem['comment'];
            $lineItem->amountNet = $rawLineItem['amount_net'];
            $lineItem->amount = $rawLineItem['amount'];

            $lineItems[] = $lineItem;
        }

        return $lineItems;
    }

    /**
     * @param int $id
     * @return array
     */
    public function fetchReferenceById(int $id): array
    {
        return $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.id = :id')
            ->setParameter('id', $id)
            ->execute()
            ->fetch();
    }

    /**
     * @param int $id
     * @param LineItemReference $reference
     * @return LineItemReference
     */
    public function addReference(int $id, LineItemReference $reference): LineItemReference
    {
        if (!$reference->isNew()) {
            throw new CanNotInsertExistingRecordException('The list provided already exists');
        }

        $this->connection->insert(
            self::TABLE_NAME,
            array_merge(
                $reference->toDatabaseArray(),
                ['list_id' => $id]
            )
        );

        $reference->id = (int) $this->connection
            ->lastInsertId();

        return $reference;
    }

    /**
     * @param int $id
     * @param int $quantity
     * @param string $comment
     */
    public function updateReference(int $id, int $quantity, string $comment)
    {
        $this->connection->update(
            self::TABLE_NAME,
            [
                'quantity' => $quantity,
                'comment' => $comment,
            ],
            ['id' => $id]
        );
    }

    /**
     * @param $id
     */
    public function removeReference($id)
    {
        $this->connection->delete(
            self::TABLE_NAME,
            ['id' => $id]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function getMainTableAlias(): string
    {
        return self::TABLE_ALIAS;
    }

    /**
     * {@inheritdoc}
     */
    public function getFullTextSearchFields(): array
    {
        return [
            'reference_number',
            'comment',
        ];
    }
}
