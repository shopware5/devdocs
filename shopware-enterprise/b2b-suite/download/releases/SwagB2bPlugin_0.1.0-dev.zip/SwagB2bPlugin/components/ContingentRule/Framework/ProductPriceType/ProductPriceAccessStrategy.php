<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\ProductPriceType;

use Shopware\B2B\Cart\Framework\CartAccessContext;
use Shopware\B2B\Cart\Framework\CartAccessStrategyInterface;
use Shopware\B2B\Cart\Framework\MessageCollection;
use Shopware\B2B\OrderClearance\Framework\OrderProductItem;

class ProductPriceAccessStrategy implements CartAccessStrategyInterface
{
    /**
     * @var int
     */
    private $productPrice;

    /**
     * @param int $productPrice
     */
    public function __construct(int $productPrice)
    {
        $this->productPrice = $productPrice;
    }

    /**
     * {@inheritdoc}
     */
    public function isAllowed(CartAccessContext $context, MessageCollection $messageCollection): bool
    {
        $products = $context->orderClearanceEntity
            ->getItemsOfType(OrderProductItem::class);

        $productErrors = array_filter($products, function (OrderProductItem $product) {
            return $product->productPrice > $this->productPrice;
        });

        if (count($productErrors) === 0) {
            return true;
        }

        $messageCollection->addError(
            __CLASS__,
            'ProductPriceError',
            [
                'allowedValue' => $this->productPrice,
            ]
        );

        return false;
    }
}
