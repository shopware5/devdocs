<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\TimeRestrictionType;

use Shopware\B2B\Cart\Framework\CartAccessContext;
use Shopware\B2B\Cart\Framework\CartAccessStrategyInterface;
use Shopware\B2B\Cart\Framework\CartHistory;
use Shopware\B2B\Cart\Framework\MessageCollection;

class OrderAmountAccessStrategy implements CartAccessStrategyInterface
{
    /**
     * @var CartHistory
     */
    private $cartHistory;

    /**
     * @var int
     */
    private $value;

    /**
     * @param CartHistory $cartHistory
     * @param int $value
     */
    public function __construct(CartHistory $cartHistory, int $value)
    {
        $this->cartHistory = $cartHistory;
        $this->value = $value;
    }

    /**
     * {@inheritdoc}
     */
    public function isAllowed(CartAccessContext $context, MessageCollection $messageCollection): bool
    {
        $history = $this->cartHistory->orderAmount + $context->orderClearanceEntity->amountNet;

        if ($history <= $this->value) {
            return true;
        }

        $messageCollection->addError(
            __CLASS__,
            'OrderAmountError',
            [
                'allowedValue' => $this->value,
                'appliedValue' => $history,
                'cartHistory' => $this->cartHistory,
            ]
        );

        return false;
    }
}
