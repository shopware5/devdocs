<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Framework;

use Shopware\B2B\Contact\Framework\ContactEntity;
use Shopware\B2B\Order\Framework\OrderEntity;

class OrderClearanceEntity extends OrderEntity
{
    /**
     * @var int
     */
    public $quantity;

    /**
     * @var ContactEntity
     */
    public $contact;

    /**
     * @var OrderItemEntity[]
     */
    public $items = [];

    /**
     * @param string $className
     * @return OrderItemEntity[]
     */
    public function getItemsOfType(string $className): array
    {
        return array_filter($this->items, function (OrderItemEntity $itemEntity) use ($className) {
            return $itemEntity instanceof $className;
        });
    }
}
