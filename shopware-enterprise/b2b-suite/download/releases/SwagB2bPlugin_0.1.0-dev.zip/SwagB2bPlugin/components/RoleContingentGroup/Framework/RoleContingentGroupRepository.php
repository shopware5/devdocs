<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContingentGroup\Framework;

use Doctrine\DBAL\Connection;

/**
 * DB-Representation of role:contact assignment
 */
class RoleContingentGroupRepository
{
    const TABLE_NAME = 'b2b_role_contingent_group';

    const TABLE_ALIAS = 'roles_contingent_groups';

    /**
     * @var Connection
     */
    private $connection;

    /**
     * @param Connection $connection
     */
    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @param int $roleId
     * @param int $contingentGroupId
     */
    public function removeRoleContingentGroupAssignment(int $roleId, int $contingentGroupId)
    {
        $this->connection->delete(
            self::TABLE_NAME,
            [
                'role_id' => $roleId,
                'contingent_group_id' => $contingentGroupId,
            ]
        );
    }

    /**
     * @param int $roleId
     * @param int $contingentGroupId
     */
    public function assignRoleContingentGroup(int $roleId, int $contingentGroupId)
    {
        $data = [
            'role_id' => $roleId,
            'contingent_group_id' => $contingentGroupId,
        ];

        $this->connection->insert(
            self::TABLE_NAME,
            $data
        );
    }
}
