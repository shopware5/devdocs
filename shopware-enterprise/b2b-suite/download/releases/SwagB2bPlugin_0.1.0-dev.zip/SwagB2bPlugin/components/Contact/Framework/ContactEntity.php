<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Framework;

use Shopware\B2B\Common\CrudEntity;
use Shopware\B2B\Debtor\Framework\DebtorEntity;

class ContactEntity implements CrudEntity
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var string
     */
    public $password;

    /**
     * @var string
     */
    public $encoder;

    /**
     * @var string
     */
    public $email;

    /**
     * @var bool
     */
    public $active;

    /**
     * @var int
     */
    public $language;

    /**
     * @var string
     */
    public $title;

    /**
     * @var string
     */
    public $salutation;

    /**
     * @var string
     */
    public $firstName;

    /**
     * @var string
     */
    public $lastName;

    /**
     * @var
     */
    public $department;

    /**
     * @var string
     */
    public $debtorEmail;

    /**
     * @var null|DebtorEntity
     */
    public $debtor;

    /**
     * {@inheritdoc}
     */
    public function isNew(): bool
    {
        return ! (bool) $this->id;
    }

    /**
     * {@inheritdoc}
     */
    public function toDatabaseArray(): array
    {
        return [
            'id' => $this->id,
            'password' => $this->password,
            'encoder' => $this->encoder,
            'email' => $this->email,
            'active' => $this->active ? 1 : 0,
            'language' => $this->language,
            'title' => $this->title,
            'salutation' => $this->salutation,
            'firstname' => $this->firstName,
            'lastname' => $this->lastName,
            'department' => $this->department,
            's_user_debtor_email' => $this->debtorEmail,
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function fromDatabaseArray(array $contactData): CrudEntity
    {
        $this->id = (int) $contactData['id'];
        $this->password = $contactData['password'];
        $this->encoder = $contactData['encoder'];
        $this->email = $contactData['email'];
        $this->active = (bool) $contactData['active'];
        $this->language = (int) $contactData['language'];
        $this->title = (string) $contactData['title'];
        $this->salutation = (string) $contactData['salutation'];
        $this->firstName = $contactData['firstname'];
        $this->lastName = $contactData['lastname'];
        $this->department = $contactData['department'];
        $this->debtorEmail = (string) $contactData['s_user_debtor_email'];

        return $this;
    }

    /**
     * @param array $data
     */
    public function setData(array $data)
    {
        foreach ($data as $key => $value) {
            if (!property_exists($this, $key)) {
                continue;
            }

            $this->{$key} = $value;
        }

        $this->active = (bool) $this->active;
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        $contactArray = get_object_vars($this);

        unset($contactArray['debtor']);

        return $contactArray;
    }

    /**
     * {@inheritdoc}
     */
    public function jsonSerialize(): array
    {
        return $this->toArray();
    }
}
