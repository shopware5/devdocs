<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Frontend;

use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\ContingentRule\Framework\ContingentRuleRepository;

class ProductOrderNumberController
{
    /**
     * @var ContingentRuleRepository
     */
    private $contingentRuleRepository;

    /**
     * @param ContingentRuleRepository $contingentRuleRepository
     */
    public function __construct(ContingentRuleRepository $contingentRuleRepository)
    {
        $this->contingentRuleRepository = $contingentRuleRepository;
    }

    public function newAction()
    {
        //nth
    }

    /**
     * @param Request $request
     * @return array
     */
    public function editAction(Request $request): array
    {
        $id = (int) $request->requireParam('id');

        return ['rule' => $this->contingentRuleRepository->fetchOneById($id)];
    }
}
