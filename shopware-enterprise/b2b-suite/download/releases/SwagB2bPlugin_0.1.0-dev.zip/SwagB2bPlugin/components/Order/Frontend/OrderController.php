<?php declare(strict_types=1);

namespace Shopware\B2B\Order\Frontend;

use Shopware\B2B\AuditLog\Framework\AuditLogRepository;
use Shopware\B2B\AuditLog\Framework\AuditLogSearchStruct;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContextRepository;
use Shopware\B2B\Order\Bridge\OrderRepository;
use Shopware\B2B\Order\Framework\OrderRepositoryInterface;
use Shopware\B2B\Order\Framework\OrderSearchStruct;
use Shopware\B2B\OrderClearance\Framework\OrderClearanceAuditLogService;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class OrderController
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var GridHelper
     */
    private $orderGridHelper;

    /**
     * @var OrderClearanceAuditLogService
     */
    private $orderClearanceAuditLogService;

    /**
     * @var LineItemListOrderContextRepository
     */
    private $orderContextRepository;

    /**
     * @var AuditLogRepository
     */
    private $auditLogRepository;
    /**
     * @var GridHelper
     */
    private $auditLogGridHelper;

    /**
     * @param AuthenticationService $authenticationService
     * @param OrderRepository $orderRepository
     * @param GridHelper $orderGridHelper
     * @param OrderClearanceAuditLogService $orderClearanceAuditLogService
     * @param LineItemListOrderContextRepository $orderContextRepository
     * @param AuditLogRepository $auditLogRepository
     * @param GridHelper $auditLogGridHelper
     */
    public function __construct(
        AuthenticationService $authenticationService,
        OrderRepository $orderRepository,
        GridHelper $orderGridHelper,
        OrderClearanceAuditLogService $orderClearanceAuditLogService,
        LineItemListOrderContextRepository $orderContextRepository,
        AuditLogRepository $auditLogRepository,
        GridHelper $auditLogGridHelper
    ) {
        $this->authenticationService = $authenticationService;
        $this->orderRepository = $orderRepository;
        $this->orderGridHelper = $orderGridHelper;
        $this->orderClearanceAuditLogService = $orderClearanceAuditLogService;
        $this->orderContextRepository = $orderContextRepository;
        $this->auditLogRepository = $auditLogRepository;
        $this->auditLogGridHelper = $auditLogGridHelper;
    }

    public function indexAction()
    {
        //nth
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $orderCredentials = $this->authenticationService
            ->getIdentity()
            ->getOwnershipContext();

        $searchStruct = new OrderSearchStruct();

        $this->orderGridHelper
            ->extractSearchDataInStoreFront($request, $searchStruct);

        $order = $this->orderRepository
            ->fetchLists($orderCredentials, $searchStruct);

        $totalCount = $this->orderRepository
            ->fetchTotalCount($orderCredentials, $searchStruct);

        $maxPage = $this->orderGridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $request->getParam('page', 1);

        $orderGridState = $this->orderGridHelper
            ->getGridState($request, $searchStruct, $order, $maxPage, $currentPage);

        return [
            'orderGrid' => $orderGridState,
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function detailAction(Request $request): array
    {
        $listId = (int) $request->requireParam('listId');

        $orderContext = $this->orderContextRepository->fetchOneOrderContextByListId($listId);

        return [
            'list' => $this->orderRepository->fetchOneListById($listId),
            'orderContext' => $orderContext,
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function logAction(Request $request): array
    {
        $orderContextId = (int) $request->requireParam('orderContextId');

        $searchStruct = new AuditLogSearchStruct();

        $this->orderGridHelper
            ->extractSearchDataInStoreFront($request, $searchStruct);

        $logItems = $this->orderClearanceAuditLogService
            ->getOrderClearanceAuditLog($orderContextId, $searchStruct);

        $totalCount = $this->auditLogRepository
            ->fetchTotalCount('b2b_order_context', $orderContextId, $searchStruct);

        $maxPage = $this->orderGridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $request->getParam('page', 1);

        $orderGridState = $this->auditLogGridHelper
            ->getGridState($request, $searchStruct, $logItems, $maxPage, $currentPage);

        return [
            'gridState' => $orderGridState,
            'orderContextId' => $orderContextId,
        ];
    }
}
