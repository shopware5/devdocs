<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

use Shopware\B2B\Common\CrudEntity;

class LineItemReference implements CrudEntity
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var string
     */
    public $referenceNumber;

    /**
     * @var int
     */
    public $quantity;

     /**
     * @var string
     */
    public $comment;

    /**
     * @var string
     */
    public $amount;

    /**
     * @var string
     */
    public $amountNet;

    /**
     * @return bool
     */
    public function isNew(): bool
    {
        return ! (bool) $this->id;
    }

    /**
     * @return array
     */
    public function toDatabaseArray(): array
    {
        return [
            'id' => $this->id,
            'reference_number' => $this->referenceNumber,
            'quantity' => $this->quantity,
            'comment' => (string) $this->comment,
            'amount' => $this->amount,
            'amount_net' => $this->amountNet,
        ];
    }

    /**
     * @param array $data
     * @return CrudEntity
     */
    public function fromDatabaseArray(array $data): CrudEntity
    {
        $this->id = (int) $data['id'];
        $this->referenceNumber = (string) $data['reference_number'];
        $this->quantity = (string) $data['quantity'];
        $this->comment = (string) $data['comment'];
        $this->amount = $data['amount'];
        $this->amountNet = $data['amount_net'];

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'referenceNumber' => $this->referenceNumber,
            'quantity' => $this->quantity,
            'comment' => $this->comment,
        ];
    }
}
