<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Framework;

class OrderProductItem extends OrderItemEntity
{
    /**
     * @var string
     */
    public $productOrderNumber;
}
