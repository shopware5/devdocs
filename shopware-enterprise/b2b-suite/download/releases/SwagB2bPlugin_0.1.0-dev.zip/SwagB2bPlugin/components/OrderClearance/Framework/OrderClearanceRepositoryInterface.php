<?php declare(strict_types=1);

namespace Shopware\B2B\OrderClearance\Framework;

use Shopware\B2B\Common\Controller\GridRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

interface OrderClearanceRepositoryInterface extends GridRepository
{
    /**
     * @param int $orderId
     * @return OrderClearanceEntity
     */
    public function fetchOneByOrderContextId(int $orderId): OrderClearanceEntity;

    /**
     * @param Identity $identity
     * @return array|OrderClearanceEntity[]
     */
    public function fetchAllOrderClearances(Identity $identity): array;

    /**
     * @param Identity $identity
     * @param int $orderContextId
     * @return bool
     */
    public function belongsOrderContextIdToDebtor(Identity $identity, int $orderContextId): bool;

    /**
     * @param int $orderContextId
     * @param string $comment
     */
    public function acceptOrder(int $orderContextId, string $comment);

    /**
     * @param int $orderContextId
     * @param string $comment
     */
    public function declineOrder(int $orderContextId, string $comment);

    /**
     * @param int $orderContextId
     */
    public function deleteOrder(int $orderContextId);

    /**
     * @param int $orderContextId
     */
    public function sendToOrderClearance(int $orderContextId);
}
