<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Bridge;

use Shopware\B2B\LineItemList\Framework\LineItemList;
use Shopware\B2B\LineItemList\Framework\LineItemReference;
use Shopware\B2B\Shop\Bridge\ShopContextFactory;
use Shopware\Bundle\ESIndexingBundle\Struct\Product;
use Shopware\Bundle\StoreFrontBundle\Service\ProductServiceInterface;

class ProductProvider
{
    /**
     * @var ProductServiceInterface
     */
    private $productService;

    /**
     * @var ShopContextFactory
     */
    private $contextFactory;

    /**
     * @param ProductServiceInterface $productService
     * @param ShopContextFactory $contextFactory
     */
    public function __construct(
        ProductServiceInterface $productService,
        ShopContextFactory $contextFactory
    ) {
        $this->productService = $productService;
        $this->contextFactory = $contextFactory;
    }

    /**
     * @param LineItemList $list
     */
    public function updateList(LineItemList $list)
    {
        $productNumbers = array_map(function (LineItemReference $reference) {
            return $reference->referenceNumber;
        }, $list->references);

        $shopContext = $this->contextFactory
            ->create(1);

        $products = @$this->productService
            ->getList($productNumbers, $shopContext);

        $totalAmount = 0;
        $totalAmountNet = 0;

        foreach ($productNumbers as $productNumber) {
            $reference = $this->findReference($list, $productNumber);

            $this->updateReferenceFromProduct($products, $productNumber, $reference);

            $totalAmount += $reference->quantity * $reference->amount;
            $totalAmountNet += $reference->quantity * $reference->amountNet;
        }

        $list->amount = $totalAmount;
        $list->amountNet = $totalAmountNet;
    }

    /**
     * @param LineItemList $list
     * @param string $productNumber
     * @return LineItemReference
     */
    private function findReference(LineItemList $list, string $productNumber): LineItemReference
    {
        $foundIndex = false;
        foreach ($list->references as $index => $currentReference) {
            if ($currentReference->referenceNumber === $productNumber) {
                $foundIndex = $index;
                break;
            }
        }

        return $list->references[$foundIndex];
    }

    /**
     * @param Product[] $products
     * @param string $productNumber
     * @param LineItemReference $reference
     */
    private function updateReferenceFromProduct(array $products, string $productNumber, LineItemReference $reference)
    {
        $product = null;

        foreach ($products as $currentProduct) {
            if ($currentProduct->getNumber() === $productNumber) {
                $product = $currentProduct;
                break;
            }
        }

        if (!$product) {
            return;
        }

        $reference->amount = $product->getCheapestPrice()->getCalculatedPrice();
        $reference->amountNet = $product->getCheapestPriceRule()->getPrice();
    }
}
