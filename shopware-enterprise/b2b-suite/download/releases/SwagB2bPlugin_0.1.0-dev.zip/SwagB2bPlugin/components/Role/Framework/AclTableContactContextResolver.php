<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Framework;

use Shopware\B2B\Acl\Framework\AclContextResolverMN;
use Shopware\B2B\Acl\Framework\AclUnsupportedContextException;
use Shopware\B2B\Contact\Framework\ContactEntity;
use Shopware\B2B\Contact\Framework\ContactIdentity;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class AclTableContactContextResolver extends AclContextResolverMN
{
    /**
     * {@inheritdoc}
     */
    public function __construct()
    {
        parent::__construct(
            'b2b_role_contact',
            'debtor_contact_id',
            'role_id'
        );
    }

    /**
     * @param $context
     * @throws AclUnsupportedContextException
     * @return int
     */
    public function extractId($context): int
    {
        if ($context instanceof OwnershipContext && is_a($context->identityClassName, ContactIdentity::class, true)) {
            return $context->identityId;
        }

        if ($context instanceof ContactEntity) {
            return $context->id;
        }

        throw new AclUnsupportedContextException();
    }
}
