<?php declare(strict_types = 1);

namespace B2bAcl\Offer;

use Shopware\B2B\Common\Repository\SearchStruct;

class OfferSearchStruct extends SearchStruct
{
}
