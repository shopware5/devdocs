<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Bridge;

use Shopware\B2B\LineItemList\Framework\LineItemCheckoutProviderInterface;
use Shopware\B2B\LineItemList\Framework\LineItemList;
use Shopware\B2B\LineItemList\Framework\LineItemListOrderContext;
use Shopware\B2B\LineItemList\Framework\LineItemListSource;
use Shopware\B2B\LineItemList\Framework\LineItemReference;

class LineItemCheckoutProvider implements LineItemCheckoutProviderInterface
{
    /**
     * @var LineItemBridgeRepository
     */
    private $bridgeRepository;

    /**
     * @param LineItemBridgeRepository $bridgeRepository
     */
    public function __construct(LineItemBridgeRepository $bridgeRepository)
    {
        $this->bridgeRepository = $bridgeRepository;
    }

    /**
     * @param LineItemListSource $source
     * @return LineItemListOrderContext
     */
    public function createOrder(LineItemListSource $source): LineItemListOrderContext
    {
        $source = $this->testSource($source);
        $orderData = $this->bridgeRepository->fetchOrderByOrderNumber($source->orderNumber);

        $order = new LineItemListOrderContext();
        $order->billingAddressId = $source->billingAddressId;
        $order->shippingAddressId = $source->shippingAddressId;
        $order->orderNumber = $source->orderNumber;
        $order->shopUserId = $orderData['userID'];
        $order->paymentId = $orderData['paymentID'];
        $order->shippingId = $orderData['dispatchID'];
        $order->comment = $orderData['customercomment'];
        $order->deviceType = $orderData['deviceType'];
        $order->statusId = $orderData['status'];
        $order->orderId = $orderData['id'];

        return $order;
    }

    /**
     * @param LineItemListSource $source
     * @return LineItemList
     */
    public function createList(LineItemListSource $source): LineItemList
    {
        $source = $this->testSource($source);

        $list = new LineItemList();
        $list->references = $this->loadReferencesFromOrderNumber($source->orderNumber);

        $this->extendReferencesFromCart($source, $list);

        $list->amount = $source->basketData['AmountNumeric'];
        $list->amountNet = $source->basketData['AmountNetNumeric'];

        return $list;
    }

    /**
     * @param string $orderNumber
     * @return array
     */
    private function loadReferencesFromOrderNumber(string $orderNumber): array
    {
        $orderDetails = $this->bridgeRepository->fetchOrderDetailsByOrderNumber($orderNumber);

        $references = [];
        foreach ($orderDetails as $shopLineItem) {
            $reference = new LineItemReference();

            $reference->referenceNumber = $shopLineItem['articleordernumber'];
            $reference->quantity = (int) $shopLineItem['quantity'];

            $references[$shopLineItem['articleordernumber']] = $reference;
        }

        return $references;
    }

    /**
     * @param LineItemCheckoutSource $source
     * @param LineItemList $list
     */
    private function extendReferencesFromCart(LineItemCheckoutSource $source, LineItemList $list)
    {
        foreach ($source->basketData['content'] as $shopLineItem) {
            $orderNumber = $shopLineItem['ordernumber'];

            /** @var LineItemReference $reference */
            $reference = $list->references[$orderNumber];

            $reference->amount = $shopLineItem['price'];
            $reference->amountNet = $shopLineItem['netprice'];
        }
    }

    /**
     * @param LineItemListSource $source
     * @throws \InvalidArgumentException
     * @return LineItemCheckoutSource
     */
    private function testSource(LineItemListSource $source): LineItemCheckoutSource
    {
        if (!$source instanceof LineItemCheckoutSource) {
            throw new \InvalidArgumentException('Invalid source class provided');
        }

        return $source;
    }
}
