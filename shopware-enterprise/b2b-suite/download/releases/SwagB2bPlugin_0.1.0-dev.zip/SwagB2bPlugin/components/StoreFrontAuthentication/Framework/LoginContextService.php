<?php declare(strict_types = 1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

class LoginContextService
{
    /**
     * @var StoreFrontAuthenticationRepository
     */
    private $authenticationRepository;

    /**
     * @param StoreFrontAuthenticationRepository $authenticationRepository
     */
    public function __construct(StoreFrontAuthenticationRepository $authenticationRepository)
    {
        $this->authenticationRepository = $authenticationRepository;
    }

    /**
     * @param string $providerClass
     * @param string $email
     * @param int $contextOwnerId
     * @return int
     */
    public function getAuthId(string $providerClass, string $email, int $contextOwnerId = null): int
    {
        $authId = $this->authenticationRepository->fetchIdByProviderData($providerClass, $email);

        if (!$authId) {
            $authId = $this->authenticationRepository
                ->createAuthContextEntry($contextOwnerId, $providerClass, $email);
        }

        return $authId;
    }
}
