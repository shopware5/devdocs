<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentGroup\Frontend;

use Shopware\B2B\Common\Controller\B2bControllerForwardException;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Common\Repository\CanNotRemoveExistingRecordException;
use Shopware\B2B\Common\Validator\ValidationException;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupCrudService;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupRepository;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupSearchStruct;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class ContingentGroupController
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var ContingentGroupRepository
     */
    private $groupRepository;

    /**
     * @var ContingentGroupCrudService
     */
    private $groupCrudService;

    /**
     * @var GridHelper
     */
    private $gridHelper;

    /**
     * @param AuthenticationService $authenticationService
     * @param ContingentGroupRepository $groupRepository
     * @param ContingentGroupCrudService $groupCrudService
     * @param GridHelper $gridHelper
     */
    public function __construct(
        AuthenticationService $authenticationService,
        ContingentGroupRepository $groupRepository,
        ContingentGroupCrudService $groupCrudService,
        GridHelper $gridHelper
    ) {
        $this->authenticationService = $authenticationService;
        $this->groupRepository = $groupRepository;
        $this->groupCrudService = $groupCrudService;
        $this->gridHelper = $gridHelper;
    }

    public function indexAction()
    {
        //nth
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $ownershipContext = $this->authenticationService->getIdentity()->getOwnershipContext();
        $searchStruct = new ContingentGroupSearchStruct();

        $this->gridHelper
            ->extractSearchDataInStoreFront($request, $searchStruct);

        $contingentGroups = $this->groupRepository
            ->fetchList($ownershipContext, $searchStruct);

        $totalCount = $this->groupRepository
            ->fetchTotalCount($ownershipContext, $searchStruct);

        $maxPage = $this->gridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $request->getParam('page', 1);

        $gridState = $this->gridHelper
            ->getGridState($request, $searchStruct, $contingentGroups, $maxPage, $currentPage);

        return [
            'gridState' => $gridState,
        ];
    }

    /**
     * @return array
     */
    public function newAction(): array
    {
        return $this->gridHelper->getValidationResponse('contingentGroup');
    }

    /**
     * @param Request $request
     * @throws B2bControllerForwardException
     */
    public function createAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();

        $serviceRequest = $this->groupCrudService->createNewRecordRequest($post);

        $identity = $this->authenticationService->getIdentity();

        try {
            $contingentGroup = $this->groupCrudService
                ->create($serviceRequest, $identity->getOwnershipContext());
        } catch (ValidationException $e) {
            $this->gridHelper->pushValidationException($e);
            throw new B2bControllerForwardException('new');
        }

        throw new B2bControllerForwardException('detail', null, null, ['id' => $contingentGroup->id]);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function detailAction(Request $request): array
    {
        return ['id' => (int) $request->requireParam('id')];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function editAction(Request $request): array
    {
        $id = (int) $request->requireParam('id');

        $validationResponse = $this->gridHelper->getValidationResponse('contingentGroup');

        return array_merge(
            ['contingentGroup' => $this->groupRepository->fetchOneById((int) $id)],
            $validationResponse
        );
    }

    /**
     * @param Request $request
     * @throws B2bControllerForwardException
     */
    public function updateAction(Request $request)
    {
        $request->checkPost();

        $post = $request->getPost();

        $ownershipContext = $this->authenticationService->getIdentity()->getOwnershipContext();
        $serviceRequest = $this->groupCrudService->createExistingRecordRequest($post);

        try {
            $this->groupCrudService
                ->update($serviceRequest, $ownershipContext);
        } catch (ValidationException $e) {
            $this->gridHelper
                ->pushValidationException($e);
        }

        throw new B2bControllerForwardException('edit', null, null, ['id' => $serviceRequest->requireParam('id')]);
    }

    /**
     * @param Request $request
     */
    public function removeAction(Request $request)
    {
        $request->checkPost();

        $serviceRequest = $this->groupCrudService
            ->createExistingRecordRequest($request->getPost());

        try {
            $this->groupCrudService->remove($serviceRequest);
        } catch (CanNotRemoveExistingRecordException $e) {
            // nth
        }

        throw new B2bControllerForwardException('grid');
    }
}
