<?php declare(strict_types=1);

namespace Shopware\B2B\Acl\Framework;

use Doctrine\DBAL\Query\QueryBuilder;

/**
 *  A default implementation for through M:N relations related contexts.
 */
abstract class AclContextResolverMN extends AclContextResolver
{
    /**
     * @var string
     */
    private $joinTableName;

    /**
     * @var string
     */
    private $joinConditionFieldName;

    /**
     * @var string
     */
    private $whereConditionFieldName;

    /**
     * @param string $joinTableName
     * @param string $whereConditionFieldName
     * @param string $joinConditionFieldName
     */
    public function __construct(
        string $joinTableName,
        string $whereConditionFieldName,
        string $joinConditionFieldName
    ) {
        $this->joinTableName = $joinTableName;
        $this->whereConditionFieldName = $whereConditionFieldName;
        $this->joinConditionFieldName = $joinConditionFieldName;
    }

    /**
     * {@inheritdoc}
     */
    public function getQuery(string $aclTableName, int $contextId, QueryBuilder $queryBuilder): AclQuery
    {
        $mainPrefix = $this->getNextPrefix();
        $joinPrefix = $this->getNextPrefix();

        $queryBuilder
            ->select($mainPrefix . '.*')
            ->from($aclTableName, $mainPrefix)
            ->innerJoin(
                $mainPrefix,
                $this->joinTableName,
                $joinPrefix,
                $mainPrefix . '.entity_id = ' . $joinPrefix . '.' . $this->joinConditionFieldName . ''
            )
            ->where($joinPrefix . '.' . $this->whereConditionFieldName . ' = :p_' . $mainPrefix)
            ->setParameter('p_' . $mainPrefix, $contextId);

        return (new AclQuery())->fromQueryBuilder($queryBuilder);
    }

    /**
     * @return bool
     */
    public function isMainContext(): bool
    {
        return false;
    }
}
