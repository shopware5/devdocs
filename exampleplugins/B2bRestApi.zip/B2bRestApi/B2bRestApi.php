<?php declare(strict_types=1);

namespace B2bRestApi;

use Shopware\Components\Plugin;

class B2bRestApi extends Plugin
{
}
