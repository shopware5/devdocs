<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\ProductOrderNumberType;

use Shopware\B2B\Common\CrudEntity;
use Shopware\B2B\ContingentRule\Framework\ContingentRuleEntity;

class ProductOrderNumberRuleEntity extends ContingentRuleEntity
{
    /**
     * @var string
     */
    public $productOrderNumber;

    /**
     * {@inheritdoc}
     */
    public function toDatabaseArray(): array
    {
        return array_merge(
            parent::toDatabaseArray(),
            ['product_order_number' => $this->productOrderNumber]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function fromDatabaseArray(array $data): CrudEntity
    {
        $this->productOrderNumber = (string) $data['product_order_number'];

        return parent::fromDatabaseArray($data);
    }
}
