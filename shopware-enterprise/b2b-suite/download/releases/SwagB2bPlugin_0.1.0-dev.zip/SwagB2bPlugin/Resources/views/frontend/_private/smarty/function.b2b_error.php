<?php declare(strict_types=1);
/**
 * Renders sub requests for the B2B suite. As this component is used for catching contingent errors
 * which will be displayed as shopware error template component.
 *
 * @param array $params
 * @return string|false
 */
function smarty_function_b2b_error($params)
{
    $snippetNamespace = Shopware()->Snippets()->getNamespace('frontend/plugins/b2b_debtor_plugin');
    $template = Shopware()->Template();

    $errors = [];
    $errors[] = $snippetNamespace->get('ConfirmErrorContingentRule');

    /** @var \Shopware\B2B\Cart\Framework\ErrorMessage $error */
    foreach ($params['list'] as $error) {
        $errorParams = $error->params;
        $allowedValue = $errorParams['allowedValue'];

        $currencyValueClasses = [
            \Shopware\B2B\ContingentRule\Framework\TimeRestrictionType\OrderAmountAccessStrategy::class,
            \Shopware\B2B\ContingentRule\Framework\ProductPriceType\ProductPriceAccessStrategy::class,
        ];

        if (in_array($error->sender, $currencyValueClasses, true)) {
            $allowedValue = $template->fetch('string: {"' . $allowedValue . '"|currency}');
        }

        $errors[] = sprintf(
            $snippetNamespace->get($error->error),
            $snippetNamespace->get($errorParams['cartHistory']->timeRestriction),
            $allowedValue
        );
    }

    $template->assign([
        'type' => 'error',
        'list' => $errors,
    ]);

    return $template->fetch('frontend/_includes/messages.tpl');
}
