<?php declare(strict_types=1);

namespace Shopware\B2B\StoreFrontAuthentication\Framework;

use Shopware\B2B\Common\Repository\NotFoundException;

interface AuthenticationRepositoryInterface
{
    /**
     * @param string $email
     * @param LoginContextService $contextService
     * @throws NotFoundException
     * @return Identity
     */
    public function fetchIdentityByEmail(string $email, LoginContextService $contextService): Identity;
}
