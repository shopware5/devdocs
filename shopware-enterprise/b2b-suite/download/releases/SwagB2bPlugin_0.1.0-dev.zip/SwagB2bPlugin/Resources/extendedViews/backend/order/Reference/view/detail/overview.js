//{namespace name=backend/plugins/b2b_debtor_plugin}
//{block name="backend/order/view/detail/overview"}
//{$smarty.block.parent}
/** global: Ext */
Ext.define('Shopware.apps.Order.Reference.view.detail.Overview', {
    override: 'Shopware.apps.Order.view.detail.Overview',

    initComponent: function () {
        var me = this;
        me.callParent();

        Ext.Ajax.request({
            url: '{url controller=AttributeData action=loadData}',
            params: {
                _foreignKey: me.record.get('id'),
                _table: 's_order_attributes'
            },
            success: function(responseData) {
                var response = Ext.JSON.decode(responseData.responseText);

                me.editForm.getForm().findField('orderReference').setValue(response.data['__attribute_b2b_order_reference']);
                me.editForm.getForm().findField('requestedDeliveryDate').setValue(response.data['__attribute_b2b_requested_delivery_date']);
            }
        });
    },

    createEditElements: function() {
        var me = this,
            elements = me.callParent(arguments);

        elements.push({
            xtype: 'textfield',
            name: 'orderReference',
            fieldLabel: '{s name=b2b_OrderReference}Order Reference{/s}'
        }, {
            xtype: 'textfield',
            name: 'requestedDeliveryDate',
            fieldLabel: '{s name=b2b_RequestedDeliveryDate}Requested delivery date{/s}',
        });

        return elements;
    }
});
//{/block}