<?php declare(strict_types=1);

namespace Shopware\B2B\Role\Framework;

use Shopware\B2B\Common\Service\AbstractCrudService;
use Shopware\B2B\Common\Service\CrudServiceRequest;

class RoleCrudService extends AbstractCrudService
{
    /**
     * @var RoleRepository
     */
    private $roleRepository;

    /**
     * @var RoleValidationService
     */
    private $validationService;

    /**
     * @param RoleRepository $roleRepository
     * @param RoleValidationService $roleValidationService
     */
    public function __construct(
        RoleRepository $roleRepository,
        RoleValidationService $roleValidationService

    ) {
        $this->roleRepository = $roleRepository;
        $this->validationService = $roleValidationService;
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createNewRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'name',
                'debtorEmail',
            ]
        );
    }

    /**
     * @param array $data
     * @return CrudServiceRequest
     */
    public function createExistingRecordRequest(array $data): CrudServiceRequest
    {
        return new CrudServiceRequest(
            $data,
            [
                'id',
                'name',
                'debtorEmail',
            ]
        );
    }

    /**
     * @param CrudServiceRequest $request
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @return RoleEntity
     */
    public function create(CrudServiceRequest $request): RoleEntity
    {
        $data = $request->getFilteredData();

        $role = new RoleEntity();

        $role->setData($data);

        $validation = $this->validationService
            ->createInsertValidation($role);

        $this->testValidation($role, $validation);

        $role = $this->roleRepository
            ->addRole($role);

        return $role;
    }

    /**
     * @param CrudServiceRequest $request
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     * @return RoleEntity
     */
    public function update(CrudServiceRequest $request): RoleEntity
    {
        $data = $request->getFilteredData();

        $role = new RoleEntity();

        $role->setData($data);

        $validation = $this->validationService
            ->createUpdateValidation($role);

        $this->testValidation($role, $validation);

        $role = $this->roleRepository
            ->updateRole($role);

        return $role;
    }

    /**
     * @param CrudServiceRequest $request
     * @return RoleEntity
     */
    public function remove(CrudServiceRequest $request): RoleEntity
    {
        $data = $request->getFilteredData();
        $role = new RoleEntity();
        $role->setData($data);

        $this->roleRepository
            ->removeRole($role);

        return $role;
    }
}
