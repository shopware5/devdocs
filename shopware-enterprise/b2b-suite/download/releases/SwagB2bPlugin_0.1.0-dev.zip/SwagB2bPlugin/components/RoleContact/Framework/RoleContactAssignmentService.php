<?php declare(strict_types=1);

namespace Shopware\B2B\RoleContact\Framework;

/**
 * Assigns roles to contacts M:N
 */
class RoleContactAssignmentService
{
    /**
     * @var RoleContactRepository
     */
    private $roleContactRepository;

    /**
     * @param RoleContactRepository $roleContactRepository
     */
    public function __construct(
        RoleContactRepository $roleContactRepository
    ) {
        $this->roleContactRepository = $roleContactRepository;
    }

    /**
     * @param int $roleId
     * @param int $contactId
     * @throws MismatchingDataException
     */
    public function assign(int $roleId, int $contactId)
    {
        if (!$this->roleContactRepository->isRoleDebtorContactDebtor($roleId, $contactId)) {
            throw new MismatchingDataException();
        }

        $this->roleContactRepository
            ->assignRoleContact($roleId, $contactId);
    }

    /**
     * @param int $roleId
     * @param int $contactId
     */
    public function removeAssignment(int $roleId, int $contactId)
    {
        $this->roleContactRepository
            ->removeRoleContactAssignment($roleId, $contactId);
    }
}
