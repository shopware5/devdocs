<?php

namespace SwagExtendCustomProducts\Subscriber;

use Enlight\Event\SubscriberInterface;
use Enlight_Event_EventArgs;
use Enlight_View_Default;
use Shopware_Proxies_ShopwareControllersBackendSwagCustomProductsProxy as Subject;
use Symfony\Component\DependencyInjection\ContainerInterface;

class Backend implements SubscriberInterface
{
    /** @var ContainerInterface */
    private $container;

    /** @var string */
    private $path;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $this->path = $this->container->getParameter('swag_extend_custom_products.plugin_dir');
    }

    public static function getSubscribedEvents()
    {
        return [
            'Enlight_Controller_Action_PostDispatch_Backend_SwagCustomProducts' => 'extendBackendModule'
        ];
    }

    public function extendBackendModule(Enlight_Event_EventArgs $arguments)
    {
        /** @var Subject $subject */
        $subject = $arguments->get('subject');

        /** @var Enlight_View_Default $view */
        $view = $subject->View();

        // add the template dir to the view.
        $view->addTemplateDir(
            $this->path . '/Resources/Views/'
        );

        $files = [];

        if ($arguments->get('request')->getActionName() === 'index') {
            $files[] = 'backend/swag_custom_products/view/option/types/custom_type.js';
        }

        if ($arguments->get('request')->getActionName() === 'load') {
            $files[] = 'backend/swag_extend_custom_products/swag_custom_products/view/components/type_translator.js';
        }

        foreach ($files as $file) {
            $view->extendsTemplate($file);
        }
    }
}