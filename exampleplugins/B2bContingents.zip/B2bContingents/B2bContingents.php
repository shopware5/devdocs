<?php declare(strict_types=1);

namespace B2bContingents;

use Shopware\Components\Plugin;

class B2bContingents extends Plugin
{
}
