<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Api;

use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Contact\Framework\ContactCrudService;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Contact\Framework\ContactSearchStruct;
use Shopware\B2B\Debtor\Framework\DebtorRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;

class ContactController
{
    /**
     * @var ContactCrudService
     */
    private $contactCrudService;

    /**
     * @var ContactRepository
     */
    private $contactSearchRepository;

    /**
     * @var GridHelper
     */
    private $contactGridHelper;

    /**
     * @var DebtorRepository
     */
    private $debtorRepository;

    /**
     * @var LoginContextService
     */
    private $loginContextService;

    /**
     * @param ContactRepository $contactSearchRepository
     * @param ContactCrudService $contactCrudService
     * @param GridHelper $contactGridHelper
     * @param DebtorRepository $debtorRepository
     * @param LoginContextService $loginContextService
     */
    public function __construct(
        ContactRepository $contactSearchRepository,
        ContactCrudService $contactCrudService,
        GridHelper $contactGridHelper,
        DebtorRepository $debtorRepository,
        LoginContextService $loginContextService
    ) {
        $this->contactCrudService = $contactCrudService;
        $this->contactSearchRepository = $contactSearchRepository;
        $this->contactGridHelper = $contactGridHelper;
        $this->debtorRepository = $debtorRepository;
        $this->loginContextService = $loginContextService;
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @throws \Shopware\B2B\Common\Repository\NotFoundException
     * @return array
     */
    public function getListAction(string $debtorEmail, Request $request): array
    {
        $search = new ContactSearchStruct();
        $context = $this->debtorRepository
            ->fetchIdentityByEmail($debtorEmail, $this->loginContextService)
            ->getOwnershipContext();

        $this->contactGridHelper
            ->extractSearchDataInRestApi($request, $search);

        $contacts = $this->contactSearchRepository
            ->fetchList($context, $search);

        $totalCount = $this->contactSearchRepository
            ->fetchTotalCount($context, $search);

        return ['success' => true, 'contacts' => $contacts, 'totalCount' => $totalCount];
    }

    /**
     * @param string $debtorEmail
     * @param string $email
     * @return array
     */
    public function getAction(string $debtorEmail, string $email): array
    {
        $contact = $this->contactSearchRepository
            ->fetchOneByEmail($email);

        return ['success' => true, 'contact' => $contact];
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function createAction(string $debtorEmail, Request $request): array
    {
        $post = $request->getPost();
        $post['passwordNew'] = $request->getParam('password');
        $post['passwordRepeat'] = $request->getParam('password');

        $serviceRequest = $this->contactCrudService
            ->createNewRecordRequest($post);

        $debtorIdentity = $this->debtorRepository
            ->fetchIdentityByEmail($debtorEmail, $this->loginContextService);

        $contact = $this->contactCrudService
            ->create($serviceRequest, $debtorIdentity);

        return ['success' => true, 'contact' => $contact];
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function updateAction(string $debtorEmail, Request $request): array
    {
        $post = $request->getPost();

        if ($request->getParam('password')) {
            $post['passwordNew'] = $request->getParam('password');
            $post['passwordRepeat'] = $request->getParam('password');
        }

        $serviceRequest = $this->contactCrudService
            ->createExistingRecordRequest($post);

        $contact = $this->contactCrudService
            ->update($serviceRequest);

        return ['success' => true, 'contact' => $contact];
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function removeAction(string $debtorEmail, Request $request): array
    {
        $serviceRequest = $this->contactCrudService
            ->createExistingRecordRequest($request->getPost());

        $contact = $this->contactCrudService->remove($serviceRequest);

        return ['success' => true, 'contact' => $contact];
    }
}
