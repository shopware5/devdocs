<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentRule\Framework\ProductOrderNumberType;

use Shopware\B2B\Cart\Framework\CartAccessContext;
use Shopware\B2B\Cart\Framework\CartAccessStrategyInterface;
use Shopware\B2B\Cart\Framework\MessageCollection;
use Shopware\B2B\OrderClearance\Framework\OrderProductItem;

class ProductOrderNumberAccessStrategy implements CartAccessStrategyInterface
{
    /**
     * @var string
     */
    private $productOrderNumber;

    /**
     * @param string $productOrderNumber
     */
    public function __construct(string $productOrderNumber)
    {
        $this->productOrderNumber = $productOrderNumber;
    }

    /**
     * {@inheritdoc}
     */
    public function isAllowed(CartAccessContext $context, MessageCollection $messageCollection): bool
    {
        $products = $context->orderClearanceEntity
            ->getItemsOfType(OrderProductItem::class);

        $articleErrors = array_filter($products, function (OrderProductItem $product) {
            return $product->productOrderNumber === $this->productOrderNumber;
        });

        if (count($articleErrors) === 0) {
            return true;
        }

        $messageCollection->addError(
            __CLASS__,
            'ProductOrderNumberError',
            [
                'allowedValue' => $this->productOrderNumber,
            ]
        );

        return false;
    }
}
