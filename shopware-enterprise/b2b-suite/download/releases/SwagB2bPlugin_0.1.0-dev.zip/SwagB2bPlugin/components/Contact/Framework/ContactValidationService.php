<?php declare(strict_types=1);

namespace Shopware\B2B\Contact\Framework;

use Shopware\B2B\Common\Validator\ValidationBuilder;
use Shopware\B2B\Common\Validator\Validator;
use Shopware\B2B\Debtor\Framework\DebtorRepository;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class ContactValidationService
{
    /**
     * @var ValidationBuilder
     */
    private $validationBuilder;

    /**
     * @var ValidatorInterface
     */
    private $validator;

    /**
     * @var ContactRepository
     */
    private $contactRepository;

    /**
     * @var DebtorRepository
     */
    private $debtorRepository;

    /**
     * @param ValidationBuilder $validationBuilder
     * @param ValidatorInterface $validator
     * @param ContactRepository $contactRepository
     * @param DebtorRepository $debtorRepository
     */
    public function __construct(
        ValidationBuilder $validationBuilder,
        ValidatorInterface $validator,
        ContactRepository $contactRepository,
        DebtorRepository $debtorRepository
    ) {
        $this->validationBuilder = $validationBuilder;
        $this->validator = $validator;
        $this->contactRepository = $contactRepository;
        $this->debtorRepository = $debtorRepository;
    }

    /**
     * @param ContactEntity $contact
     * @return Validator
     */
    public function createInsertValidation(ContactEntity $contact): Validator
    {
        return $this->createCrudValidation($contact)
            ->validateThat('id', $contact->id)
                ->isBlank()

            ->validateThat('email', $contact->email)
                ->isUnique(function () use ($contact) {
                    return 0 === $this->contactRepository->hasByEmail($contact->email);
                })
                ->isUnique(function () use ($contact) {
                    return !$this->debtorRepository->hasDebtorWithEmail($contact->email);
                })
                ->isNotBlank()
                ->isEmail()

            ->getValidator($this->validator);
    }

    /**
     * @param ContactEntity $contact
     * @return Validator
     */
    public function createUpdateValidation(ContactEntity $contact): Validator
    {
        return $this->createCrudValidation($contact)
            ->validateThat('id', $contact->id)
                ->isNotBlank()

            ->validateThat('email', $contact->email)
                ->isUnique(function () use ($contact) {
                    return 2 > $this->contactRepository->hasByEmail($contact->email);
                })
                ->isUnique(function () use ($contact) {
                    return 3 > $this->debtorRepository->fetchDebtorWithEmailCount($contact->email);
                })
                ->isNotBlank()
                ->isEmail()


            ->getValidator($this->validator);
    }

    /**
     * @param ContactEntity $contact
     * @return ValidationBuilder
     */
    private function createCrudValidation(ContactEntity $contact): ValidationBuilder
    {
        return $this->validationBuilder

            ->validateThat('password', $contact->password)
                ->isNotBlank()
                ->isString()

            ->validateThat('encoder', $contact->encoder)
                ->isNotBlank()
                ->isString()

            ->validateThat('active', $contact->active)
                ->isBool()

            ->validateThat('language', $contact->language)
                ->isInt()

            ->validateThat('title', $contact->title)
                ->isString()

            ->validateThat('salutation', $contact->salutation)
                ->isString()

            ->validateThat('firstName', $contact->firstName)
                ->isNotBlank()
                ->isString()

            ->validateThat('lastName', $contact->lastName)
                ->isNotBlank()
                ->isString()

            ->validateThat('lastName', $contact->department)
                ->isString()

            ->validateThat('debtorEmail', $contact->debtorEmail)
                ->isNotBlank()
                ->isString();
    }
}
