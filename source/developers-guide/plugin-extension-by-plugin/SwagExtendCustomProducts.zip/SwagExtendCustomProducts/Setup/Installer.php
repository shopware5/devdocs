<?php

namespace SwagExtendCustomProducts\Setup;

use RuntimeException;
use SwagExtendCustomProducts\Components\Verifier;
use Symfony\Component\DependencyInjection\ContainerInterface;

class Installer
{
    /** @var ContainerInterface */
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    /**
     * @return bool
     */
    public function install()
    {
        // Checks if the plugin Custom Products (v2) is installed.
        $verifier = new Verifier($this->container->get('dbal_connection'));
        if(!$verifier->isDependingPluginInstalled()) {
            throw new RuntimeException('The Plugin "Custom Products (v2)" is required.');
        }

        return true;
    }
}