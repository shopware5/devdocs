<?php declare(strict_types=1);

namespace Shopware\B2B\Order\Bridge;

use Enlight\Event\SubscriberInterface;

use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class OrderRequestedDeliveryDateSubscriber implements SubscriberInterface
{
    /**
     * @var AuthenticationService
     */
    private $authenticationService;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @param AuthenticationService $authenticationService
     * @param \Shopware\B2B\Order\Bridge\OrderRepository $orderRepository
     */
    public function __construct(
        AuthenticationService $authenticationService,
        OrderRepository $orderRepository
    ) {
        $this->authenticationService = $authenticationService;
        $this->orderRepository = $orderRepository;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Shopware_Controllers_Frontend_Checkout::saveOrder::after' => 'addOrderRequestedDeliveryDate',
        ];
    }

    /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function addOrderRequestedDeliveryDate(\Enlight_Hook_HookArgs $args)
    {
        $orderNumber = $args->getReturn();
        $args->setReturn($orderNumber);

        if (!$this->authenticationService->isB2b()) {
            return;
        }

        $requestedDeliveryDate = $args->getSubject()->Request()->getParam('b2bRequestedDeliveryDate');

        if (!$requestedDeliveryDate) {
            return;
        }

        $this->orderRepository->setRequestedDeliveryDate((string) $orderNumber, $requestedDeliveryDate);
    }
}
