<?php declare(strict_types=1);

namespace Shopware\B2B\ContingentGroup\Api;

use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupCrudService;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupRepository;
use Shopware\B2B\ContingentGroup\Framework\ContingentGroupSearchStruct;
use Shopware\B2B\Debtor\Framework\DebtorRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;

class ContingentGroupController
{
    /**
     * @var ContingentGroupRepository
     */
    private $contingentGroupRepository;

    /**
     * @var GridHelper
     */
    private $requestHelper;

    /**
     * @var ContingentGroupCrudService
     */
    private $contingentGroupCrudService;

    /**
     * @var DebtorRepository
     */
    private $debtorRepository;
    /**
     * @var LoginContextService
     */
    private $loginContextService;

    /**
     * @param ContingentGroupRepository $contingentGroupRepository
     * @param GridHelper $requestHelper
     * @param ContingentGroupCrudService $contingentGroupCrudService
     * @param DebtorRepository $debtorRepository
     * @param LoginContextService $loginContextService
     */
    public function __construct(
        ContingentGroupRepository $contingentGroupRepository,
        GridHelper $requestHelper,
        ContingentGroupCrudService $contingentGroupCrudService,
        DebtorRepository $debtorRepository,
        LoginContextService $loginContextService
    ) {
        $this->contingentGroupRepository = $contingentGroupRepository;
        $this->requestHelper = $requestHelper;
        $this->contingentGroupCrudService = $contingentGroupCrudService;
        $this->debtorRepository = $debtorRepository;
        $this->loginContextService = $loginContextService;
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function getListAction(string $debtorEmail, Request $request): array
    {
        $search = new ContingentGroupSearchStruct();

        $this->requestHelper
            ->extractSearchDataInRestApi($request, $search);

        $context = $this->debtorRepository
            ->fetchIdentityByEmail($debtorEmail, $this->loginContextService)
            ->getOwnershipContext();

        $contingentGroups = $this->contingentGroupRepository
            ->fetchList($context, $search);

        $totalCount = $this->contingentGroupRepository
            ->fetchTotalCount($context, $search);

        return ['success' => true, 'contingentGroups' => $contingentGroups, 'totalCount' => $totalCount];
    }

    /**
     * @param string $debtorEmail
     * @param int $contingentGroupId
     * @return array
     */
    public function getAction(string $debtorEmail, int $contingentGroupId): array
    {
        $contingentGroup = $this->contingentGroupRepository
            ->fetchOneById($contingentGroupId);

        return ['success' => true, 'contingentGroup' => $contingentGroup];
    }

    /**
     * @param string $debtorEmail
     * @param Request $request
     * @return array
     */
    public function createAction(string $debtorEmail, Request $request): array
    {
        $context = $this->debtorRepository
            ->fetchIdentityByEmail($debtorEmail, $this->loginContextService)
            ->getOwnershipContext();

        $data = [
            'name' => $request->getParam('name'),
            'description' => $request->getParam('description'),
        ];

        $newRecord = $this->contingentGroupCrudService
            ->createNewRecordRequest($data);

        $contingentGroup = $this->contingentGroupCrudService
            ->create($newRecord, $context);

        return ['success' => true, 'contingentGroup' => $contingentGroup];
    }

    /**
     * @param string $debtorEmail
     * @param int $contingentGroupId
     * @param Request $request
     * @return array
     */
    public function updateAction(string $debtorEmail, int $contingentGroupId, Request $request): array
    {
        $context = $this->debtorRepository
            ->fetchIdentityByEmail($debtorEmail, $this->loginContextService)
            ->getOwnershipContext();

        $data = [
            'id' => $contingentGroupId,
            'name' => $request->getParam('name'),
            'description' => $request->getParam('description'),
        ];

        $existingRecord = $this->contingentGroupCrudService
            ->createExistingRecordRequest($data);

        $contingentGroup = $this->contingentGroupCrudService
            ->update($existingRecord, $context);

        return ['success' => true, 'contingentGroup' => $contingentGroup];
    }

    /**
     * @param string $debtorEmail
     * @param int $contingentGroupId
     * @param Request $request
     * @return array
     */
    public function removeAction(string $debtorEmail, int $contingentGroupId, Request $request): array
    {
        $data = [
            'id' => $contingentGroupId,
            'name' => $request->getParam('name'),
            'description' => $request->getParam('description'),
        ];

        $existingRecord = $this->contingentGroupCrudService
            ->createExistingRecordRequest($data);

        $contingentGroup = $this->contingentGroupCrudService
            ->remove($existingRecord);

        return ['success' => true, 'contingentGroup' => $contingentGroup];
    }
}
