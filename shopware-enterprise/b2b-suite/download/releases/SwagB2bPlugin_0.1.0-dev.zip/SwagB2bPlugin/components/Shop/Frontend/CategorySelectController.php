<?php declare(strict_types=1);

namespace Shopware\B2B\Shop\Frontend;

use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Shop\Bridge\CategoryRepository;
use Shopware\B2B\Shop\Bridge\ShopService;

class CategorySelectController
{
    /**
     * @var CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var ShopService
     */
    private $shop;

    /**
     * @param CategoryRepository $categoryRepository
     * @param ShopService $shop
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        ShopService $shop
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->shop = $shop;
    }

    /**
     * @param Request $request
     * @return array
     */
    public function gridAction(Request $request): array
    {
        $selectedCategory = (int) $request->getParam('selectedId');
        $parentId = (int) $request->getParam('parentId');

        if (!$parentId) {
            $parentId = $this->shop->getRootCategoryId();
        }

        $rows = $this->categoryRepository
            ->fetchChildren($parentId);

        return [
            'nodes' => $rows,
            'selectedId' => $selectedCategory,
        ];
    }
}
