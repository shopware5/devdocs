<?php declare(strict_types=1);

namespace Shopware\B2B\Cart\Framework;

use Shopware\B2B\OrderClearance\Framework\OrderClearanceEntity;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;

class CartService
{
    /**
     * @var CartAccessFactoryInterface[]
     */
    private $rootStrategyFactories;

    /**
     * @param CartAccessFactoryInterface[] $rootStrategyFactories, ...
     */
    public function __construct(CartAccessFactoryInterface ... $rootStrategyFactories)
    {
        $this->rootStrategyFactories = $rootStrategyFactories;
    }

    /**
     * {@inheritdoc}
     */
    public function isAccessible(Identity $identity, OrderClearanceEntity $orderEntity, MessageCollection $messageCollection): bool
    {
        $strategies = [];
        foreach ($this->rootStrategyFactories as $strategyFactory) {
            $strategies[] = $strategyFactory->createCartAccessForIdentity($identity);
        }

        $blackList = new BlackListCartAccess(...$strategies);
        $cartContext = $this->createCartAccessContext($orderEntity);

        return $blackList->isAllowed($cartContext, $messageCollection);
    }

    /**
     * @param OrderClearanceEntity $orderEntity
     * @return CartAccessContext
     */
    private function createCartAccessContext(OrderClearanceEntity $orderEntity): CartAccessContext
    {
        $context = new CartAccessContext();
        $context->orderClearanceEntity = $orderEntity;

        return $context;
    }
}
