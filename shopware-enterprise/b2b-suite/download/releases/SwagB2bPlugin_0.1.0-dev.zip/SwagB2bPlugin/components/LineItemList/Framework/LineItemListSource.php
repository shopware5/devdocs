<?php declare(strict_types=1);

namespace Shopware\B2B\LineItemList\Framework;

interface LineItemListSource
{
}
